"use strict";
class Tweet {
    constructor(tweet_text, tweet_time) {
        this.text = tweet_text;
        this.time = new Date(tweet_time); //, "ddd MMM D HH:mm:ss Z YYYY"
    }
    //returns either 'live_event', 'achievement', 'completed_event', or 'miscellaneous'
    get source() {
        //TODO: identify whether the source is a live event, an achievement, a completed event, or miscellaneous.
        if (this.text.startsWith("Just completed a") || this.text.startsWith("Just posted a")) {
            return "completed_event";
        }
        else if (this.text.startsWith("Achieved a new") || this.text.startsWith("I just set")) {
            return "achievement";
        }
        else if (this.text.startsWith("Watch my")) {
            return "live_event";
        }
        return "miscellaneous";
    }
    //returns a boolean, whether the text includes any content written by the person tweeting.
    get written() {
        //TODO: identify whether the tweet is written
        if (!this.text.includes(" - ") || this.source != "completed_event") {
            return false;
        }
        var rules = ["#runkeeper", "@runkeeper", "#Runkeeper", "@Runkeeper", "Just completed a", "Check it out!",
            "km", " mi ", "run", "with", ".", "walk", "bike", "Watch my", "Just posted a", "swim",
            "Achieved a new personal record", "activity", "mtn", "elliptical workout", "right now",
            "MySports Freestyle", "hike", " in "];
        var tokensString = this.text;
        for (var i = 0; i <= rules.length - 1; ++i) {
            var tokensSplit = tokensString.split(rules[i]);
            var tokensString = tokensSplit.join("");
        }
        var tokens = tokensString.split(" ");
        for (var i = tokens.length - 1; i != -1; --i) {
            if (tokens[i].includes("https://") || tokens[i].includes("0") || tokens[i].includes("1") ||
                tokens[i].includes("2") || tokens[i].includes("3") || tokens[i].includes("4") || tokens[i].includes("5") ||
                tokens[i].includes("6") || tokens[i].includes("7") || tokens[i].includes("8") || tokens[i].includes("9")) {
                tokens.splice(i, 1);
            }
        }
        for (var i = tokens.length - 1; i != -1; --i) {
            if (tokens[i] == "") {
                tokens.splice(i, 1);
            }
        }
        /*
        if (tokens.length != 0) {
            console.log(this.text);
            console.log(tokens);
        }
        */
        if (tokens.length != 0) {
            return true;
        }
        return false;
    }
    get writtenText() {
        if (!this.written) {
            return "";
        }
        //TODO: parse the written text from the tweet
        var rules = ["#runkeeper", "@runkeeper", "#Runkeeper", "@Runkeeper", "Just completed", "Check it out!",
            "km", " mi ", "run", "with", ".", "walk", "bike", "Watch my", "Just posted", "swim",
            "Achieved a new personal record", "activity", "mtn", "elliptical workout", "right now",
            "MySports Freestyle", "hike", " in ", "yoga practice", "strength workout", "group workout",
            "spinning workout", "CrossFit® workout", "pilates session", "bootcamp workout", "stairmaster / stepwell workout",
            " a ", " an ", "core workout", "row"];
        var tokensString = this.text;
        for (var i = 0; i <= rules.length - 1; ++i) {
            var tokensSplit = tokensString.split(rules[i]);
            var tokensString = tokensSplit.join("");
        }
        var tokens = tokensString.split(" ");
        for (var i = tokens.length - 1; i != -1; --i) {
            if (tokens[i].includes("https://") || tokens[i].includes("0") || tokens[i].includes("1") ||
                tokens[i].includes("2") || tokens[i].includes("3") || tokens[i].includes("4") || tokens[i].includes("5") ||
                tokens[i].includes("6") || tokens[i].includes("7") || tokens[i].includes("8") || tokens[i].includes("9")) {
                tokens.splice(i, 1);
            }
        }
        for (var i = tokens.length - 1; i != -1; --i) {
            if (tokens[i] == "") {
                tokens.splice(i, 1);
            }
        }
        return tokens.join(" ");
    }
    get activityType() {
        if (this.source != 'completed_event') {
            return "unknown";
        }
        //TODO: parse the activity type from the text of the tweet
        var activities = ["run", "walk", "mtn bike", "bike", "swim", "hike", "row", "elliptical", "MySports", "yoga",
            "strength workout", "group workout", "spinning workout", "CrossFit®", "pilates", "bootcamp workout",
            "stairmaster"];
        for (var i = 0; i <= activities.length - 1; ++i) {
            if (this.text.includes(activities[i])) {
                return activities[i];
            }
        }
        return "undefined";
    }
    get distance() {
        if (this.source != 'completed_event') {
            return 0;
        }
        //TODO: prase the distance from the text of the tweet
        var digits = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "."];
        var dist = "";
        for (var i = 0; i <= this.text.length - 1; ++i) {
            if (this.text[i] in digits) {
                for (var j = i; j <= this.text.length - 1; ++j) {
                    if (!(digits.includes(this.text[j]))) {
                        dist = dist + this.text[j] + this.text[j + 1] + this.text[j + 2];
                        //console.log(dist);
                        break;
                    }
                    dist = dist + this.text[j];
                }
                break;
            }
        }
        if (dist.slice(-2) == "mi") {
            return Number(dist.slice(0, -3));
        }
        else if (dist.slice(-2) == "km") {
            return Number(dist.slice(0, -3)) / 1.609;
        }
        return 0;
    }
    getHTMLTableRow(rowNumber) {
        //TODO: return a table row which summarizes the tweet with a clickable link to the RunKeeper activity
        var table_row = "<tr>";
        table_row = table_row + "<td>" + rowNumber + "</td>";
        table_row = table_row + "<td>" + this.activityType + "</td>";
        var index = this.text.indexOf("http");
        var blankIndex = 0;
        var link = "";
        var has_second = false;
        for (var i = index; i <= this.text.length - 1; ++i) {
            if (this.text[i] == " ") {
                blankIndex = i;
                has_second = true;
                break;
            }
            link = link + this.text[i];
        }
        var firstPart = this.text.slice(0, index);
        var secondPart = "";
        if (has_second) {
            secondPart = this.text.slice(blankIndex, this.text.length);
        }
        table_row = table_row + "<td>" + firstPart + "<a href='" + link + "'>" + link + "</a>" + secondPart + "</td>";
        table_row = table_row + "</tr>";
        return table_row;
    }
}
