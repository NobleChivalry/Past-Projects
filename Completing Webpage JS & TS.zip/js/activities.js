function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}
	
	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

	//TODO: create a new array or manipulate tweet_array to create a graph of the number of tweets containing each type of activity.
	//See line 164.
	var arr = [
		{"activity": "running", "distance": 4966},
		{"activity": "walking", "distance": 1672},
		{"activity": "mountain biking", "distance": 46},
		{"activity": "biking", "distance": 777},
		{"activity": "swimming", "distance": 55},
		{"activity": "hiking", "distance": 58},
		{"activity": "rowing", "distance": 17}
	]

	activity_vis_spec = {
	  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
	  "description": "A graph of the number of Tweets containing each type of activity.",
	  "data": {
	    "values": arr
	  },
	  //TODO: Add mark and encoding
	  "mark": "bar", "encoding": {
			"x": {"field": "activity", "type": "nominal", "sort": null},
			"y": {"field": "distance", "type": "quantitative"}
		}
	};

	vegaEmbed('#activityVis', activity_vis_spec, {actions:false});

	//TODO: create the visualizations which group the three most-tweeted activities by the day of the week.
	//Use those visualizations to answer the questions about which activities tended to be longest and when.
	//See comment block on line 200.
	var arr2 = [
		{"day":"Sun", "activity": "running", "distance":911}, {"day":"Sun", "activity": "walking", "distance":245}, {"day":"Sun", "activity": "biking", "distance":126},
      	{"day":"Mon", "activity": "running", "distance":775}, {"day":"Mon", "activity": "walking", "distance":273}, {"day":"Mon", "activity": "biking", "distance":129},
      	{"day":"Tue", "activity": "running", "distance":752}, {"day":"Tue", "activity": "walking", "distance":284}, {"day":"Tue", "activity": "biking", "distance":127},
		{"day":"Wed", "activity": "running", "distance":709}, {"day":"Wed", "activity": "walking", "distance":239}, {"day":"Wed", "activity": "biking", "distance":119},
		{"day":"Thu", "activity": "running", "distance":683}, {"day":"Thu", "activity": "walking", "distance":255}, {"day":"Thu", "activity": "biking", "distance":106},
		{"day":"Fri", "activity": "running", "distance":531}, {"day":"Fri", "activity": "walking", "distance":222}, {"day":"Fri", "activity": "biking", "distance":94},
		{"day":"Sat", "activity": "running", "distance":605}, {"day":"Sat", "activity": "walking", "distance":154}, {"day":"Sat", "activity": "biking", "distance":76}
	]

	distance_vis_spec = {
	  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
	  "description": "A graph of the distances by day of the week for all of the three most tweeted-about activities.",
	  "data": {
	    "values": arr2
	  },
	  //TODO: Add mark and encoding
	  "mark": "bar",
  		"encoding": {
		"x": {"field": "day", "sort": null},
		"y": {"field": "distance", "type": "quantitative"},
		"xOffset": {"field": "activity", "sort": null},
		"color": {"field": "activity", "sort": null}
  		}
	};

	//TODO: 3rd graph
	//[4.039047029812147, 3.7580243527101547, 3.8108308869099337, 4.1125090927952, 4.09342798687702, 5.5051054245489, 5.583062275250577]
	//																	[2.5395447539822924, 2.569749691436375, 2.6017593505152745, 2.5643537698485264, 2.6152289206546504, 2.7487584044296276, 3.0681726259179873]
	//																																	[8.815014477671626, 8.914521417420712, 8.425344360242542, 9.072776012289363, 9.653657485156634, 14.286384318471754, 13.991749583197686]
	//See comment block on line 200.
	var arr3 = [
		{"day":"Sun", "activity": "running", "distance":5.583062275250577}, {"day":"Sun", "activity": "walking", "distance":3.0681726259179873}, {"day":"Sun", "activity": "biking", "distance":13.991749583197686},
      	{"day":"Mon", "activity": "running", "distance":4.039047029812147}, {"day":"Mon", "activity": "walking", "distance":2.5395447539822924}, {"day":"Mon", "activity": "biking", "distance":8.815014477671626},
      	{"day":"Tue", "activity": "running", "distance":3.7580243527101547}, {"day":"Tue", "activity": "walking", "distance":2.569749691436375}, {"day":"Tue", "activity": "biking", "distance":8.914521417420712},
		{"day":"Wed", "activity": "running", "distance":3.8108308869099337}, {"day":"Wed", "activity": "walking", "distance":2.6017593505152745}, {"day":"Wed", "activity": "biking", "distance":8.425344360242542},
		{"day":"Thu", "activity": "running", "distance":4.1125090927952}, {"day":"Thu", "activity": "walking", "distance":2.5643537698485264}, {"day":"Thu", "activity": "biking", "distance":9.072776012289363},
		{"day":"Fri", "activity": "running", "distance":4.09342798687702}, {"day":"Fri", "activity": "walking", "distance":2.6152289206546504}, {"day":"Fri", "activity": "biking", "distance":9.653657485156634},
		{"day":"Sat", "activity": "running", "distance":5.5051054245489}, {"day":"Sat", "activity": "walking", "distance":2.7487584044296276}, {"day":"Sat", "activity": "biking", "distance":14.286384318471754}
	]

	distance_vis_spec_agg = {
	  "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
	  "description": "A graph of the distances by day of the week for all of the three most tweeted-about activities.",
	  "data": {
	    "values": arr3
	  },
	  //TODO: Add mark and encoding
	  "mark": "bar",
  		"encoding": {
		"x": {"field": "day", "sort": null},
		"y": {"aggregate": "mean", "field": "distance", "type": "quantitative"},
		"xOffset": {"field": "activity", "sort": null},
		"color": {"field": "activity", "sort": null}
  		}
	};

	//TODO: Button
	var current_graph = 0;
	function switchGraphs() {
		if (current_graph == 0) {
			current_graph = 1;
		}
		else {
			current_graph = 0;
		}

		if (current_graph === 0) {
            document.getElementById('distanceVis').style.display = 'inline';
			document.getElementById('distanceVisAggregated').style.display = 'none';
            vegaEmbed('#distanceVis', distance_vis_spec, {actions:false});
			document.getElementById('aggregate').innerText = "Show all means";
        }
		else {
            document.getElementById('distanceVis').style.display = 'none';
			document.getElementById('distanceVisAggregated').style.display = 'inline';
            vegaEmbed('#distanceVisAggregated', distance_vis_spec_agg, {actions:false});
			document.getElementById('aggregate').innerText = "Show all activities";
        }
	}
	
	document.getElementById('aggregate').addEventListener('click', switchGraphs);
	vegaEmbed('#distanceVis', distance_vis_spec, {actions:false});

	//TODO: Replace span tags
	var activities = ["running", "walking", "mountain biking", "biking", "swimming", "hiking", "rowing", "elliptical", "MySports",
						"yoga", "strength workout", "group workout", "spinning workout", "CrossFit®", "pilates", "bootcamp workout",
						"stairmaster"];
	document.getElementById('numberActivities').innerText = activities.length;

	var activities2 = ["run", "walk", "mountain bike", "bike", "swim", "hike", "row"];
	var run = 0;
	var walk = 0;
	var mtn_bike = 0;
	var bike = 0;
	var swim = 0;
	var hike = 0;
	var row = 0;
	for (var i = 0; i <= tweet_array.length-1; ++i) {
		if (tweet_array[i].activityType == "run") {
			++run;
		}
		else if (tweet_array[i].activityType == "walk") {
			++walk;
		}
		else if (tweet_array[i].activityType == "mtn bike") {
			++mtn_bike;
		}
		else if (tweet_array[i].activityType == "bike") {
			++bike;
		}
		else if (tweet_array[i].activityType == "swim") {
			++swim;
		}
		else if (tweet_array[i].activityType == "hike") {
			++hike;
		}
		else if (tweet_array[i].activityType == "row") {
			++row;
		}
	}
	var lis = [run, walk, mtn_bike, bike, swim, hike, row];
	//console.log(lis); // # of each type of activity -> [4966, 1672, 46, 777, 55, 58, 17]
	var index1 = lis.indexOf(Math.max(...lis));
	lis[index1] = null;
	var index2 = lis.indexOf(Math.max(...lis));
	lis[index2] = null;
	var index3 = lis.indexOf(Math.max(...lis));
	lis[index3] = null;
	document.getElementById('firstMost').innerText = activities[index1];
	document.getElementById('secondMost').innerText = activities[index2];
	document.getElementById('thirdMost').innerText = activities[index3];
	
	document.getElementById('longestActivityType').innerText = activities2[index1];
	document.getElementById('shortestActivityType').innerText = activities2[index3];

	var running_activities = tweet_array.filter(function(tweet){return tweet.activityType == activities2[index1];});
	var days = running_activities.map(function(tweet){return tweet.time.toString().slice(0, 3);})
	var weekdays = 0;
	var weekends = 0;
	for (var i = 0; i <= days.length-1; ++i) {
		if (["Mon", "Tue", "Wed", "Thu", "Fri"].includes(days[i])) {
			++weekdays;
		}
		if (["Sat", "Sun"].includes(days[i])) {
			++weekends;
		}
	}
	var answer = "";
	if (weekdays >= weekends) {
		answer = "weekdays";
	}
	else {
		answer = "weekends";
	}
	document.getElementById('weekdayOrWeekendLonger').innerText = answer;

	/*
	var running_activities = tweet_array.filter(function(tweet){return tweet.activityType == activities2[index1];});
	var days = running_activities.map(function(tweet){return tweet.time.toString().slice(0, 3);});
	var maps = {"Mon":0, "Tue":0, "Wed":0, "Thu":0, "Fri":0, "Sat":0, "Sun":0};
	for (var i = 0; i <= days.length-1; ++i) {
		++maps[days[i]];
	}

	console.log(maps); // running -> {Mon: 775, Tue: 752, Wed: 709, Thu: 683, Fri: 531, Sat: 605, Sun: 911}

	var summ = {"Mon":0, "Tue":0, "Wed":0, "Thu":0, "Fri":0, "Sat":0, "Sun":0};
	for (var i = 0; i <= running_activities.length-1; ++i) {
		summ[running_activities[i].time.toString().slice(0, 3)] = summ[running_activities[i].time.toString().slice(0, 3)] +
			running_activities[i].distance;
	}
	mean = [summ["Mon"]/maps["Mon"], summ["Tue"]/maps["Tue"], summ["Wed"]/maps["Wed"], summ["Thu"]/maps["Thu"],
			summ["Fri"]/maps["Fri"], summ["Sat"]/maps["Sat"], summ["Sun"]/maps["Sun"]];

	console.log(mean); // running mean -> [4.039047029812147, 3.7580243527101547, 3.8108308869099337, 4.1125090927952, 4.09342798687702, 5.5051054245489, 5.583062275250577]

	var walking_activities = tweet_array.filter(function(tweet){return tweet.activityType == activities2[index2];});
	var days = walking_activities.map(function(tweet){return tweet.time.toString().slice(0, 3);});
	var maps = {"Mon":0, "Tue":0, "Wed":0, "Thu":0, "Fri":0, "Sat":0, "Sun":0};
	for (var i = 0; i <= days.length-1; ++i) {
		++maps[days[i]];
	}

	console.log(maps); // walking -> {Mon: 273, Tue: 284, Wed: 239, Thu: 255, Fri: 222, Sat: 154, Sun: 245}

	var summ = {"Mon":0, "Tue":0, "Wed":0, "Thu":0, "Fri":0, "Sat":0, "Sun":0};
	for (var i = 0; i <= walking_activities.length-1; ++i) {
		summ[walking_activities[i].time.toString().slice(0, 3)] = summ[walking_activities[i].time.toString().slice(0, 3)] +
			walking_activities[i].distance;
	}
	mean = [summ["Mon"]/maps["Mon"], summ["Tue"]/maps["Tue"], summ["Wed"]/maps["Wed"], summ["Thu"]/maps["Thu"],
			summ["Fri"]/maps["Fri"], summ["Sat"]/maps["Sat"], summ["Sun"]/maps["Sun"]];
	
	console.log(mean); // walking mean -> [2.5395447539822924, 2.569749691436375, 2.6017593505152745, 2.5643537698485264, 2.6152289206546504, 2.7487584044296276, 3.0681726259179873]

	var biking_activities = tweet_array.filter(function(tweet){return tweet.activityType == activities2[index3];});
	var days = biking_activities.map(function(tweet){return tweet.time.toString().slice(0, 3);});
	var maps = {"Mon":0, "Tue":0, "Wed":0, "Thu":0, "Fri":0, "Sat":0, "Sun":0};
	for (var i = 0; i <= days.length-1; ++i) {
		++maps[days[i]];
	}

	console.log(maps); // biking -> {Mon: 129, Tue: 127, Wed: 119, Thu: 106, Fri: 94, Sat: 76, Sun: 126}

	var summ = {"Mon":0, "Tue":0, "Wed":0, "Thu":0, "Fri":0, "Sat":0, "Sun":0};
	for (var i = 0; i <= biking_activities.length-1; ++i) {
		summ[biking_activities[i].time.toString().slice(0, 3)] = summ[biking_activities[i].time.toString().slice(0, 3)] +
			biking_activities[i].distance;
	}
	mean = [summ["Mon"]/maps["Mon"], summ["Tue"]/maps["Tue"], summ["Wed"]/maps["Wed"], summ["Thu"]/maps["Thu"],
			summ["Fri"]/maps["Fri"], summ["Sat"]/maps["Sat"], summ["Sun"]/maps["Sun"]];

	console.log(mean); // biking mean -> [8.815014477671626, 8.914521417420712, 8.425344360242542, 9.072776012289363, 9.653657485156634, 14.286384318471754, 13.991749583197686]
	*/
}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	loadSavedRunkeeperTweets().then(parseTweets);
});