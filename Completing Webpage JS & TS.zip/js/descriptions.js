function parseTweets(runkeeper_tweets) {
	//Do not proceed if no tweets loaded
	if(runkeeper_tweets === undefined) {
		window.alert('No tweets returned');
		return;
	}

	tweet_array = runkeeper_tweets.map(function(tweet) {
		return new Tweet(tweet.text, tweet.created_at);
	});

	//TODO: Filter to just the written tweets
	tweet_array = tweet_array.filter(function(tweet){return tweet.written;});
}

function addEventHandlerForSearch() {
	//TODO: Search the written tweets as text is entered into the search box, and add them to the table
	var text_box = document.getElementById('textFilter');
	var len = 0;
	text_box.addEventListener('input', function(){
		var input = text_box.value;
		len = tweet_array.length;
		var has_text = tweet_array.filter(function(tweet){return tweet.text.toLowerCase().includes(input.toLowerCase());});
		document.getElementById('searchCount').innerText = has_text.length;
		document.getElementById('searchText').innerText = input;

		//TODO: Make table
		var table = document.getElementById("tweetTable");
		while (table.firstChild) {
			table.removeChild(table.firstChild);
		}
		for (var i = 1; i <= has_text.length; ++i) {
			var table = document.getElementById("tweetTable");
			var current_row = table.insertRow();
			current_row.innerHTML = has_text[i-1].getHTMLTableRow(i);
		}

		//TODO: No input in search bar
		if (input == "") {
			document.getElementById('searchCount').innerText = "???";
			document.getElementById('searchText').innerText = "???";

			var table = document.getElementById("tweetTable");
			while (table.firstChild) {
				table.removeChild(table.firstChild);
			}
		}
	});
}

//Wait for the DOM to load
document.addEventListener('DOMContentLoaded', function (event) {
	addEventHandlerForSearch();
	loadSavedRunkeeperTweets().then(parseTweets);
});