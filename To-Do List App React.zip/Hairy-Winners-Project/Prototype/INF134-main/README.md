# How to Run: <br>
cd my-react-app <br>
npm install <br>
npm start <br>

# Demo Video: <br>
[Link]
