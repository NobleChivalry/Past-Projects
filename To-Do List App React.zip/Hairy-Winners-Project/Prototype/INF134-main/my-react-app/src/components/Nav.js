import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from './AuthContext'; 

function Nav() {
    const { isAuthenticated, logout } = useAuth();

    return (
        <nav style={{ backgroundColor: '#333', padding: '10px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'sticky', top: 0, zIndex: 1000 }}>
            <div style={{ marginLeft: '20px' }}>
                <Link to="/" style={{ textDecoration: 'none', color: '#faf0e6', fontSize: '24px', fontWeight: 'bold' }}>
                    To-Do App
                </Link>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, display: 'flex', gap: '10px', alignItems: 'center', marginRight: '20px' }}>
                {!isAuthenticated && (
                    <>
                        <li>
                            <Link 
                                to="/login" 
                                className="nav-button"
                                style={{ 
                                    color: '#faf0e6', 
                                    padding: '10px 20px', 
                                    textDecoration: 'none', 
                                    borderRadius: '4px',
                                    textAlign: 'center',
                                    backgroundColor: '#555',
                                    transition: 'background-color 0.3s'
                                }}
                                onMouseEnter={(e) => e.target.style.backgroundColor = '#777'}
                                onMouseLeave={(e) => e.target.style.backgroundColor = '#555'}
                            >
                                Login
                            </Link>
                        </li>
                        <li>
                            <Link 
                                to="/register" 
                                className="nav-button"
                                style={{ 
                                    color: '#faf0e6', 
                                    padding: '10px 20px', 
                                    textDecoration: 'none', 
                                    borderRadius: '4px',
                                    textAlign: 'center',
                                    backgroundColor: '#555',
                                    transition: 'background-color 0.3s'
                                }}
                                onMouseEnter={(e) => e.target.style.backgroundColor = '#777'}
                                onMouseLeave={(e) => e.target.style.backgroundColor = '#555'}
                            >
                                Register
                            </Link>
                        </li>
                    </>
                )}
                {isAuthenticated && (
                    <>
                        <li>
                            <Link 
                                to="/task-manager" 
                                className="nav-button"
                                style={{ 
                                    color: '#faf0e6', 
                                    padding: '10px 20px', 
                                    textDecoration: 'none', 
                                    borderRadius: '4px',
                                    textAlign: 'center',
                                    backgroundColor: '#555',
                                    transition: 'background-color 0.3s'
                                }}
                                onMouseEnter={(e) => e.target.style.backgroundColor = '#777'}
                                onMouseLeave={(e) => e.target.style.backgroundColor = '#555'}
                            >
                                Manage Tasks
                            </Link>
                        </li>
                        <li>
                            <Link 
                                to="/user-tasks" 
                                className="nav-button"
                                style={{ 
                                    color: '#faf0e6', 
                                    padding: '10px 20px', 
                                    textDecoration: 'none', 
                                    borderRadius: '4px',
                                    textAlign: 'center',
                                    backgroundColor: '#555',
                                    transition: 'background-color 0.3s'
                                }}
                                onMouseEnter={(e) => e.target.style.backgroundColor = '#777'}
                                onMouseLeave={(e) => e.target.style.backgroundColor = '#555'}
                            >
                                User Tasks
                            </Link>
                        </li> 
                        
                        <li>
                            <Link
                                onClick={logout}
                                className="nav-button"
                                style={{ 
                                    color: '#faf0e6', 
                                    padding: '10px 20px', 
                                    textDecoration: 'none', 
                                    borderRadius: '4px',
                                    textAlign: 'center',
                                    backgroundColor: '#555',
                                    border: 'none',
                                    cursor: 'pointer',
                                    transition: 'background-color 0.3s'
                                }}
                                onMouseEnter={(e) => e.target.style.backgroundColor = '#777'}
                                onMouseLeave={(e) => e.target.style.backgroundColor = '#555'}
                            >
                                Logout
                            </Link>
                        </li>
                    </>
                )}
            </ul>
        </nav>
    );
}

export default Nav;
