import React, { useState, useEffect } from 'react';

function UserTasks() {
    const [selectedUser, setSelectedUser] = useState('');
    const [tasks, setTasks] = useState([]);
    const [searchInput, setSearchInput] = useState('');

    useEffect(() => {
        const storedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
        setTasks(storedTasks);
    }, []);

    const handleSearch = (event) => {
        event.preventDefault();
        setSelectedUser(searchInput.trim());
    };

    const filteredTasks = tasks.filter(task => task.assignee.toLowerCase() === selectedUser.toLowerCase());

    return (
        <div style={{ maxWidth: '800px', margin: 'auto', padding: '20px', textAlign: 'center' }}>
            <h2 style={{ marginBottom: '20px' }}>Tasks for {selectedUser}</h2>
            <form onSubmit={handleSearch} style={{ marginBottom: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <input
                    type="text"
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                    placeholder="Enter user name"
                    style={{ padding: '10px', width: '100%', maxWidth: '400px', marginBottom: '10px', borderRadius: '4px' }}
                />
                <button type="submit" style={{ padding: '10px', backgroundColor: 'faf0e6', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer', width: '100%', maxWidth: '400px' }}>
                    Search Tasks
                </button>
            </form>
            <ul style={{ listStyleType: 'none', padding: 0 }}>
                {filteredTasks.length > 0 ? (
                    filteredTasks.map(task => (
                        <li key={task.id} style={{ textDecoration: task.status === 'Done' ? 'line-through' : 'none', padding: '10px 0' }}>
                            {task.description} - Priority: {task.priority} - Status: {task.status}
                        </li>
                    ))
                ) : (
                    <li>No tasks found for {selectedUser}</li>
                )}
            </ul>
        </div>
    );
}

export default UserTasks;
