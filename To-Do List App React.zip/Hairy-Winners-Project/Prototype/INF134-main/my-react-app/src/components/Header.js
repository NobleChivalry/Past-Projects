import React from 'react';

function Header() {
  return (
    <header style={{ backgroundColor: '#faf0e6', padding: '20px 0', textAlign: 'center', borderBottom: '1px solid #ddd' }}>
      <h1 style={{ margin: 0, color: '#333' }}>To-Do List</h1>
    </header>
  );
}

export default Header;
