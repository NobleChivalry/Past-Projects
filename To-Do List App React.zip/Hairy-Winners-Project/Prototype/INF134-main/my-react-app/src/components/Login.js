import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext'; // Ensure this path is correct

function Login() {
    const navigate = useNavigate();
    const { login } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = (event) => {
        event.preventDefault();
        if (login(email, password)) {
            setError('');
            navigate('/task-manager'); // Redirect to the task manager page
        } else {
            setError('Invalid email or password');
        }
    };

    return (
        <main style={{ padding: '20px', maxWidth: '300px', margin: 'auto' }}>
            <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'center' }}>
                <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    style={{ padding: '10px', width: '100%' }}
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    style={{ padding: '10px', width: '100%' }}
                />
                <button type="submit" style={{ padding: '10px', backgroundColor: '#faf0e6', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer', width: '100%' }}>
                    Log In
                </button>
            </form>
            {error && <p style={{ marginTop: '20px', color: 'red', textAlign: 'center' }}>{error}</p>}
        </main>
    );
}

export default Login;
