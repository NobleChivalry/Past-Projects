import React, { useState, useEffect } from 'react';

function TaskManager() {
    const [tasks, setTasks] = useState([]);
    const [taskInput, setTaskInput] = useState('');
    const [priority, setPriority] = useState('low');
    const [assignee, setAssignee] = useState('');
    const [status, setStatus] = useState('To Do');
    const [editingId, setEditingId] = useState('');
    const [sortOrder, setSortOrder] = useState('priority-asc');
    const [draggedTaskId, setDraggedTaskId] = useState(null);
    const [hoveredTaskId, setHoveredTaskId] = useState(null);

    useEffect(() => {
        const storedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
        setTasks(storedTasks);
    }, []);

    const saveTasksToLocalStorage = (tasks) => {
        localStorage.setItem('tasks', JSON.stringify(tasks));
    };

    const handleAddOrEditTask = (event) => {
        event.preventDefault();
        const newTask = {
            id: editingId || Date.now(),
            description: taskInput,
            assignee,
            priority,
            status,
        };

        let updatedTasks;
        if (editingId) {
            updatedTasks = tasks.map(task => task.id === editingId ? newTask : task);
        } else {
            updatedTasks = [...tasks, newTask];
        }

        setTasks(updatedTasks);
        saveTasksToLocalStorage(updatedTasks);

        setTaskInput('');
        setAssignee('');
        setPriority('low');
        setStatus('To Do');
        setEditingId('');
    };

    const prepareEditTask = (task) => {
        setTaskInput(task.description);
        setAssignee(task.assignee);
        setPriority(task.priority);
        setStatus(task.status);
        setEditingId(task.id);
    };

    const handleDeleteTask = (taskId) => {
        const updatedTasks = tasks.filter(task => task.id !== taskId);
        setTasks(updatedTasks);
        saveTasksToLocalStorage(updatedTasks);
    };

    const sortTasks = (order) => {
        const priorityOrder = {
            low: 1,
            medium: 2,
            high: 3
        };

        return [...tasks].sort((a, b) => {
            if (order === 'priority-asc') {
                return priorityOrder[a.priority] - priorityOrder[b.priority];
            } else {
                return priorityOrder[b.priority] - priorityOrder[a.priority];
            }
        });
    };

    const sortedTasks = sortTasks(sortOrder);

    const handleDragStart = (e, taskId) => {
        setDraggedTaskId(taskId);
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/html", e.target.innerHTML);
    };

    const handleDragOver = (e, taskId) => {
        e.preventDefault();
        setHoveredTaskId(taskId);
    };

    const handleDrop = (e, dropTaskId) => {
        e.preventDefault();
        const draggedTaskIndex = tasks.findIndex(task => task.id === draggedTaskId);
        const dropTaskIndex = tasks.findIndex(task => task.id === dropTaskId);
        const updatedTasks = [...tasks];
        const [draggedTask] = updatedTasks.splice(draggedTaskIndex, 1);
        updatedTasks.splice(dropTaskIndex, 0, draggedTask);

        setTasks(updatedTasks);
        saveTasksToLocalStorage(updatedTasks);
        setDraggedTaskId(null);
        setHoveredTaskId(null);
    };

    const handleDragEnd = () => {
        setDraggedTaskId(null);
        setHoveredTaskId(null);
    };

    return (
        <main style={{ padding: '20px', maxWidth: '400px', margin: 'auto' }}>
            <form onSubmit={handleAddOrEditTask} style={{ display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'center' }}>
                <input
                    type="text"
                    value={taskInput}
                    onChange={(e) => setTaskInput(e.target.value)}
                    placeholder="Add a new task"
                    required
                    style={{ padding: '10px', width: '100%' }}
                />
                <input
                    type="text"
                    value={assignee}
                    onChange={(e) => setAssignee(e.target.value)}
                    placeholder="Enter assignee"
                    required
                    style={{ padding: '10px', width: '100%' }}
                />
                <select value={priority} onChange={(e) => setPriority(e.target.value)} style={{ padding: '10px', width: '100%' }}>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select>
                <select value={status} onChange={(e) => setStatus(e.target.value)} style={{ padding: '10px', width: '100%' }}>
                    <option value="To Do">To Do</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Done">Done</option>
                </select>
                <button type="submit" style={{ padding: '10px', backgroundColor: '#faf0e6', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer', width: '100%' }}>
                    {editingId ? 'Edit Task' : 'Add Task'}
                </button>
            </form>
            <select onChange={(e) => setSortOrder(e.target.value)} value={sortOrder} style={{ padding: '10px', width: '100%', marginTop: '20px' }}>
                <option value="priority-asc">Sort by Priority (Ascending)</option>
                <option value="priority-desc">Sort by Priority (Descending)</option>
            </select>
            <ul style={{ listStyleType: 'none', padding: 0, width: '100%', marginTop: '20px' }}>
                {sortedTasks.map(task => (
                    <li
                        key={task.id}
                        draggable
                        onDragStart={(e) => handleDragStart(e, task.id)}
                        onDragOver={(e) => handleDragOver(e, task.id)}
                        onDrop={(e) => handleDrop(e, task.id)}
                        onDragEnd={handleDragEnd}
                        className={`task-item ${draggedTaskId === task.id ? 'dragging' : ''} ${hoveredTaskId === task.id ? 'hovered' : ''}`}
                        style={{ padding: '10px', marginBottom: '10px', border: '1px solid #ccc', borderRadius: '4px', backgroundColor: '#f9f9f9', textAlign: 'center', textDecoration: task.status === 'Done' ? 'line-through' : 'none' }}
                    >
                        <p>{task.description}</p>
                        <p>Assigned to: {task.assignee}</p>
                        <p>Priority: {task.priority}</p>
                        <p>Status: {task.status}</p>
                        <div>
                            <button onClick={() => prepareEditTask(task)} style={{ margin: '5px', padding: '5px 10px', backgroundColor: '#faf0e6', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Edit</button>
                            <button onClick={() => handleDeleteTask(task.id)} style={{ margin: '5px', padding: '5px 10px', backgroundColor: '#ffcccb', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Delete</button>
                        </div>
                    </li>
                ))}
            </ul>
            <style>
                {`
                    .task-item.dragging {
                        opacity: 0.5;
                        background-color: #e0e0e0;
                    }
                    .task-item.hovered {
                        border: 2px dashed #4285F4;
                    }
                `}
            </style>
        </main>
    );
}

export default TaskManager;
