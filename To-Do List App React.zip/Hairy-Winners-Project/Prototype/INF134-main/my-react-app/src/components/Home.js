import React from 'react';

function Home() {
  return (
    <main>
      <p>Welcome to our To-do list! Please navigate using the menu above.</p>
    </main>
  );
}

export default Home;
