import React, { useState } from 'react';

function Register() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleRegister = (event) => {
        event.preventDefault();
        const user = { name, email, password };
        localStorage.setItem('user', JSON.stringify(user));
        setMessage('New account created!');
    };

    return (
        <main style={{ padding: '20px', maxWidth: '325px', margin: 'auto' }}>
            <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <input
                    type="text"
                    placeholder="Full Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    style={{ padding: '10px', boxSizing: 'border-box' }}
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    style={{ padding: '10px', boxSizing: 'border-box' }}
                />
                <input
                    type="password"
                    placeholder="Create Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    style={{ padding: '10px', boxSizing: 'border-box' }}
                />
                <button type="submit" style={{ padding: '10px', backgroundColor: 'faf0e6', color: '#333', border: 'none', borderRadius: '4px', cursor: 'pointer', boxSizing: 'border-box' }}>
                    Register
                </button>
            </form> 
            {message && <p style={{ marginTop: '20px', color: 'green', textAlign: 'center', padding: '10px', border: '1px solid green', borderRadius: '4px', backgroundColor: '#e0ffe0' }}>{message}</p>}
        </main>
    );
}

export default Register;
