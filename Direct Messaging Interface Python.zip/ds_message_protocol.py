# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

import json, time
from collections import namedtuple
from Profile import Post, Profile

DataTuple = namedtuple('DataTuple', ['typeError', 'error_message', 'token'])

def join(username:str, password:str):
  '''
  Converts username and password into specified join JSON format.
  '''
  join_msg = {'join': {'username': username, 'password': password, 'token': ''}}
  return json.dumps(join_msg)


def post(message:str, token:str):
  '''
  Converts post into specified post JSON format.
  '''
  post = Post(message)
  post_time = post.get_time()
  post_msg = {'token': token, 'post': {'entry': message, 'timestamp': str(post_time)}}
  return json.dumps(post_msg)


def bio(bio:str, token:str, time:str = None):
  '''
  Converts bio into specified bio JSON format, if given.
  '''
  if bio != None:
    bio_msg = {'token': token, 'bio': {'entry': bio, 'timestamp': time}}
    return json.dumps(bio_msg)
  return bio


def sendDM(message:str, recipient:str, token:str):
  '''
  Sends a directmessage to another DS user.
  '''
  post = Post(message)
  post_time = post.get_time()
  dm = {'token': token, 'directmessage': {'entry': message, 'recipient': recipient, 'timestamp': str(post_time)}}
  return json.dumps(dm)


def reqUnread(token:str):
  '''
  Requests unread message from the DS server.
  '''
  req = {'token': token, 'directmessage': 'new'}
  return json.dumps(req)


def reqAll(token:str):
  '''
  Requests all messages from the DS server.
  '''
  req = {'token': token, 'directmessage': 'all'}
  return json.dumps(req)
  

def extract_json(json_msg:str) -> DataTuple:
  '''
  Call the json.loads function on a json string and convert it to a DataTuple
  object (ONLY for server responses).
  '''
  try:
    json_obj = json.loads(json_msg)
    typeError = json_obj['response']['type'] # Grabs typeError from the json_obj.
    error_message = json_obj['response']['message'] # Grabs error_message from json_obj.
    if 'token' in json_msg: 
      token = json_obj['response']['token'] # Grabs token from json_obj.
      return DataTuple(typeError, error_message, token) # Returns DataTuple if of parameters typeError, error_message, and token.
    return DataTuple(typeError, error_message, None)
  except json.JSONDecodeError:
    print("Json cannot be decoded.")
