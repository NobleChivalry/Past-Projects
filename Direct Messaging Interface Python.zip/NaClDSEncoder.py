# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

import nacl.utils
from nacl.public import PrivateKey, PublicKey, Box

class NaClDSEncoder:
    def generate(self):
        """
        The generate method handles the creation of a private and public keys.
        These keys are also combined to form a keypair. Call this function when
        your program needs to generate new keys.
        """
        # Calls the key generator function from the nacl library.
        raw = PrivateKey.generate()
        # The raw keypair, stored as PrivateKey.
        self.raw_keypair = raw
        # The private key, encoded from bytes to string.
        self.private_key = raw.encode(encoder=nacl.encoding.Base64Encoder).decode(encoding = 'UTF-8')
        # The public key, encoded from bytes to string.
        self.public_key = raw.public_key.encode(encoder=nacl.encoding.Base64Encoder).decode(encoding = 'UTF-8')
        # The keypair, useful for storage, but primarily a convenience
        # attribute that simply concatenates the public and private keys and
        # stores them as a string.
        self.keypair = self.public_key + self.private_key
    
    def encode_public_key(self, public_key:str) -> PublicKey:
        """
        encode_public_key takes an public_key string as a parameter and
        generates a PublicKey object.
        """
        return PublicKey(public_key, nacl.encoding.Base64Encoder)
    
    def encode_private_key(self, private_key:str) -> PrivateKey:
        """
        encode_private_key takes an private_key string as a parameter and
        generates a PrivateKey object.
        """
        return PrivateKey(private_key, nacl.encoding.Base64Encoder)
    
    def create_box(self, encoded_private_key:PrivateKey, encoded_public_key:PublicKey) -> Box:
        """
        A Box object enables messages to be encrypted and decrypted.
        creates an encryption Box using PrivateKey and PublicKey objects. Key
        types can be created using the encode_private_key and encode_public_key
        methods.
        """
        return Box(encoded_private_key, encoded_public_key)
    
    def encrypt_message(self, box:Box, message:str) -> str:
        """
        Encrypts a message using a Base64Encoder and UTF-8 encoding.
        :param box: the encryption box to use for encrypting. A box can be generated using the create_box method.
        :param message: the message to be encrypted
        :returns: an encrypted message in bytes
        """
        # First converts the message to bytes.
        bmsg = message.encode(encoding='UTF-8')
        # Encrypts message.
        encrypted_msg = box.encrypt(bmsg, encoder=nacl.encoding.Base64Encoder)
        # Converts back to string.
        msg = encrypted_msg.decode(encoding='UTF-8')
        return msg
    
    def decrypt_message(self, box:Box, message:str) -> str:
        """
        Encrypts a message using a Base64Encoder and UTF-8 encoding.
        :param box: the encryption box to use for decrypting. A box can be generated using the create_box method.
        :param message: the message to be decrypted
        :returns: a decrypted message of type str
        """
        
        # First converts the message to bytes.
        bmsg = message.encode(encoding='UTF-8')
        decrypted_msg = box.decrypt(bmsg, encoder=nacl.encoding.Base64Encoder)
        # Converts back to string.
        msg = decrypted_msg.decode(encoding='UTF-8')
        return msg
