# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

from tkinter import *
import tkinter as tk
from tkinter import ttk, filedialog
from unittest.mock import NonCallableMagicMock
from urllib.parse import non_hierarchical
from Profile import Post
from NaClProfile import NaClProfile
import json, time, os
from pathlib import Path
import ds_messenger

SERVER = "168.235.86.101"

class DsuFileNotFoundError(Exception):
    """
    A custom exception raised whenever the specified DSU file is not found.
    """
    pass

class Body(tk.Frame):
    def __init__(self, root, select_callback=None, current_profile=None):
        """
        A subclass of tk.Frame that is responsible for drawing all of the
        widgets in the body portion of the root frame.
        """
        tk.Frame.__init__(self, root)
        self.root = root
        self._select_callback = select_callback
        self._current_profile = current_profile

        # A list of the Post objects available in the active DSU file.
        self._posts = [Post]

        self.recipient = []
        self.curr_recipient = None
        
        # After all initialization is complete, call the _draw method to pack
        # the widgets into the Body instance.
        self._draw()

    def node_select(self, event):
        """
        Updates the entry_editor with the full post entry when the corresponding
        node in the posts_tree is selected.
        """
        index = int(self.posts_tree.selection()[0])
        curr_recipient_posts = self.recipient[index]

        for curr_recipient in curr_recipient_posts.keys():
            self.curr_recipient = curr_recipient

        self.set_text_entry(curr_recipient_posts)

    def get_text_entry(self) -> str:
        """
        Returns the text that is currently displayed in the entry_editor widget.
        """
        return self.send_box.get('1.0', 'end').rstrip()

    def set_text_entry(self, posts:list):
        """
        Sets the text to be displayed in the entry_editor widget.
        NOTE: This method is useful for clearing the widget, just pass an empty
        string.
        """
        self.entry_editor.config(state="normal")
        self.entry_editor.delete('0.0', 'end')
        for post in posts[self.curr_recipient]:
            self.entry_editor.insert(INSERT, post + '\n\n')
        self.entry_editor.config(state="disabled")

    def insert_text_entry(self, text:str, recipient:str):
        try:
            if self.curr_recipient + ': 'not in text and recipient == self.curr_recipient:
                self.entry_editor.insert(INSERT, self.curr_recipient + ': ' + text + '\n\n')
        except:
            pass

    def set_posts(self, posts:list):
        """
        Populates the self._posts attribute with posts from the active DSU file.
        """
        self.recipient = posts
        self._posts = posts
        for idx, post_obj in enumerate(posts):
            for name in post_obj.keys():
                self._insert_post_tree(idx,name)

    def insert_post(self, post: Post=None):
        """
        Inserts a single post to the post_tree widget.
        """
        if post != None:
            self.recipient.append({post.recipient:[]})
            self.curr_recipient = post.recipient
            id = len(self.recipient) - 1
            self._insert_post_tree(id, post)

    def reset_ui(self):
        """
        Resets all UI widgets to their default state. Useful for when clearing the UI is neccessary such
        as when a new DSU file is loaded, for example.
        """
        self.entry_editor.configure(state=tk.NORMAL)
        self.entry_editor.delete(0.0, 'end')
        self.entry_editor.insert(0.0, "")
        for item in self.posts_tree.get_children():
            self.posts_tree.delete(item)

    def _insert_post_tree(self, id, post: Post):
        """
        Inserts a post entry into the posts_tree widget.
        """
        if isinstance(post, Post):
            entry = post.recipient
        else:
            entry = post
        # Since we don't have a title, we will use the first 24 characters of a
        # post entry as the identifier in the post_tree widget.
        if len(entry) > 25:
            entry = entry[:24] + "..."
        
        self.posts_tree.insert('', id, id, text=entry)

    def _draw(self):
        """
        Call only once upon initialization to add widgets to the frame
        """
        posts_frame = tk.Frame(master=self, width=250)
        posts_frame.pack(fill=tk.BOTH, side=tk.LEFT)
        self.posts_tree = ttk.Treeview(posts_frame)
        self.posts_tree.bind("<<TreeviewSelect>>", self.node_select)
        self.posts_tree.pack(fill=tk.BOTH, side=tk.TOP, expand=True, padx=5, pady=5)

        entry_frame = tk.Frame(master=self, bg="")
        entry_frame.pack(fill=tk.BOTH, side=tk.BOTTOM, expand=False)
        
        self.editor_frame = tk.Frame(master=self)
        self.editor_frame.pack(fill=tk.BOTH, side=tk.TOP, expand=True)
        
        self.entry_editor = tk.Text(self.editor_frame, width=0)
        self.entry_editor.pack(fill=tk.BOTH, side=tk.TOP, expand=True, padx=0, pady=0)
        self.entry_editor.config(state=DISABLED)

        self.scrollbar = tk.Scrollbar(master=self.entry_editor)
        self.scrollbar.pack(side=RIGHT, fill=Y)

        send_frame = tk.Frame(master=entry_frame, bg="")
        send_frame.pack(fill=tk.BOTH, side=tk.TOP, expand=True)

        self.send_box = tk.Text(send_frame, width=0, height=5)
        self.send_box.pack(fill=tk.BOTH, side=tk.TOP, expand=True, padx=0, pady=0)
        self.send_box.insert(INSERT , "[INSERT MESSAGE]")

class Footer(tk.Frame):
    """
    A subclass of tk.Frame that is responsible for drawing all of the widgets
    in the footer portion of the root frame.
    """
    def __init__(self, root, save_callback=None, online_callback=None, add_callback=None):
        tk.Frame.__init__(self, root)
        self.root = root
        self._save_callback = save_callback
        self._online_callback = online_callback
        self._add_callback = add_callback
        # IntVar is a variable class that provides access to special variables
        # for Tkinter widgets. is_online is used to hold the state of the
        # chk_button widget. The value assigned to is_online when the chk_button
        # widget is changed by the user can be retrieved using the get()
        # function: chk_value = self.is_online.get()
        self.is_online = tk.IntVar()
        # After all initialization is complete, call the _draw method to pack
        # the widgets into the Footer instance.
        self._draw()

    def online_click(self):
        """
        Calls the callback function specified in the online_callback class attribute, if
        available, when the chk_button widget has been clicked.
        """
        if self._online_callback is not None:
            if self.is_online.get() == 0:
                value = False
            elif self.is_online.get() == 1:
                value = True
            self._online_callback(value)

    def save_click(self):
        """
        Calls the callback function specified in the save_callback class attribute, if
        available, when the save_button has been clicked.
        """
        if self._save_callback is not None:
            self._save_callback()

    def add_click(self, contact):
        if self._add_callback is not None:
            self.r_post = Post()
            self.r_post.recipient = contact.get()
            self._add_callback(self.r_post)
            self.contacts_window.destroy()

    def set_status(self, message):
        """
        Updates the text that is displayed in the footer_label widget
        """
        self.footer_label.configure(text=message)

    def add_contact_window(self):
        self.contacts_window = Toplevel(main)
        self.contacts_window.geometry("250x120")

        recipient = tk.StringVar()

        contact_label = ttk.Label(self.contacts_window, text='Enter contact name')
        contact_label.pack(pady=8)
        contact_entry = ttk.Entry(self.contacts_window, textvariable=recipient, width=28)
        contact_entry.pack()

        save_button = ttk.Button(master=self.contacts_window, text='Add')
        save_button.pack(ipady=3, pady=3, expand=True)
        save_button.configure(command=lambda: self.add_click(recipient))

    def _draw(self):
        """
        Call only once upon initialization to add widgets to the frame
        """
        save_button = tk.Button(master=self, text="Send", width=20)
        save_button.configure(command=self.save_click)
        save_button.pack(fill=tk.BOTH, side=tk.RIGHT, padx=5, pady=5)

        add_contact_button = tk.Button(master=self, text="Add contact", width=27)
        add_contact_button.configure(command=self.add_contact_window)
        add_contact_button.pack(fill=tk.BOTH, side=tk.LEFT, padx=5, pady=5)

        self.footer_label = tk.Label(master=self, text="")
        self.footer_label.pack(fill=tk.BOTH, side=tk.LEFT, padx=5)

class MainApp(tk.Frame):
    """
    A subclass of tk.Frame that is responsible for drawing all of the widgets
    in the main portion of the root frame. Also manages all method calls for
    the NaClProfile class.
    """
    def __init__(self, root):
        tk.Frame.__init__(self, root)
        self.root = root
        self._is_online = False

        # Initialize a new NaClProfile and assign it to a class attribute.
        self._current_profile = NaClProfile()

        # After all initialization is complete, call the _draw method to pack
        # the widgets into the root frame.
        self._draw()
        self.recipient = []

    def new_profile(self):
        """
        Creates a new DSU file when the 'New' menu item is clicked.
        """
        try: 
            filename = tk.filedialog.asksaveasfile(filetypes=[('Distributed Social Profile', '*.dsu')])
            self._profile_filename = filename.name
            self._current_profile = NaClProfile()
            self._current_profile.keypair = self._current_profile.generate_keypair()
            self._current_profile.import_keypair(self._current_profile.keypair)
            self.body.reset_ui()
        except AttributeError:
            pass

    def open_profile(self):
        """
        Opens an existing DSU file when the 'Open' menu item is clicked and loads the profile
        data into the UI.
        """
        try:
            filename = tk.filedialog.askopenfile(filetypes=[('Distributed Social Profile', '*.dsu')])
            self._profile_filename = filename.name
            self._current_profile = NaClProfile()
            self._current_profile.load_profile(self._profile_filename)
            self._current_profile.import_keypair(self._current_profile.keypair)
            self.dm = ds_messenger.DirectMessenger(SERVER, self._current_profile.username, self._current_profile.password)
            self.dm.send("","")
            self.body.reset_ui()
            self.body.set_posts(self._current_profile._posts)
        except AttributeError:
            pass

    def close(self):
        """
        Closes the program when the 'Close' menu item is clicked.
        """
        self.root.destroy()

    def save_to_file(self):
        p = Path(self._profile_filename)
        if os.path.exists(p) and p.suffix == '.dsu':
            try:
                f = open(p, 'w')
                json.dump(self._current_profile.__dict__, f)
                f.close()
            except Exception:
                raise DsuFileNotFoundError("Failed to find DSU file.")
        else:
            raise DsuFileNotFoundError("Failed to find DSU file.")

    def save_profile(self):
        """
        Saves the text currently in the entry_editor widget to the active DSU file.
        """
        self.body.entry_editor.configure(state="normal")
        post = self.body.get_text_entry()

        self.body.send_box.delete(0.0, 'end')
        self.body.send_box.insert(0.0, "")

        if post.strip() != "":
            try:
                self.footer.r_post.set_entry(post)
            except AttributeError:
                pass
            self.body.entry_editor.insert(INSERT, self._current_profile.username + ': ' + post + '\n\n')
            self.publish(post)
        for idx, contact in enumerate(self.body.recipient):
            if self.body.curr_recipient in contact:
                self.body.recipient[idx][self.body.curr_recipient].append(f"{self._current_profile.username}: " + post)
        
        self._current_profile._posts = self.body.recipient
        self.save_to_file()
        self.body.entry_editor.configure(state="disabled")

    def publish(self, post:Post):
        self.dm.send(post, self.body.curr_recipient)
    
    def receive(self):
        count = 0
        try:
            curr_received = self.dm.retrieve_new()
            if curr_received != []:
                msg, recipient = curr_received[0].message, curr_received[0].recipient
                for idx, contact in enumerate(self.body.recipient):
                    if recipient in contact and count == 0:
                        self.body.recipient[idx][recipient].append(recipient + ": " + msg)
                        self.body.entry_editor.configure(state="normal")
                        self.body.insert_text_entry(msg, recipient)
                        self.body.entry_editor.configure(state="disabled")
                        count += 1
        except:
            pass
        self._current_profile._posts = self.body.recipient
        try:
            self.save_to_file()
        except AttributeError:
            pass
        self.root.after(1500, self.receive)

    def online_changed(self, value:bool):
        """
        A callback function for responding to changes to the online chk_button.
        """
        self._is_online = value
        print(self._is_online)

    def close_settings(self):
        """
        Closes the settings window when the 'Save' button is pressed and populates new info.
        """
        if self.new_username != None and self.new_password != None and self.new_server != None:
            self._current_profile.username = self.new_username.get()
            self._current_profile.password = self.new_password.get()
            self._current_profile.dsuserver = self.new_server.get()
            self.dm = ds_messenger.DirectMessenger(SERVER, self._current_profile.username, self._current_profile.password)
            self.dm.send("","")
        try:
            self._current_profile.save_profile(self._profile_filename)
        except AttributeError:
            pass

        self.settings_window.destroy()

    def disableSaveSettings(self):
        """
        Does not let user save new username/password unless they create/open a DSU file.
        """
        self.save_button_settings["state"] = "disabled"

    def settings_window(self):
        """
        Settings window from the menu bar.
        """
        settings = ttk.Frame(main)
        settings.pack()

        self.settings_window = Toplevel(settings)
        self.settings_window.geometry('250x200')

        self.new_username = tk.StringVar()
        self.new_password = tk.StringVar()
        self.new_server = tk.StringVar()

        usrname_label = ttk.Label(self.settings_window, text='Enter username')
        usrname_label.pack(pady=5)
        usrname_entry = ttk.Entry(self.settings_window, textvariable=self.new_username)
        usrname_entry.pack()

        pwd_label = ttk.Label(self.settings_window, text='Enter password')
        pwd_label.pack(pady=5)
        pwd_entry = ttk.Entry(self.settings_window, textvariable=self.new_password)
        pwd_entry.pack()

        srv_label = ttk.Label(self.settings_window, text='Enter dsuserver')
        srv_label.pack(pady=5)
        srv_entry = ttk.Entry(self.settings_window, textvariable=self.new_server)
        srv_entry.pack() 

        self.save_button_settings = ttk.Button(master=self.settings_window, text='Save')
        self.save_button_settings.pack(ipady=5, pady=10, expand=True)
        self.save_button_settings.configure(command=self.close_settings)

    def _draw(self):
        """
        Call only once, upon initialization to add widgets to root frame
        """
        # Builds a menu and adds it to the root frame.
        menu_bar = tk.Menu(self.root)
        self.root['menu'] = menu_bar
        menu_file = tk.Menu(menu_bar)
        menu_bar.add_cascade(menu=menu_file, label='File')
        menu_file.add_command(label='New', command=self.new_profile)
        menu_file.add_command(label='Open...', command=self.open_profile)
        menu_file.add_command(label='Close', command=self.close)
        menu_bar.add_command(label='Settings', command=self.settings_window)

        # The Body and Footer classes are initialized and packed into the
        # root window.
        self.body = Body(self.root, self._current_profile, self._current_profile)
        self.body.pack(fill=tk.BOTH, side=tk.TOP, expand=True)

        self.footer = Footer(self.root, save_callback=self.save_profile, online_callback=self.online_changed, add_callback=self.body.insert_post)
        self.footer.pack(fill=tk.BOTH, side=tk.BOTTOM)

if __name__ == "__main__":
    # All Tkinter programs start with a root window. We will name ours 'main'.
    main = tk.Tk()

    # 'title' assigns a text value to the Title Bar area of a window.
    main.title("ICS 32 Distributed Social Demo")

    main.geometry("720x480")

    # Adding this option removes some legacy behavior with menus that modern
    # OSes don't support.
    main.option_add('*tearOff', False)

    # Initializes the MainApp class, which is the starting point for the widgets
    # used in the program. All of the classes that we use, subclass Tk.Frame,
    # since our root frame is main, we initialize the class with it.
    m = MainApp(main)

    # When update is called, we finalize the states of all widgets that have
    # been configured within the root frame. Here, Update ensures that we get an
    # Haccurate width and height reading based on the types of widgets we have
    # used. minsize prevents the root window from resizing too small.
    main.update()
    main.minsize(main.winfo_width(), main.winfo_height())
    # And finally, this starts up the event loop for the program.
    main.after(1500, m.receive)
    main.mainloop()
