__a6.py__ = Main module where all other modules are imported and where the program runs. <br />
__ds_messenger.py__ = Handles messages sent to server and to recipients. <br />
__ds_message_protocol.py__ = Reponsible for handling protocols within ds_messenger.py <br />
__NaClDSEncoder.py__ = Handles generating keypairs (private, public), encodes them, encrypts messages, <br />
and creates Boxes (enables messages to be encrypted and decrypted). <br />
__NaClProfile.py__ Inherits from profile class that mainly concerns with decrypting data. <br />
__Profile.py__ = Profile class for Posts and Profile. <br />
__test_ds_messenger_protocol.py__ = unittests for __ds_message_protocol.py__. <br />
__test_ds_messenger.py__ = unittests for __ds_messenger.py__. <br />

## GUI Process
### Menu Options 
#### Files
Within the __files__ menu, there are three options: __New__, __Open__, and __Close__. <br />
__New__ provides the option for the user to create a new file where messages, and other user information will be stored. <br />
__Open__ allows the user to open up a new file where prepended information such as messages are loaded into the program. <br />
__Close__ button exits the program and as a result, the GUI. <br />

#### Settings
In the settings menu, you are able to change your username, password, and dsuserver. If you decide to change your information, be sure to type all the given criterias (username, password, and dsuserver) or else empty responses will not be valid!

### Add Contact and Send
Within the "Footer" of the GUI, there are two options: __Add Contact__ and __Send__. <br />
__Add Contact__ allows the user to type in a recipient which will then be appended to the Tree View for chatting purposes. <br />
__Send__ allows the to relay the message to the added recipient listed on the Tree View. <br />

## How the Program Works
The program starts up from the __a6.py__ module where most of the GUI is configured. Once you start up the program from the __a6.py__ module, a window pops up as an user interface. Within __a6.py__, three classes are present within the module: the _Body_, _Footer_, and _Main_. The _Body_ class is responible for responsible for drawing all of the widgets in the body portion of the root frame. _Footer_ is responsible for responsible for drawing all of the widgets in the __footer__ portion of the root frame. _Main_ is responsible for drawing all of the widgets in the main portion of the root frame. Also manages all method calls for the NaClProfile class. __a6.py__ in general, calls on other other modules and implements them to create the GUI chat. <br />

### Getting Started
_To get started_, you will need to create a _file_. If you're on windows, make sure to include the suffix ".dsu". If on MAC, no need. After that, you will be bought back to the GUI. Next, head over to the __Settings__ menu. Type in your _username, password, and dsuserver_. Then you will then need to __Add Contact__ located on the bottom left. Type in the recipient you wish to text and submit it. You should be able to view the recipients username within the Tree View box located on the left side of the GUI. Lastly, type in a message on thetext box located right above the __Send__ button. Lastly, press the __Send__ button to relay typed message to selected recipient from the Tree View. Your message should appear on the main text box preprended by your username. Congrats, you sent your first message!  <br />
