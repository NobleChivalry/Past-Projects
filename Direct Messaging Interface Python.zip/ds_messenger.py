# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

import socket, ds_message_protocol, json

PORT = 3021

class DirectMessage:
  def __init__(self):
    self.recipient = None
    self.message = None
    self.timestamp = None

class DirectMessenger:
  def __init__(self, dsuserver=None, username=None, password=None):
    self.dsuserver = dsuserver
    self.username = username
    self.password = password
    self.token = None

  def connectServer(self, server:str, port:int):
    """
    Connects to server.
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((server, port))
        return sock
    except:
        print("\nInvalid server and/or port, try again.")
        return None

  def joinServer(self, connection:socket, username:str, password:str) -> all:
      """
      Joins the server.
      """
      send = connection.makefile('w')
      recv = connection.makefile('r')

      join_msg = ds_message_protocol.join(self.username, self.password)
      send.write(join_msg + '\r\n')
      send.flush()

      srv_msg = recv.readline()
      typeError, error_message, self.token = ds_message_protocol.extract_json(srv_msg) 

      return send, recv

  def send(self, message:str, recipient:str) -> bool:
    """
    Returns true if message successfully sent, false if send failed.
    """
    connection = self.connectServer(self.dsuserver, PORT)
    if connection == None:
        return False
    try:
        send, recv = self.joinServer(connection, self.username, self.password)
        
        directmessage = ds_message_protocol.sendDM(message, recipient, self.token)
        send.write(directmessage + '\r\n')
        send.flush()

        srv_msg = recv.readline()

        connection.close()
    except:
        connection.close()
        return False
    else:
        return True

  def retrieve_new(self) -> list:
    """
    Returns a list of DirectMessage objects containing all new messages.
    """
    connection = self.connectServer(self.dsuserver, PORT)

    if connection == None:
        return False

    send = connection.makefile('w')
    recv = connection.makefile('r')

    json_new_msg = ds_message_protocol.reqUnread(self.token)

    send.write(json_new_msg + '\r\n')
    send.flush()

    srv_msg = recv.readline()

    new_msg = json.loads(srv_msg)['response']['messages']
    if new_msg != []:
        dm = DirectMessage()
        dm.recipient = new_msg[0]['from']
        dm.message = new_msg[0]['message']
        dm.timestamp = new_msg[0]['timestamp']
        new_msg = [dm]

    connection.close()
    return new_msg

  def retrieve_all(self) -> list:
    """
    Returns a list of DirectMessage objects containing all messages.
    """
    connection = self.connectServer(self.dsuserver, PORT)

    if connection == None:
        return False

    send = connection.makefile('w')
    recv = connection.makefile('r')

    json_all_msg = ds_message_protocol.reqAll(self.token)

    send.write(json_all_msg + '\r\n')
    send.flush()

    srv_msg = recv.readline()

    all_msg_obj = []
    all_msg = json.loads(srv_msg)['response']['messages']
    if all_msg != []:
        for msg_obj in all_msg:
            dm = DirectMessage()
            dm.recipient = msg_obj['from']
            dm.message = msg_obj['message']
            dm.timestamp = msg_obj['timestamp']
            all_msg_obj.append(dm)
    
    connection.close()
    return all_msg_obj
