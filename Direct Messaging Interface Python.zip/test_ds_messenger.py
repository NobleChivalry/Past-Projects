# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

import socket, ds_message_protocol, json
from ds_messenger import DirectMessage, DirectMessenger
import unittest

SERVER = "168.235.86.101"
PORT = 3021

DirectMessage.recipient = 'Recipient'
DirectMessage.message = 'Message'

dm = DirectMessenger(SERVER, 'randyusername', 'Password')

class ds_messenger_Test(unittest.TestCase):
    def test_send(self):
        ran = dm.send(DirectMessage.recipient, DirectMessage.message)

        self.assertEqual(ran, True)
    
    def test_retrieve_new(self):
        dm.send(DirectMessage.message, DirectMessage.recipient)
        
        self.assertIsInstance(dm.retrieve_new(), list)
    
    def test_retrieve_all(self):
        dm.send(DirectMessage.message, DirectMessage.recipient)
        
        self.assertIsInstance(dm.retrieve_all(), list)

if __name__ == '__main__':
    unittest.main()
