# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

import unittest
import json
import ds_message_protocol
from Profile import Post, Profile


profile = Profile(username='Username', password='Password')
profile.bio = 'Bio'
post = Post('Message')

class ds_protocol_Test(unittest.TestCase):
    def test_join(self):
        join_msg = ds_message_protocol.join(profile.username, profile.password)

        self.assertEqual(join_msg, json.dumps({"join": {"username": f'{profile.username}', "password": f'{profile.password}', "token": ""}}))

    def test_post(self):
        post_msg = ds_message_protocol.post('Message', '')

        self.assertIsInstance(post, Post)
        self.assertEqual(json.loads(post_msg)['post']['entry'], 'Message')

    def test_bio(self):        
        bio_msg = ds_message_protocol.bio(profile.bio, '')

        self.assertEqual(bio_msg, json.dumps({'token': '', 'bio': {'entry': profile.bio, 'timestamp': None}}))
    
    def test_sendDM(self):
        sendDM = ds_message_protocol.sendDM('Message', 'Recipient', '')

        self.assertEqual(json.loads(sendDM)['directmessage']['entry'], 'Message')
        self.assertEqual(json.loads(sendDM)['directmessage']['recipient'], 'Recipient')

    def test_reqUnread(self):
        req = ds_message_protocol.reqUnread('')

        self.assertEqual(req, '{"token": "", "directmessage": "new"}')

    def test_reqAll(self):
        req = ds_message_protocol.reqAll('')

        self.assertEqual(req, '{"token": "", "directmessage": "all"}')


if __name__ == '__main__':
    unittest.main()
