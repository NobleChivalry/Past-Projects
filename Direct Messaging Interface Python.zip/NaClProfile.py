# Eric Truong
# ewtruong@uci.edu
# 13059272

# Raymond Chou
# chour3@uci.edu
# 20123271

# Noah Wang
# botaow3@uci.edu
# 32603123

import nacl.utils
from nacl.public import PrivateKey, PublicKey, Box

from Profile import Profile
from Profile import Post
from Profile import DsuFileError
from Profile import DsuProfileError
import json, time, os
from pathlib import Path
import ds_messenger
import NaClDSEncoder

class NaClProfile(Profile):
    def __init__(self):
        """
        Creates an NaClProfile object.
        """
        public_key:str
        private_key:str
        keypair:str
        super().__init__()

    def generate_keypair(self) -> str:
        """
        Generates a new public encryption key using NaClDSEncoder.
        :return: str    
        """
        obj = NaClDSEncoder.NaClDSEncoder()
        obj.generate()
        self.keypair = obj.keypair
        return self.keypair

    def import_keypair(self, keypair: str):
        """
        Imports an existing keypair. Useful when keeping encryption keys in a
        location other than the DSU file created by this class.
        """
        keypair = keypair.split("=")
        keypair = keypair[:-1]
        public_key = keypair[0] + "="
        private_key = keypair[1] + "="
        self.public_key = public_key
        self.private_key = private_key

    def add_post(self, post: Post) -> None:
        self._posts.append(post)

    def get_posts(self):
        dm = ds_messenger.DirectMessenger(self.dsuserver, self.username, self.password)
        dm.send("Hello world!", "ohhimark")
        lis = dm.retrieve_all()
        return lis

    def load_profile(self, path):
        p = Path(path)
        if os.path.exists(p) and p.suffix == '.dsu':
            try:
                f = open(p, 'r')
                obj = json.load(f)
                self.username = obj['username']
                self.password = obj['password']
                self.dsuserver = obj['dsuserver']
                self.public_key = obj['public_key']
                self.private_key = obj['private_key']
                self.keypair = obj['keypair']
                for post_obj in obj['_posts']:
                    self._posts.append(post_obj)
                f.close()
            except Exception as ex:
                raise DsuProfileError(ex)
        else:
            raise DsuFileError()

    def encrypt_entry(self, entry:str, public_key:str) -> bytes:
        """
        Used to encrypt messages using a 3rd party public key, such as the one that
        the DS server provides.
        :return: bytes 
        """
        obj = NaClDSEncoder.NaClDSEncoder()
        e_public_key = obj.encode_public_key(public_key)
        e_private_key = obj.encode_private_key(self.private_key)
        entry = obj.encrypt_message(obj.create_box(e_private_key, e_public_key), entry)
        return entry
