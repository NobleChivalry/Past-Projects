#Need to import sys for commandline arguments.
import sys

#Time complexity is O(n) because it goes over every character in the file once.
def tokenize(TextFilePath):
    try:
        tokens = []
        current_token = ""
        with open(TextFilePath, 'r') as file:
            while True:
                char = file.read(1)
                if char == '': #Ends at EOF
                    break

                if (('a' <= char <= 'z') or ('A' <= char <= 'Z') or ('0' <= char <= '9')):
                    current_token += char.lower()
                else: #Ends when not alphanumeric
                    if current_token != "":
                        tokens.append(current_token)
                        current_token = "" #Resets for next token
    #Exception handlers to battle bad input
    except FileNotFoundError:
        print("Sorry, but that file could not be found!")
        return []
    except UnicodeDecodeError:
        print("Sorry, but that file could not be read, either because of its file type or some kind of illegal symbol!")
        return []
    except BaseException:
        print("Sorry, but that is an invalid input!")
        return []
    return tokens

#Time complexity is O(n) because it goes over every token in the list twice,
#which would still mean it runs in linear time.
def computeWordFrequencies(ListOfTokens):
    dicti = {}
    for token in ListOfTokens:
        dicti[token] = 0 #Sets all frequencies to 0 first.
    for token in ListOfTokens:
        dicti[token] += 1
    return dicti

#Time complexity is likely O(nlog(n)) due to the sorting algorithm's runtime
#being dominant in terms of time complexity.
def printFrequencies(MapOfFrequencies):
    MapOfFrequencies = sorted(MapOfFrequencies.items(), key = lambda x: (-x[1], x[0]))
    for key, value in MapOfFrequencies:
        print(key, end = ""), print(" = ", end = ""), print(value)

#This is what takes in the commandline argument.
if __name__ == "__main__":
    try:
        printFrequencies(computeWordFrequencies(tokenize(sys.argv[1])))
    except:
        print("Sorry, but this program actually requires 1 input file.")
