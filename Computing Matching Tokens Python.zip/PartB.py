#Need to import sys for commandline arguments.
import sys

#Imports functions from PartA
from PartA import tokenize
from PartA import computeWordFrequencies

#Time complexity is O(n) because a nested loop was not used, since it would
#have been inefficient to use one.
def NumOfMatchingTokens(File1, File2):
    sets = set()
    #Only interested in the keys in the maps.
    for word in computeWordFrequencies(tokenize(File1)).keys():
        #Only includes the word if they are found in both files.
        if word in computeWordFrequencies(tokenize(File2)).keys():
            sets.add(word)
    return len(sets)

#This is what takes in the commandline argument.
if __name__ == "__main__":
    try:
        print(NumOfMatchingTokens(sys.argv[1], sys.argv[2]))
    except:
        print("Sorry, but this program actually requires 2 input files.")
