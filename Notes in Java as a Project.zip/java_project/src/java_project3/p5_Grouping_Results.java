//REMEMBER: Map<Integer, List<String>> result = wordList.stream().collect(Collectors
//.groupingBy(w -> w.length())); groups the elements by their lengths.

//Note: Basically, converting stream to a map object.

/*

Results are usually values or collections. Sometimes, we can to split a result into groups instead. We do
this with the stream.collect(Collectors.groupingBy(lambda)) method, which returns an object of type
Map<Object, collection>. The lambda is what makes the key. Key is paired with associated value in a
collection. Collection is list by default.

stream.collect(Collectors.groupingBy(lambda), Collectors.toSet()) is used to change the collector that the
elements are stored in.

stream.collect(Collectors.groupingBy(lambda), Collectors.counting()) is used to the keys to the amount of
elements inside of their associated collection. Store in something like Map<String, Long> variable.

stream.collect(Collectors.groupingBy(lambda), Collectors.summingLong(lambda)) is used to set the keys to the
sum of values found in the second lambda expression. Example, each key can be associated with the length of
the word. May use Map<String, Long>, Map<String, Integer>, Map<String, Double>. summingInt and summingDouble
also exist.

averagingInt, averagingDouble, and averagingLong also exist. Both these and Collectors.summing methods end
up returning 0 if the group is empty. String::length can be used to replace w -> w.length(). Returns the
average of each number of letters for each word in each collection.

maxBy and minBy methods require a comparator. Returns max/min value of each associated collection. Returns
Optional objects for each key.

*/

package java_project3;

import java.util.Map;
import java.util.List;
import java.util.Set;

import java.util.stream.Stream;
import java.util.Optional;
import java.util.stream.Collectors;

public class p5_Grouping_Results {
	public static void main(String[] args) {
		Stream<String> stream = Stream.of("Mario", "Luigi", "Toad");
		Map<String, List<String>> map = stream.collect(Collectors.groupingBy(w -> w.substring(0, 1)));
		System.out.println(map); //{T=[Toad], L=[Luigi], M=[Mario]}
		System.out.println(map.get("T").get(0)); //Toad
		
		Stream<String> stream2 = Stream.of("Mario", "Luigi", "Toad");
		Map<String, Set<String>> map2 = stream2.collect(Collectors.groupingBy(w -> w.substring(0, 1), Collectors.toSet()));
		System.out.println(map2); //{T=[Toad], L=[Luigi], M=[Mario]}
		System.out.println(map2.get("T")); //[Toad] (Set)
		
		Stream<String> stream3 = Stream.of("Mario", "Luigi", "Toad");
		Map<String, Long> map3 = stream3.collect(Collectors.groupingBy(w -> w.substring(0, 1), Collectors.counting()));
		System.out.println(map3); //{T=1, L=1, M=1}
		System.out.println(map3.get("T")); //1
		
		Stream<String> stream4 = Stream.of("Mario", "Luigi", "Toad");
		Map<String, Long> map4 = stream4.collect(Collectors.groupingBy(w -> w.substring(0, 1), Collectors.summingLong(w -> w.length())));
		System.out.println(map4); //{T=4, L=5, M=5}
		System.out.println(map4.get("T")); //4
		
		Stream<String> stream5 = Stream.of("Mario", "Luigi", "Toad");
		Map<String, Double> map5 = stream5.collect(Collectors.groupingBy(w -> w.substring(0, 1), Collectors.averagingDouble(w -> w.length())));
		System.out.println(map5); //{T=4.0, L=5.0, M=5.0} (only 1 object in each collection)
		System.out.println(map5.get("T")); //4.0
		
		Stream<String> stream6 = Stream.of("Mario", "Luigi", "Toad");
		Map<String, Optional<String>> map6 = stream6.collect(Collectors.groupingBy(w -> w.substring(0, 1), Collectors.maxBy((v, w) -> v.length() - w.length())));
		System.out.println(map6); //{T=Optional[Toad], L=Optional[Luigi], M=Optional[Mario]}
		System.out.println(map6.get("T")); //Optional[Toad]
	}
}