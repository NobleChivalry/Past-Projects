/*

Lambda expressions (ex: w -> w.length() > 10). They're like short static methods. Left side is parameter
variable, right side is code to be operated on parameter. Return types assumed by compilers, can specify if
you want (ex: (String w) -> w.length() > 10). Parameter, operation.

Multiple parameters, enclose them in parentheses and add commas (ex: (v, w) -> v.length() - w.length()).
Useful for things like applying different sorting techniques for the sorted() function on Stream objects.
Sorts from lowest length objects to highest length objects. sorted() just lexicographic.

Example of complex lambda expressions with longer body that computes a difference between lengths of words:
(v, w) ->
{
	int difference = v.length() - w.length();
	return difference;
}

*/

//-----------------------------------------------------------------------------------------------------------

/*

null is commonly used to denote the absence of a result. However, the existence of null can lead to us
bumping into NullPointerException exceptions. Optional class of Stream library used when a result may not
be present.

Optional.of(x) method returns an Optional object containing an object.
Optional.empty() method returns an empty Optional object.
stream.findFirst() method returns an Optional object that contains the first object that is in the stream.
optional.orElse("") method returns whatever the optional object contains. If it is empty, return "".
optional.get() method is an unsafe version of orElse. If empty, raises exception.
optional.ifPresent(lambda) method executes lambda expression if Optional object is not empty.
optional.isPresent() method returns whether or not the optional object carries an object.

Note: orElse method is basically a get method.
orElse and get return non-Optional objects.

*/

package java_project3;

import java.util.stream.Stream;
import java.util.Optional;

public class p2_Lambdas_and_Optionals {
	public static void main(String[] args) {
		Stream<String> stream = Stream.of("Mario", "Luigi", "Toad"); //Constructing an Optional object.
		Optional<String> optional = stream.filter(w -> w.length() > 10).findFirst();
		Optional<Double> optional2 = Optional.of(Math.sqrt(3.14)); //Constructing one from scratch.
		Optional<Double> optional3 = Optional.empty(); //Constructing an empty Optional object.
		System.out.println(optional2.get()); //Causes an exception if Optional object is empty.
		
		String value = optional.orElse(""); //Returns "".
		
		String[] array = new String[1];
		optional.ifPresent(w -> array[0] = w); //Doesn't execute lambda.
		
		if (optional.isPresent()) { //Nothing is present in the empty Optional object.
			System.out.println("amogus"); //Doesn't print anything.
		}
	}
}