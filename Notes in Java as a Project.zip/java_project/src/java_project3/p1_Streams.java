//REMEMBER: Use long variables to store the amount of characters in a stream.

//REMEMBER: Common error is using terminated streams. Terminal operations use up streams, need a new stream.
//Ex: toArray OR collect OR count (operations that "convert" streams).

/*

Streams used to process data by specifying actions to be done with that data. Streams library used to
implement the actions using lazy execution, which can skip unneeded steps and split work over multiple
processors (good for processing large amounts of data).

Stream.of(x, y, z) used to create a stream object. Can either list all elements or a single array.
collection.stream() used to create a stream object with the elements of a collection type.
stream.filter(lambda) used to create a new stream object with a filter.
stream.limit(int) used to create a new stream object of only the first "x" elements
stream.count() used to return number of elements in stream.

Similar to collections, but doesn't store their own data. Works well with lambda expressions (->). Streams
are immutable (filter method just makes new streams). Stream processing is lazy. To remove things from
streams, just create a new stream and filter the to-be-removed things out.

Lambda expressions have two parameters, types are assumed, convention to use lowercase letters. First
parameter establishes variable for each element, second parameter is the condition that the elements need to
pass (returns true or false).

*/

package java_project3;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;

import java.util.stream.Stream;
import java.util.stream.Collectors;

public class p1_Streams {
	public static void main(String[] args) {
		//Basic commands for Stream class.
		ArrayList<String> array = new ArrayList<>();
		array.add("Teeeeeeeen");
		array.add("Eleveeeeeen");

		Stream<String> words = array.stream(); //Create a stream object by converting an array list.
		long counts = words //long is a numeric class good for big numbers.
				.filter(w -> w.length() > 10) //Only allows words with higher length of 10.
				.count(); //Counts how many words apply to the filter.
		System.out.println(counts); //Prints 1.
		
		ArrayList<String> array2 = new ArrayList<>();
		array2.add("Teeeeeeeen");
		array2.add("Eleveeeeeen");
		
		Stream<String> fiveWords = array2.stream() //Note: Calling methods on a stream object always.
				.filter(w -> w.length() > 10) //Returns a new stream that applied the filter.
				.limit(5); //Returns a new stream that only includes the first 5 elements.
		
		//--------------------------------------------------------------------------------------------------
		
		//Creating Stream objects.
		//long count = list.stream().filter(w -> w.length() <= 3).count();
		//long count = Stream.of(array).filter(w -> w.length() <= 3).count();
		Stream<String> stream = Stream.of("Mario", "Luigi", "Toad"); //Creates a stream object from scratch.
		Stream<Integer> stream2 = Stream.of(1, 2, 3); //Can't create streams of primitive types.
		String[] array3 = {"A", "B", "C"};
		Stream<String> stream3 = Stream.of(array3); //Can create a stream object of elements in an array.
		ArrayList<String> listArray = new ArrayList<>();
		listArray.add("A");
		listArray.add("B");
		Stream<String> stream4 = listArray.stream(); //Can create a stream object of elements in collection.
		
		//Creating special Stream objects.
		/*
		String filename = . . .; //Creating a line stream using a file. Contains lines of text in file.
		try(Stream<String> lineStream = Files.lines(Path.get(filename))) {
			. . .
		}
		*/
		//Starts at 0, keeps generating more and iterating by 1 each time.
		Stream<Integer> integers = Stream.iterate(0, n -> n + 1); //Creating an infinite stream.
		//Causes operations to be distributed over available processors.
		Stream<String> parStream = stream.parallel(); //Can create a parallel stream with any stream.
		
		//--------------------------------------------------------------------------------------------------
		
		//Collecting results of a Stream object. Note: There will be an exception, stream was closed.
		String[] resultA = stream.toArray(String[]::new); //String[]::new is a new constructed array.
		List<String> resultL = stream.collect(Collectors.toList()); //Use collect method for lists and sets.
		Set<String> resultS = stream.collect(Collectors.toSet()); //Must import Collectors class.
		String result = stream.collect(Collectors.joining(", ")); //Collected into string with a separator.
		
		//--------------------------------------------------------------------------------------------------
		
		//There are even more Stream transformations to know of.
		//map transforms a stream by applying a method to each of its elements. CHANGES the values.
		Stream<String> lStream = stream.map(w -> w.toLowerCase()); //Returns stream of all lowercase words.
		Stream<Integer> cStream = stream.map(w -> w.length()); //Returns stream of lengths of all words.
		
		Stream<String> fStream = stream.skip(2); //Returns stream of elements after skipping the first 2.
		Stream<String> dStream = stream.distinct(); //Returns stream of only unique elements.
		Stream<String> sStream = stream.sorted(); //Returns sorted stream, requires Comparable interface.
		//Stream<String> s2Stream = stream.sorted(comparator/lambda); //Uses different sorting method.
	}
}