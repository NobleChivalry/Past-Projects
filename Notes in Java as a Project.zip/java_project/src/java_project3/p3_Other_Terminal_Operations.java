//REMEMBER: If input is a stream, just convert input to a list and convert that list each time you want
//to reuse that stream. This is the way around terminal operations.

/*

Other terminal operations:

stream.findAny() method is similar to findFirst, but it returns any match and is faster on parallel streams,
still returns type Optional.

stream.max(lambda) method used to return Optional object that contains the highest value (later in
dictionary order for strings). Requires comparator ((v, w) -> v.length() - w.length() is dictionary).

stream.allMatch(lambda) returns whether or not all elements match with expression. Boolean.
stream.anyMatch(lambda) returns whether or not any elements match with expression. Boolean.
stream.noneMatch(lambda) returns whether or not all elements do not match with expression. Boolean.

Note: Can use String methods str.endsWith("str") and str.startsWith("str") in lambda expressions.
Can use anyMatch instead of using filter and then findAny.

*/

package java_project3;

import java.util.stream.Stream;

public class p3_Other_Terminal_Operations {
	public static void main(String[] args) {
		Stream<String> stream = Stream.of("Mario", "Luigi", "Toad");
		String result = stream.parallel().limit(2).findAny().orElse(""); //findAny method.
		System.out.println(result); //Luigi always.
		
		Stream<String> stream2 = Stream.of("Mario", "Luigi", "Toad");
		String result2 = stream2.max((v, w) -> v.length() - w.length()).orElse("");
		System.out.println(result2); //Mario comes after Luigi in dictionary.
		
		//Note: Causes exception because stream3 already terminated.
		Stream<String> stream3 = Stream.of("Mario", "Luigi", "Toad");
		boolean result3 = stream3.allMatch(w -> w.contains("i")); //false because Toad has no "i".
		boolean result4 = stream3.anyMatch(w -> w.contains("d")); //true because at least Toad has "d".
		boolean result5 = stream3.noneMatch(w -> w.contains("W")); //true because no one has "W".
	}
}