/*

Streams are like collections, but don't store their own data. They use lambda expressions, are immutable,
use lazy processing, and simply create new streams when executing non-terminal operations. Has a generic
type parameter. Most terminal operations are ones that "convert" streams.

Lambda expressions have two parameters, the type of them being assumed. First establishes the variable,
second is the condition being used with the variable.

Stream.of(x, y, z) OR Stream.of(array) manually creates a stream.
collection.stream() converts a collection into a stream.
stream.filter(lambda) filters out elements that don't match the lambda.
stream.limit(int) returns a new stream with only the first "int" elements.
stream.count() returns the number of elements in a stream (return as a long).
stream.map(lambda) converts old elements into something else with the lambda.
stream.skip(int) returns a new stream without the first "int" elements.
stream.distinct() returns a new stream with only the unique elements.
stream.sorted() returns sorted version of stream, requires Comparable interface implementation.

stream.toArray(String[]::new) //Converts to string array.
stream.collect(Collectors.toList()) //Converts to list.
stream.collect(Collectors.toSet()) //Converts to set.
stream.collect(Collectors.joining(", ")) //Converts to string with optional separator.

(v, w) -> v.length() - w.length() //Comparator that sorts from lowest to highest length objects.
stream.findFirst/Last/Any() returns Optional object that might contain an element from the stream.
Optional.of(x) //Creates Optional object with stored "x".
Optional.empty() //Creates empty Optional object.
optional.orElse("") //Returns value in optional. If empty, return "".
optional.get() //Returns value in optional, unsafe.
optional.ifPresent(lambda) //Executes lambda if not empty.
optional.isPresent() //If not empty, returns true.

stream.max/min(comparator) //Returns max/min.
stream.allMatch/anyMatch/noneMatch(lambda) //Returns boolean.
str.ends/startsWith("string") //Used in lambdas for Stream<String> objects.

Int/Double/LongStream.of(x, y, z) //Constructs stream for primitive types.
IntStream.range(1, 11) //Creates an IntStream object with numbers from 1 to 10.
stream.mapToObj/Double/Long(lambda) //Like map method, but converts to different type of stream.

//First sets keys that will determine how elements will be grouped. Second determines the value of each key.
stream.collect(Collectors.groupingBy(lambda), Collectors.method(lambda)) //Creates a Map object (fake).
stream.collect(Collectors.groupingBy(w -> w.substring(0, 1))) //Groups elements by their first letters.
stream.collect(Collectors.groupingBy(w -> w.substring(0, 1), Collectors.toSet())) //Values become sets.
Collectors.counting() //Values are lengths of each group.
Collectors.summingLong(w -> w.length()) //Values are the sum of the lengths of each group.
Collectors.averagingDouble(w -> w.length()) //Values are the average of each group using lengths.
Collectors.maxBy((v, w) -> v.length() - w.length()) //Values are the max of each group (Optionals returned).

*/