//REMEMBER: long class is for long INTEGERS, not doubles.

/*

Primitive types streams. You can have Stream that hold elements of type wrapper classes, inefficient because
you need to unbox and rebox them. Better to use IntStream, DoubleStream, and LongStream classes.

IntStream.range(a, b) generates stream of ints from a to b-1.
str.codePoints() returns unit code representation of stream in an IntStream variable.

intStream.mapToObj(lambda) returns a stream with elements of type Object after having performed an operation
on the elements that would change them into non-integer elements. Good for storing inside of Stream objects.
mapToInt, mapToDouble, and mapToLong also exist, return them to primitive type streams.

Can also use sum, average, max, and min methods on IntStream objects (no need for comparators). Returns
OptionalInt/OptionalDouble/OptionalLong types because could be empty. Need to call orElse method on them to
safely convert to type int/double/long.

stream.forEach(action) method used to perform an action, like printing, for each of the elements in a stream.

*/

package java_project3;

//import java.util.Random; //Doesn't work.

import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.stream.DoubleStream;
import java.util.stream.LongStream;

public class p4_Primitive_Type_Streams {
	public static void main(String[] args) {
		IntStream intStream = IntStream.of(1, 2, 3); //Manual construction.
		DoubleStream doubleStream = DoubleStream.of(2.5, 5, 7.5);
		LongStream longStream = LongStream.of(100, 200);
		
		IntStream stream = IntStream.range(1, 11); //Includes integers from 1 to 10.
		
		//Random generator = new Random(); //Generates infinite stream of random nums from 1 to 7.
		//IntStream dieTosses = generator.ints(1, 7);
		
		String str = "amogus";
		IntStream codePoints = str.codePoints(); //Unit code representation of a string.
		System.out.println(codePoints); //java.util.stream.IntPipeline$Head@33833882
		
		Stream<String> sStream = stream.mapToObj(n -> "a" + n);
		
		//int[] array = stream.toArray; //Doesn't work. Would return array of integers from IntStream.
		
		int num = stream.max().orElse(0); //10
	}
}