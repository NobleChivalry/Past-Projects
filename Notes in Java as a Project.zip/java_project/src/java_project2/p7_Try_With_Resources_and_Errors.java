/*

public static void capitalizeFile(String inputFile, String outputFile) {
	try (Scanner in = new Scanner(new File(inputFile))) {
    	try (PrintWriter out = new PrintWriter(outputFile)) {
        	while (in.hasNext()) {
            	out.println(in.nextLine().toUpperCase());
			}
		}
	}
	catch (FileNotFoundException e) {
		System.out.println("File " + inputFile + " was not found.");
	}
}

*/

//REMEMBER: Try-with-resources statements deal with null and closing.
//Always use try-with-resources statements when dealing with files.
//PrintWriter always goes inside of Scanner try-with-resources statements.
//Therefore, only need to have catch statement for outside statement (Scanner).

/*

There are 3 types of exceptions.

Internal Errors: Beyond our control (ex: OutOfMemoryError).

Descendants of RuntimeException/Unchecked Exceptions: Fault of programmers. Compiler doesn't check for us.
IndexOutOfBoundsException OR IllegalArgumentException.

Descendants of IOException/Checked Exceptions: Usually not our fault, out of our control.
Compiler checks for these errors and won't allow you to run the program when not fixed.
FileNotFoundException OR IOException.

*/

package java_project2;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class p7_Try_With_Resources_and_Errors {
	//Tells compiler you are aware there might be exceptions. If they come up, terminate the method.
	//Add "throws" keyword to method header. Will have to be handled elsewhere if not caught.
	public static void main2() throws IllegalArgumentException, IndexOutOfBoundsException {
	}
	
	//REMEMBER: Try-with-resources statement also can be used to avoid any null elements in an array
	//when iterating over them.
	public static void main(String[] args) throws FileNotFoundException { //Need this for "out".
		//Need to create a PrintWriter OR Scanner object here.
		try (PrintWriter out = new PrintWriter("output.txt")) {
			out.print("amogus");
		} //Makes sure to automatically close whatever object that opened.
		
		//Able to throw the custom exception from p8.
		throw new p8_Custom_Exception("amogus");
	}
}