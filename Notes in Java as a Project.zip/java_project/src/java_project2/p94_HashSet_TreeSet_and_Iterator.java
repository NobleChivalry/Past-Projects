/*

Set: Automatically ordered in a way that maximizes inefficiency. We can never order it, it is hence
deemed to be unordered. Inserting and removing elements from a set is more efficient than with a list.
Sets do not accept duplicate values. Can be used in enhanced for loops.

There are two concrete classes that implement Set, being HashSet and TreeSet. Arranges elements, so that
they can be located quickly.

-

HashSet: Hash table groups elements into small groups if they share similar integer hash codes with the
other elements. All objects in a hash table must have implemented the hashCode method and equals method
in their classes. Already included in many built-in Java classes.

TreeSet: Elements kept in sorted order and are stored in nodes. The nodes are arranged in a tree shape
(not in a linear sequence). You can only use objects that implements the Comparable interface in their
classes for TreeSet (ex: String or Integer).

Use TreeSet if you want to visit the set's elements in sorted order. Otherwise, use HashSet for efficiency.
You should store references to TreeSet and HashSet objects inside of Set variables. Add, remove, and
contains methods exist for Set objects.

Iterator: To process the elements of sets, we use Iterator objects instead of ListIterator objects. Still
uses the next and hasNext methods. Different from list iterators because sets are unsorted and lists are
sorted, so it wouldn't make sense to have previous and hasPrevious methods.

*/

package java_project2;
//import java.util.Collections; //Set interface implements Collections interface.
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Iterator;

public class p94_HashSet_TreeSet_and_Iterator {
	public static void main(String[] args) {
		Set<String> hashSet = new HashSet<>();
		Set<String> treeSet = new TreeSet<>();
		
		hashSet.add("Mario"); //Adds item.
		hashSet.add("Wario");
		treeSet.add("Luigi");
		treeSet.add("Waluigi");

		System.out.println(hashSet); //[Wario, Mario] (unsorted)
		System.out.println(treeSet); //[Luigi, Waluigi] (sorted)
		
		treeSet.remove("Luigi"); //Removes item.
		System.out.println(treeSet); //[Waluigi]
		
		if (hashSet.contains("Mario")) { //contains method exists for Set objects.
			System.out.println("amogus");
		}
		
		for (String name : hashSet) { //Prints Wario and Mario.
			System.out.println(name);
		}
		
		Iterator<String> iter = hashSet.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next()); //Prints Wario and Mario. Cannot use previous.
		}
	}
}