/*

Frames can contain menu bars. A menu bar can contain menus. A menu contains submenus and menu items. You
need to add an event listener for each JMenu object. Construct JMenu and JMenuItem objects by including
their displayed texts.

Use setJMenuBar(menuBar) method on frame object.
Use add(menu) method on JMenuBar or JMenu objects to add JMenu or JMenuItem objects to them.

In your custom JFrame class, make create methods in order to easily add certain menu objects to the menu
bar. Do the same for menu item and submenu objects for menu objects. All should be returning menu or menu
item objects. For all menu item objects, create methods for them with inner event listener classes and
return a menu item object that already called the addActionListener(listener) method. Inputs should include
things like a name parameter.

JMenu objects do not generate events because they are not JMenuItem objects. Only selecting JMenuItem
objects counts as an event. Choice components store information, while you can't really do that with menus
or menu items.

*/

package java_project2;

import javax.swing.JFrame;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class p993_UI_Menus {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300, 400);
		frame.setTitle("Empty Frame");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JMenuBar menuBar = new JMenuBar();
		JMenu menu1 = new JMenu("File"); //Example of menu.
		JMenu menu2 = new JMenu("Edit");
		menuBar.add(menu1);
		menuBar.add(menu2);
		
		JMenu menu3 = new JMenu("amogus"); //Example of submenu.
		menu3.add(new JMenuItem("lil amogus")); //Example of menu item in submenu.
		menu2.add(new JMenuItem("???")); //Example of menu item in menu.
		menu1.add(menu3);
		
		frame.setJMenuBar(menuBar); //Adds the menu bar to UI.
	}
}