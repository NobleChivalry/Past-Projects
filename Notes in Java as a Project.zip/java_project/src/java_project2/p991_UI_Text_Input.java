/*

JTextField objects used for user input. Create JTextField object by including the width of the field. Use
the getText() method on the object to return the user-inputted text in the field (String).

JTextArea objects used for multi-line text fields. Include height and width of area. Expands if typing
beyond the width limit. Must press enter to drop down a row.

getText() method used to return user-inputed text in the field/area (String). Use parse methods if numbers.
setText("text") method used to set the text displayed in text field/area.
setEditable(false) method used to make sure field/area is for display purposes only.

append("text") method used to concatenate a String to the text already in the area.

JTextField and JTextArea are subclasses of JTextComponent. They share many methods because of this, but the
append method is only defined in JTextArea.

------------------------------------------------------------------------------------------------------------

JScrollPane objects used to stop text areas from expanding. When constructing, include JTextArea object in
the argument. Don't need to add JTextArea object to container this way, just add JScrollPane object. If text
goes beyond height or width, displays vertical and horizontal scroll bars.

*/

package java_project2;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField; //Input.
import javax.swing.JTextArea; //Multi-Line Input.
import javax.swing.JScrollPane; //Helps Text Areas.

public class p991_UI_Text_Input {
	static String word = "";

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300, 400);
		frame.setTitle("Empty Frame");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JTextField field = new JTextField(10); //Include the width (in characters) of the field. Can scroll.
		JTextArea area = new JTextArea(5, 7); //Include height and width.
		JScrollPane pane = new JScrollPane(area); //Place text area inside of scroll pane to stop expanding.

		JButton button = new JButton("Click Me!");
		JLabel label = new JLabel("word: \"" + word + "\"");
		
		JPanel panel = new JPanel();
		panel.add(pane);
		panel.add(field);
		panel.add(button);
		panel.add(label);
		frame.add(panel);
		
		//HERE HERE HERE
		class amogus implements ActionListener{
			public void actionPerformed(ActionEvent event) {
				area.setText("amogus"); //Sets text to "amogus".
				area.append("amogus"); //Makes text "amogusamogus".
				word = field.getText(); //Returns the user-inputted text in the field.
				label.setText("word: \"" + word + "\"");
				System.out.println("amogus");
			}
		}
		
		ActionListener listener = new amogus(); //Creates event listener object.
		button.addActionListener(listener); //Whenever button is clicked, action performed.
	}
}