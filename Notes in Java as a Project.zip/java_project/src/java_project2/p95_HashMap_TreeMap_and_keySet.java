/*

Maps: Allows you to associate elements from a key set with elements from a value collection. Use a map
whenever you want to look up objects by using a key. Keys must be unique, but values do not need to be.
Unsorted like sets.

A lot like sets, having two classes that implement it. HashMap and TreeMap. Make sure to store HashMap and
TreeMap objects into Map objects. Creating a Map object involves giving the object types of both keys and
values (don't need to do so for the new HashMap object itself).

put method used to set the keys and values.
get method used to get the value of the key specified in the parameter. If key does not exist, return null.
remove method used to completely remove a key and its value from the map, parameter must be the key.
keySet method used to create a set of the keys of the Map object. Can helpful if you want to enumeration.

-

HashMap: Elements stored in random order.

TreeMap: Elements stored in order of keys.

*/

package java_project2;

import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;

import java.util.Set;

public class p95_HashMap_TreeMap_and_keySet {
	public static void main(String[] args) {
		Map<String, Integer> hashMap = new HashMap<>(); //Creates HashMap object in Map variable.
		hashMap.put("Mario", 11);
		hashMap.put("Luigi", 9);
		hashMap.put("Mario", 10);
		System.out.println(hashMap); //{Luigi=9, Mario=10}
		System.out.println(hashMap.get("Mario")); //Returns 10.
		System.out.println(hashMap.get("Wario")); //Returns null.
		hashMap.remove("Luigi"); //Removes Luigi and its key.
		System.out.println(hashMap); //{Mario=10}
		hashMap.put("Luigi", 9);
		
		Set<String> keySet = hashMap.keySet(); //Creates a set of the keys of the HashMap.
		for (String key : keySet) {
			System.out.println(hashMap.get(key)); //Prints 9 and then 10.
		}
	}
}