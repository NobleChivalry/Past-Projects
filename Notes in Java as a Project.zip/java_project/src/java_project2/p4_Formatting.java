//REMEMBER: You can have multiple format fields, but each require their own argument and "%" sign.

package java_project2;

public class p4_Formatting {
	public static void main(String[] args) {
		String country1 = "America";
		double population1 = 392500.5;

		String country2 = "China";
		int population2 = 1402000000;

		//[A][M][E][R][I][C][A][ ][ ][ ]||[ ][3][9][2][5][0][0][.][5][0]
		//%'s create 2 separate format fields.
		//- represents left align. Right align is automatic.
		//10's represent the format field lengths.
		//s represents 1st parameter is string, d represents 2nd parameter is int.
		//.2 between field length and "f" says to round float to 2 spaces after the decimal.
		System.out.printf("%-10s%10.2f", country1, population1); //America    392500000.50
		System.out.println();
		System.out.printf("%-10s%10d", country2, population2); //China     1402000000
	}
}