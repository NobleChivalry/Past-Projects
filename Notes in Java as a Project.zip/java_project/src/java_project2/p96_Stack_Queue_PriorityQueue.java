//REMEMBER: We do not need to include the object type. We can have contain multiple different types in a
//single collection.

/*

Stack: Only lets you add and remove elements on one end (like a stack on pancakes). Top of the stack. Think
of it as like an undo or redo button.

push method used to add a stack.
pop method used to remove a stack. Do not include a parameter. Returns removed top.
peek method used to return the value of the top stack.

//---------------------------------------------------------------------------------------------------------

Queue: Adds items from one end and removes items from the other end. Can be thought of as a line of people
entering a line and entering a store, leaving the line. Starts at the tail, reaches the head to leave.
Leftmost is head, rightmost is tail. Store LinkedList objects inside of Queue variables.

add method adds an element at the tail.
remove method throws out the element at the head. Do not use parameters. Returns former head.
peek method returns the head/first value.

//---------------------------------------------------------------------------------------------------------
 
Priority Queue: Some things are viewed as having more priority than others to remove from the list, is not
first-in, first-out. Priority is resembled by integers. 1 is the most urgent, larger numbers are less.
The one with the smallest integer will always be retrieved/removed first. Unsorted.

Elements that are added to the priority queues should be from classes that have implemented the Comparable
interface (ex: new WorkOrder(1, "fix sink")). Will pick the one that is worth the least. String is usable.
Strings that come first in the dictionary order will be prioritized.

add method just adds the value to the queue.
remove method removes the value with the smallest priority number. No parameters. Returns deleted number.
peek method returns the value with the smallest priority number, being which will be deleted next.

*/

package java_project2;

import java.util.Stack;

import java.util.Queue;
import java.util.LinkedList;

import java.util.PriorityQueue;

public class p96_Stack_Queue_PriorityQueue {
	public static void main(String[] args) {
		Stack<String> stack = new Stack<>();
		stack.push("Mario");
		stack.push("Luigi");
		stack.push("Toad");
		System.out.println(stack); //[Mario, Luigi, Toad]
		System.out.println(stack.pop()); //Toad
		System.out.println(stack.peek()); //Luigi
		
		Queue<String> queue = new LinkedList<>();
		queue.add("Mario"); //At the head.
		queue.add("Luigi");
		queue.add("Toad"); //At the tail.
		System.out.println(queue); //[Mario, Luigi, Toad] (only Mario can be removed right now)
		System.out.println(queue.remove()); //Mario
		System.out.println(queue.peek()); //Luigi
		
		PriorityQueue<Integer> p = new PriorityQueue<>();
		p.add(3);
		p.add(1);
		p.add(2);
		System.out.println(p); //[1, 3, 2]
		int num1 = p.remove();
		System.out.println(num1); //1
		System.out.println(p); //[2, 3]
		System.out.println(p.peek()); //2
		
		Queue q = new LinkedList<>();
		q.add("amogus");
		q.add(1);
		System.out.println(q); //[amogus, 1]
	}
}