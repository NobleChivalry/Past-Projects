//REMEMBER: All exception classes derive from the "Throwable" class.
//REMEMBER: Always place more specific catch exceptions near the top. Write FileNotFoundException before
//IOException, Exception before IOException. Order from most specific to broadest.

//Note: Throwing terminates the method. Catching handles the method.

package java_project2;
import java.util.Scanner;
import java.io.File;

import java.io.IOException;
import java.io.FileNotFoundException; //Inherits from IOException.
import java.util.NoSuchElementException;
import java.lang.NumberFormatException;

public class p6_Try_Catch_and_Throw {
	public static void main2() {
		try {
			Scanner in = new Scanner(new File("amogus.txt")); //FileNotFoundException if not real file.
			String input = in.next(); //NoSuchElementException if no element.
			int value = Integer.parseInt(input); //NumberFormatException if input is not integer.
		}
		//All FileNotFoundException errors are caught by IOException. Will always run.
		catch (IOException exception) {
			//amogus.txt (The system cannot find the file specified)
			System.out.println(exception.getMessage());
			System.out.println();

			//Huge traceback block.
			exception.printStackTrace();
		}
		/*
		catch (FileNotFoundException exception) { //This is not needed because of IOException.
			System.out.println("amogus");
		}
		*/
		catch (NoSuchElementException exception) { //Handler "exception" is the exception message object.
			System.out.println("amogus");
		}
		catch (NumberFormatException exception) { //Everything is skipped after first exception found.
			System.out.println("amogus");
		}
		
		catch (Exception exception) { //Broadest exception is "Exception". Catches all exceptions.
			System.out.println("amogus");
		}
	}
	
	public static void main(String[] args) {
		main2();
		
		//THROWING EXCEPTIONS

		//You can create exception objects with their own messages.
		IllegalArgumentException exception = new IllegalArgumentException("Error");
		//throw exception; //Terminates the method immediately and continues with exception handler.
		
		//This code would be unreachable after line 7.
		if (2 > 1) {
			//You can create and throw an exception on the spot.
			throw new IllegalArgumentException("Error"); //Does not need import.
		}
		//This code becomes unreachable after the throw because of method being ended.
		boolean amogus = true;
	}
}