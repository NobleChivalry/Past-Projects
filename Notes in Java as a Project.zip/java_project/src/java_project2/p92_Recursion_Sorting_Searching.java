//REMEMBER: Arrays.toString(x) exists for normal arrays.

/*

Recursion involves solving a problem by using the same method over and over again, each time with simpler
values, which should get you closer to the base case each time (like an if-statement w/ a return value).

For recursion, you are continuously running a function within itself, until you get the result you want.
Inputs should become more and more simplified each time. You need to make sure that there is a base/ending
case to stop the recursion.

It's like a function taking a break and asking another function for an answer, this being a repeating
process until the base case is met. A good example is factorials. Always check base cases first.
factorial(5) = 5 * factorial(4) = . . . = 120; base case is when factorial(0) returns 1.

Recursive approach or iterative (loops) approach. Most cases, recursive approach is only slightly slower.
Efficiency is pretty similar. Some cases, recursive approach is easier to understand. Use recursion when
you recognize a pattern where you can reuse the same method over and over again.

*/

//---------------------------------------------------------------------------------------------------------

/*

Sorting, which is usually done from smallest to largest by default, has several ways of being performed.

Selection Sort: Picking the smallest element out of all of them and replacing them with the first element.
Repeat the process with the remaining elements after the first element. Slowest way.

Insertion Sort: Inserting each element into their correct spot one at a time to keep them sorted. You have
an empty hand, you grab a card. You grab another, if it's larger than your first card, place it to the
right of it. Otherwise, to the left of it. Pretty slow.

Merge Sort: Recursively cuts the array in half and sorts each half, merging them all together in the end.
Works quicker than the first two.

Quicksort: No temporary arrays required like in merge sort. Divide and conquer, splits the array in half
between the smaller and larger elements, sorting each half and combining them. Quicker and is faster than
merge sort in certain cases.

All of these Java sort methods require the class of the
objects in the array to implement the Comparable interface:

import java.util.Arrays; //Used for arrays.
import java.util.Collections; //Used for array lists.

Arrays.parallelSort(...) = Multi-threaded merge sort, faster with more elements.
Arrays.sort(...) = Quicksort for primitive types, merge sort for objects.
Collections.sort(...) = Uses merge sort.

*/

//---------------------------------------------------------------------------------------------------------

/*

Linear/Sequential Search: Examines every single element in order until a match is found or the end is
reached, which would mean there are is no match.

Binary Search: Only takes sorted arrays. Cuts the array in half. Continues to search for the array in the
half that must have the value in it, throwing away the other half. Repeats until match is found.

If you plan to search an array only once, then it's okay to use linear search. If you plan to do so
multiple times, it's better to sort it and then use binary search. Arrays and Collections classes also
contain static binarySearch methods (must be sorted arrays first). If no matches found, will return
-k - 1, k being the where the element should be inserted before (ex: -3 = before index 2).

*/

package java_project2;

import java.util.Arrays;
import java.util.Collections;
import java.util.ArrayList;

public class p92_Recursion_Sorting_Searching {
	public static void main(String[] args) {
		int[] array = {4, 1, 2};
		System.out.println(Arrays.toString(array)); //Use this to view array properly.
		Arrays.parallelSort(array);
		Arrays.sort(array); //Used for normal arrays.
		System.out.println(Arrays.toString(array));
		System.out.println();
		
		ArrayList<Integer> array2 = new ArrayList<Integer>();
		array2.add(4);
		array2.add(1);
		array2.add(2);
		System.out.println(array2);
		Collections.sort(array2); //Used for array lists.
		System.out.println(array2);
		System.out.println();
		
		//Prints for each one:
		//[4, 1, 2]
		//[1, 2, 4]
		
		int p = Arrays.binarySearch(array, 2);
		System.out.println(p); //Returns 1, since 2 is found at index 1.
		int p2 = Arrays.binarySearch(array, 3);
		System.out.println(p2); //Returns -3, since 3 should come before index 2 (3-1).
	}
}