//REMEMBER: Always use appropriate hasNext methods to ensure you run into no "no such element" exceptions.
//Ex: You might call the nextInt() method to look for the next integer in the text. An exception will be
//raised if there is no next integer. Therefore, shove the call into an if-statement or something.

/*

//Another in.next method is in.nextLine(). It separates by newline characters and consumes whitespace.
//When working with lines of text, you can use .isDigit() or .isWhitespace() with while loops and
//substrings in order to figure where certain parts of the line ends or starts.
//Ex: "United States 392500000" separated to "United States" & "392500000".

*/

package java_project2;
import java.util.Scanner;

import java.io.File; //Input & Output Modules.
import java.io.PrintWriter; //java.io modules need to be imported: File & PrintWriter.
import java.io.FileNotFoundException; //To handle missing file exceptions, import exception class.

public class p1_Files_and_Delimiters {
	public static void main(String[] args) throws FileNotFoundException {
		//Can use Scanner class for reading console input, but can also use to read file input.

		//Searches for files in the same project folder. Can indicate in which directories they're in,
		//separating them with slashes. If file not found, can break program.

		/*
		File inputFile = new File("src/input.txt"); //Creating an object to store certain file data in.
		Scanner in = new Scanner(inputFile); //Use file object as argument instead.
		double num = in.nextDouble(); //Treat the same as any other input.
		while (in.hasNextDouble()) { //Has method returns whether or not there is another double in input.
			num = in.nextDouble();
		}
		in.close();
		*/
		
		//Create PrintWriter objects to create and write in new files. Creates empty file in project.
		//PrintWriter works with PrintStream.

		PrintWriter out = new PrintWriter("output.txt"); //Empties all data in file before writing.
		out.print("Hello World!");
		out.printf("%10.2f%n", 1.5); //Call print methods on PrintWriter object to write into file.
		out.println("amogus");
		out.close();
		
		//If input/output file does not exist, causes FileNotFoundException to occur. To handle, you
		//need to label your main method with "throws" keyword:
		//public static void main(String[] args) throws FileNotFoundException

		
		//-------------------------------------------------------------------------------------------------
		
		
		//Example of processing input with hasNext methods and useDelimiter method. Creates infinite loop.
		
		/*
		Scanner in = new Scanner(System.in); //Parameter can be replaced with type File.
		in.useDelimiter("-"); //Delimiter is whitespace by default. Now separated by dashes.
		in.useDelimiter("[^A-Za-z]+"); //The delimiter is any non-letter character. Uses RegEx.
		in.useDelimiter(""); //Separates every single character.
		while (in.hasNext()) { //Checks if there is any text left (separated by delimiter).
			char word = in.next().charAt(0); //Includes Strings, Integers, whatever text.
			System.out.println(word); //Prints all the characters on separate lines.
		}
		in.close();
		*/
		
		//Example of using hasNext method effectively. Want to separate country name and population.
		
		Scanner in = new Scanner(System.in); //Input: United States 392500000
		String result = in.next(); //United
		while (! in.hasNextInt()) { //While the next segment of characters aren't integers. NEED to have in case no int exists.
			result = result + " " + in.next(); //Combines non-integer segments together with spaces.
		}
		System.out.println(result); //United States
		System.out.println(in.next()); //392500000
		in.close();
	}
}