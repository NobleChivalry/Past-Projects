//Character Testing Methods are all static. You call them on the Character wrapper class and enter in a
//char argument to be checked. Returns true or false.

package java_project2;

public class p2_Character_Testing_Methods {
	public static void main(String[] args) {
		char num = '2';
		System.out.println(Character.isDigit(num));
		
		char letter = 'Z';
		System.out.println(Character.isLetter(letter));
		
		char upper = 'A';
		System.out.println(Character.isUpperCase(upper));
		
		char lower = 'a';
		System.out.println(Character.isLowerCase(lower));
		
		char whitespace = '\n'; //Accept spaces, newlines, or tabs.
		System.out.println(Character.isWhitespace(whitespace));
	}
}