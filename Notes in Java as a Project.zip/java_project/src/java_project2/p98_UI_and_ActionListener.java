//REMEMBER: final objects cannot be reassigned to new values, but you can still call methods on them to
//change their attributes.

/*

Graphical applications display information through frames.

UI events include key presses, mouse moves, button clicks, etc. To prevent flooding of events, program needs
to have an event listener indicate which events should be received and respond to them through its methods.

Event sources are UI components that generate certain events. Event listeners added to these to listen to
certain events. Notifies all event listeners whenever the event happens.

Event listeners usually need to be external classes with their own file. If it's something more specific to
the main class, it's best to make it an inner class in the main method. If it needs access to things in the
main class, make it an inner class. You cannot modify the local variables that are accessed by these inner
classes, best to add "final" keyword onto them.

JFrame objects have an add(panel) method to add UI components, including panels.
JPanel objects have an add(button) method to group UI components.
JLabel objects have a setText("text") method to update text attribute.
Event source objects (ex: buttons) have an addActionListener(listener) method to give them functionality.

------------------------------------------------------------------------------------------------------------

//ActionListener interface used for event sources to notify when certain actions were performed.
public interface ActionListener {
	void actionPerformed(ActionEvent action); //Never have to call actionPerformed method.
}

//Event listener must be constructed and then assigned to an event source (ex: button).
public class ClickListener implements ActionListener {
	public void actionPerformed(ActionEvent event) {
		System.out.println("amogus");
	}
}

*/

package java_project2;

//All objects below JFrame can be added to frame objects.
import javax.swing.JFrame; //Frame objects.
import javax.swing.JPanel; //Container that contains UI components.
import javax.swing.JButton; //Button objects.
import javax.swing.JLabel; //Label objects.

import java.awt.event.ActionListener; //Event listener classes.
import java.awt.event.ActionEvent; //Represents events.

public class p98_UI_and_ActionListener { //Event listener class.
	static int num = 0;

	public static void main(String[] args) {
		JFrame frame = new JFrame(); //Construct a JFrame object.
		frame.setSize(300, 400); //Set the frame size (pixels).
		frame.setTitle("Empty Frame"); //Set title bar of frame.
		//Setting default close operation (what happens when frame is closed).
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Terminates program when frame is closed.
		frame.setVisible(true); //Make the frame visible.
		
		JButton button = new JButton("Click Me!"); //Button object with text in the center.
		//frame.add(button); //Button is added to frame.
		
		JLabel label = new JLabel("num: " + num); //Label with an initial text.
		
		JPanel panel = new JPanel(); //Panel object used to group components.
		panel.add(button); //If you want label to the left of the button, switch adding order.
		panel.add(label);
		frame.add(panel); //All things inside of panel added to frame.
		
		//Create inner classes before construction of event listener.
		class amogus implements ActionListener{ //Inner classes can only have "final" keyword.
			public void actionPerformed(ActionEvent event) { //Automatic response to an event.
				num = num + 1;
				label.setText("num: " + num); //Labels have setText method to update the text.
				System.out.println("amogus");
			}
		}
		
		ActionListener listener = new amogus(); //Creates event listener object.
		button.addActionListener(listener); //Whenever button is clicked, action performed.
	}
}