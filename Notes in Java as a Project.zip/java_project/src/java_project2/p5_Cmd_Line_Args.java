/*

//"String[] args" is a String array of command line arguments.
//Accepts flags and file names, ex:
args[0]: "-v";
args[1]: "input.txt";
args[2]: "output.txt";
		
//Best used with a for loop that reads each String as either a flag or a file name. Order of flags and
//file names do not matter in CaesarCipher.java. Don't need java file type in commands.
//Program determines what to do with commands inputted from command line.
		
//Encrypts the data in input.txt with CaesarCipher.java and puts data into encrypt.txt:
//java CaesarCipher.java input.txt encrypt.txt
		
//Optional -d flag used to decrypt whatever is in encrypt.txt. Places in decrypt.txt:
//java CaesarCipher.java -d encrypt.txt decrypt.txt

*/

//There is a file called "input.txt" that is in the same directory (java_project2) as this class.
//Open command prompt and enter: C:\Users\roblo\eclipse-workspace\java_project\src\java_project2
//Place Caesar Cipher of input.txt into new encrypt.txt: java p5_Cmd_Line_Args.java input.txt encrypt.txt
//Now use this to decrypt encrypt.txt: java p5_Cmd_Line_Args.java -d encrypt.txt decrypt.txt

package java_project2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * This program encrypts a file using the Caesar cipher.
 */
public class p5_Cmd_Line_Args {
	
	public static void main(String[] args) throws FileNotFoundException {
		final int DEFAULT_KEY = 3;
		int key = DEFAULT_KEY;
		String inFile = "";
		String outFile = "";
		int files = 0; // Number of command line arguments that are files

		for (int i = 0; i < args.length; i++) {
			String arg = args[i];
			if (arg.charAt(0) == '-') {
				// It is a command line option

				char option = arg.charAt(1);
				if (option == 'd') {
					key = -key;
				} 
				else {
					usage();
					return;
				}
			} else {
				// It is a file name

				files++;
				if (files == 1) {
					inFile = arg;
				} else if (files == 2) {
					outFile = arg;
				}
			}
		}
		if (files != 2) {
			usage();
			return;
		}

		Scanner in = new Scanner(new File(inFile));
		in.useDelimiter(""); // Process individual characters
		PrintWriter out = new PrintWriter(outFile);

		while (in.hasNext()) {
			char from = in.next().charAt(0);
			char to = encrypt(from, key);
			out.print(to);
		}
		in.close();
		out.close();
	}

	/**
	 * Encrypts upper- and lowercase characters by shifting them according to a key.
	 * 
	 * @param ch  the letter to be encrypted
	 * @param key the encryption key
	 * @return the encrypted letter
	 */
	public static char encrypt(char ch, int key) {
		int base = 0;
		if ('A' <= ch && ch <= 'Z') {
			base = 'A';
		} else if ('a' <= ch && ch <= 'z') {
			base = 'a';
		} else {
			return ch;
		} // Not a letter
		int offset = ch - base + key;
		final int LETTERS = 26; // Number of letters in the Roman alphabet
		if (offset >= LETTERS) {
			offset = offset - LETTERS;
		} else if (offset < 0) {
			offset = offset + LETTERS;
		}
		return (char) (base + offset);
	}

	/**
	 * Prints a message describing proper usage.
	 */
	public static void usage() {
		System.out.println("Usage: java CaesarCipher [-d] infile outfile");
	}
}