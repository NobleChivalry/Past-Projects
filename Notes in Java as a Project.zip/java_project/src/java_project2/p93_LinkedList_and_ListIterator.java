//REMEMBER: You don't need to create iterator types if you don't want to. For some reason, it is normal
//to use iterators for linked lists, but not for the other types.

//REMEMBER: You don't need to add object types when declaring a new Collections object, only include it
//in the variable declaration itself.

//REMEMBER: Changing iterable objects means also changing the actual linked list that it is derived from.

//REMEMBER: We don't need iterator objects for arrays because we can easily access each element by index,
//since arrays don't need to access elements sequentially like linked lists.

/*
 
A collection groups together elements and allow them to be retrieved later. Collection is an interface
that is implemented by a bunch of other interfaces, making sure all of them have a common set of methods.
A concrete Collection class that ends up implementing from the List interface is ArrayList.

All of them have size, add, toString, remove, contains, and iterator methods. Can be printed and iterated
over in loops.

-

List Interface: A Collection that remembers the order of its elements. Implemented by ArrayList and
LinkedList.

Set Interface: An unordered Collection of unique elements. Usually used for hash tables or binary search
trees.

Stack: Remembers order of elements, but you can only add or remove at the top.

Queue: Remembers order of elements, but you can only add from one side and remove from the other side.

Priority Queue: An unordered collection. Always removes the element with the highest priority.

Maps: Stores the keys, values, and the associations between them. Every key has a corresponding value.

*/

//---------------------------------------------------------------------------------------------------------

/*

Linked Lists: Used for collecting a sequence of objects. Consists of multiple nodes. Each object consists
of a value and a reference to the next node. Doubly-linked lists consist of a value and references to both
the next and previous nodes. Java only uses doubly-linked lists.

Allows for efficient addition and removal of elements in the middle of the sequence (unlike arrays).
Visiting elements in a linked list in sequential order is efficient. Random access is not efficient.

Use when concerned about efficiency of inserting or removing elements. Use when you know you will always
access the elements of the linked list sequentially.

-

List Iterator: Used to access the elements inside of a linked list. Somewhat similar to Scanner objects.
Uses the hasNext and next methods. Can use with whatever loops or if-statements, etc. Can use hasPrevious
and previous methods to go backwards in a linked list.

Think of it as a line at the start that goes in between nodes to reach the end. The next method simply
returns the value of the node that it just passed. If you use the add method on the list iterator object,
the object will be inserted right behind where the line is.

The remove method used to remove the last value that was called by the next or previous methods. Does not
have any parameters. Do not call it more than once after using next or previous methods. Do not call it
right after using add method.

The set method is similar to remove method. Simply changes the last value that was called by the next or
previous methods. Has 1 parameter for the new value.

*/

package java_project2;
//import java.util.Collections; //Not needed.
import java.util.LinkedList;
import java.util.ListIterator;

public class p93_LinkedList_and_ListIterator {
	public static void main(String[] args) {
		LinkedList<String> names = new LinkedList<String>();
		names.addLast("Luigi"); //Adds to the end of the linked list.
		names.addFirst("Mario");// Adds to the start of the linked list.
		System.out.println(names); //[Mario, Luigi]
		
		System.out.println(names.getFirst()); //Returns first in linked list, Mario.
		System.out.println(names.getLast()); //Returns last in linked list, Luigi.
		
		String removed = names.removeLast(); //Like pop method. Removes last element and returns it.
		System.out.println(names); //[Mario]
		System.out.println(removed); //Luigi
		names.addLast(removed);
		
		ListIterator<String> iter = names.listIterator(); //Creates list iterator object for linked list.
		while (iter.hasNext()) {
			System.out.println(iter.next()); //Returns Mario and Luigi.
		}
		while (iter.hasPrevious()) { //Will do nothing if haven't iterated through yet.
			System.out.println(iter.previous()); //Returns Luigi and Mario.
		}
		System.out.println();
		
		iter.next(); //Just passes Mario.
		iter.add("Wario"); //Wario added after Mario.
		iter.previous();
		iter.previous(); //Passes Wario and then Mario.
		while (iter.hasNext()) {
			System.out.println(iter.next()); //Returns Mario, Wario, and Luigi.
		}
		while (iter.hasPrevious()) {
			iter.previous();
		}
		
		//Example of remove method.
		while (iter.hasNext()) {
			String name = iter.next();
			if (name.contains("W")) { //Removes Wario.
				iter.remove();
			}
		}
		while (iter.hasPrevious()) {
			iter.previous();
		}
		while (iter.hasNext()) {
			System.out.println(iter.next()); //Returns Mario and Luigi.
		}
		while (iter.hasPrevious()) {
			iter.previous();
		}
		
		//Example of set method.
		while (iter.hasNext()) {
			String name = iter.next();
			if (name.contains("L")) { //Changes Luigi to Waluigi.
				iter.set("Waluigi");
			}
		}
		while (iter.hasPrevious()) {
			iter.previous();
		}
		//Changing iterable objects means also changing the actual linked list that it is derived from.
		//Printing iterable objects themselves just gives memory locations.
		System.out.println(names); //[Mario, Waluigi]
		
		for (String element : names) {
			System.out.println(element); //Prints Mario and Waluigi.
		}
	}
}