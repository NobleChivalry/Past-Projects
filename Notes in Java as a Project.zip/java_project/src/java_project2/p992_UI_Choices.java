/*

Radio Button used for a small set of mutually exclusive choices.
Check Box used for a binary choice.
Combo Box used for a large set of choices.

Radio Button: Making sure that only one of the buttons are selected. Construct with the button text. Create
ButtonGroup object and add the radio buttons to it, but you must add them separately into panels. isSelected
method used to check to see if the radio button is selected or not (boolean). Group makes sure only one of
them is selected.

Check Box: Use for binary choices (true or false). Construct with button text. Multiple can be selected.
isSelected method used to check to see if check box is checked or not.

Combo Box: Combination of a list and text field. You can either type into it or press on the drop down to
pick an option. Useful when there's many options. Closed ones show only 1 selection, open ones show
multiple selections. Place into a panel to make it a reasonable size. Can't see all options at once.
setEditable(false) method used to make it uneditable.
addItem("text") method used to add options.
getSelectedItem() method used to find out which option is selected (must typecast to String after).
DO NOT PUT IN A NESTED PANEL.

*/

package java_project2;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.TitledBorder; //Used to make borders visible and have titles.
import javax.swing.border.EtchedBorder; //panel.setBorder(new TitledBorder(new EtchedBorder(), "Size"));

import javax.swing.ButtonGroup; //Used for radio buttons.
import javax.swing.JRadioButton; //Only 1 button in the group can be selected.
import javax.swing.JCheckBox; //Box used to check if true or false.
import javax.swing.JComboBox; //Box used to pick an option from drop down.

public class p992_UI_Choices {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300, 400);
		frame.setTitle("Empty Frame");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JRadioButton b1 = new JRadioButton("Small");
		JRadioButton b2 = new JRadioButton("Medium");
		JRadioButton b3 = new JRadioButton("Large");
		
		ButtonGroup group = new ButtonGroup(); //Used to make sure only 1 is selected.
		group.add(b1);
		group.add(b2);
		group.add(b3);
		
		JPanel radioPanel = new JPanel(); //Must add them separately, not in ButtonGroup.
		radioPanel.add(b1);
		radioPanel.add(b2);
		radioPanel.add(b3);
		//Used to make border visible and have a title.
		radioPanel.setBorder(new TitledBorder(new EtchedBorder(), "Size"));
		
		//--------------------------------------------------------------------------------------------------
		
		JCheckBox check1 = new JCheckBox("Italics"); //Creating check boxes.
		JCheckBox check2 = new JCheckBox("Bold"); //Multiple can be selected.
		JPanel checkPanel = new JPanel();
		checkPanel.add(check1);
		checkPanel.add(check2);
		checkPanel.setBorder(new TitledBorder(new EtchedBorder(), "Style"));
		
		//--------------------------------------------------------------------------------------------------
		
		JComboBox<String> cb = new JComboBox<>();
		cb.addItem("amogus1");
		cb.addItem("amogus2");
		cb.addItem("amogus3");
		
		//--------------------------------------------------------------------------------------------------
		
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(radioPanel, BorderLayout.SOUTH);
		panel.add(checkPanel, BorderLayout.CENTER);
		panel.add(cb, BorderLayout.NORTH);
		frame.add(panel);
		
		class amogus implements ActionListener{
			public void actionPerformed(ActionEvent event) {
				if (check1.isSelected()) { //Prints when check1 is selected. Checks each time pressed.
					String result = (String) cb.getSelectedItem(); //Prints whatever is in combo box.
					System.out.println(result);
				}
			}
		}
		
		ActionListener listener = new amogus();
		check1.addActionListener(listener);
	}
}