//You can create your own custom exception that inherits from Exception OR RuntimeException.
//Ex: You can inherit from IllegalArgumentException.

//NEED one constructor with no parameters and one with String parameter.
//Need to throw custom exceptions, not automatically brought up.

//Check p7 for results.

package java_project2;

public class p8_Custom_Exception extends IllegalArgumentException {
	public p8_Custom_Exception() {
	}
	
	public p8_Custom_Exception(String message) {
		super(message); //Need this to trigger IllegalArgumentException's second constructor.
	}
}