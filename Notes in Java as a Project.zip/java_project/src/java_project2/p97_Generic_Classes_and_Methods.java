//REMEMBER: CANNOT have an array of generic types or create objects of generic types. Just create arrays
//type Object instead. Don't use array lists.
//Java simply replaces all generic types in the code with the type parameters.
//You can use generic type iterables for enhanced for loops, but you still cannot call any methods of the
//generic types. THE TYPE OF THE ITERABLE ALWAYS TAKES PRIORITY.



//REMEMBER: This would compile, but you cannot convert an array list of Rectangles into an array list of
//Measurables. No relation between array lists.
//public static Measurable min(ArrayList<Measurable> a)

//You can do this for arrays, but it would return type Measurable, so you need to typecast it afterwards.
//Would not matter if return type was not an interface type.
//public static Measurable min(Measurable[] a)

//Using arrays would work, using with array list would not work. Overall, better to use type parameters.

/*

Generic Programming: Creating programming constructs that can be used with many different types. An example
is where you can pick what type to hold for an array list, using "<>". Good to use when you want to allow
whatever types as parameters.

Generic classes have one or more type parameters. "E" represents a type parameter, being the parameter with
no predetermined type. Defined by inputs of type parameters during instantiation.
public void add(E element)
public E get(int index)

Type parameters can be instantiated with a class or interface. No primitive types allowed, must use a
wrapper class instead. Replaces all type parameters with actual given types.
ArrayList<String> OR ArrayList<Comparable>

Generic methods can exist in both generic classes and non-generic classes. Simply a method with a type
parameter. Comes right before the return type of the method header. Does not include methods that simply
use type variables that were instantiated with the class. Defined by inputs of method parameters.
public static <E> void print(E[] a)

You can constrain type variables, disallowing for ALL types to be accepted. You can do this by only
allowing in types that extends from certain superclasses or interfaces. Can use multiple, but both have to
be interfaces then.
public static <E extends Comparable & Cloneable> void constrained(E object)

//---------------------------------------------------------------------------------------------------------

Type Erasure: All references to generic types are replaced with type Object. Therefore, you cannot normally
call the methods of the type variables, since that would be calling a method on an object of type Object.
For methods, if it has a bound, will change all references of the generic type to the interface/class.

Meaning, you cannot create objects of the generic types, since that would be like trying to instantiate an
object of type Object. Cannot create arrays of generic types either, just use Object[] instead of E[].
Can fix this with a list array OR by typecasting the Object array (iffy).

*/

//TYPE PARAMETERS = "<>"
package java_project2;

import java.lang.reflect.Array;

//Example of a generic class.
//Convention to make generic type variables uppercase letters.
public class p97_Generic_Classes_and_Methods<A, B> {
	private A amogus1; //These generic types can then be referenced anywhere in the class. Replaces all
	private B amogus2; //references of A and B with type Object.
	
	public p97_Generic_Classes_and_Methods(A amogus1, B amogus2) {
		this.amogus1 = amogus1; //Ex: Can refer to types of instance variables or return types of methods.
		this.amogus2 = amogus2;
	}
	
	public A getFirst() { //A and B are all replaced by type Object.
		return amogus1;
	}
	
	public B getSecond() {
		return amogus2;
	}
	
	//Example of generic class. Can print the elements of arrays of any type. Type parameters are defined
	//by the object types of the method parameters.
	public static <E, R> void print(E[] a, R b) {
		for (E element : a) {
			System.out.println(element);
		}
	}
	
	//Example of using constrained type parameters. MUST use extends keyword for both interfaces and
	//superclasses. Only allows classes that implement the Comparable interface, the compareTo method using
	//a parameter of type String. Classes usually implement Comparable with a type parameter of themselves.
	public static <E extends Comparable<String>> void constrained(E object) {
	}
	
	//Refers to ALL classes that implement a Comparable interface with a type parameter of themselves.
	//Can implement more than 1 interface with "&". MUST be another interface at that point.
	public static <E extends Comparable<E> & Cloneable> void constrained2(E object) {
		//E is replaced by interface types Comparable<E> and Cloneable.
	}
	
	//Make sure to ALWAYS include type parameters almost anywhere you create a generic class instance.
	public static void main(String[] args) { //Do not need to include type variables on the right side.
		p97_Generic_Classes_and_Methods<String, Integer> age = new p97_Generic_Classes_and_Methods<>("Mario", 10);
		System.out.println(age.getFirst()); //"Mario"
		System.out.println(age.getSecond()); //10
		String[] array = {"Mario", "Luigi"};
		p97_Generic_Classes_and_Methods.print(array, 1); //Prints Mario and Luigi.
	}
}

//---------------------------------------------------------------------------------------------------------

//HOW TO FORCE THE CREATION OF A GENERIC ARRAY THROUGH THE (newInstance) METHOD.

/*

import java.lang.reflect.Array; //newInstance method requires class type and desired array length.

Class c = result.get(0).getClass(); //Need to get the type of the objects inside the arrays.
T[] result = (T[]) Array.newInstance(c, array.length); //Manually makes an array of that class and casts.

for (int i = 0; i != array.length; i++) { //Then just fill the empty array with whatever values.
	result[i] = array[i];
}

*/