/*

Five-Part Program Development Process

1. Gather Requirements for a requirements specification.
2. Use CRC cards to find classes, responsibilities, and collaborators.
3. Use UML diagrams to record class relationships.
4. Use javadoc to document method behavior.
5. Implement your program.

Best to work with sample results/returns. When finding classes and methods, figure out which nouns and
methods matter.

Use javadoc comments with blank method bodies to record behaviors of classes: write a Java source file
for each class, write the method comments for discovered methods, leave the body of the methods blank.
Run javadoc to obtain formatted version of documentation in HTML format.

*/

//Example of javadoc (just a file that describes a class and its methods with comments).

package java_project2;

/**
Describes an impostor from amogus.
*/
public class p91_Process_and_javadoc {
	/**
	The impostor kills off a crewmate.
	@param crewmate the name of the person that the impostor will kill
	*/
	public void kill(String crewmate) {
	}
	
	/**
	Gives the message that the impostor typed.
	@return what the impostor wants to type into the chat
	*/
	public String chat() {
		return "";
	}
}