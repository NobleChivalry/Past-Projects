/*

Discovering Classes and Methods

First getting into a software project, you start out with a requirements specification. Our job is to
discover structures that make it possible to implement those requirements.

To discover classes, we should look for nouns in the doc (ex: public class Student).
To discover methods, we should look for verbs/behaviors of class objects (ex: studentA.study()).

CRC Card Method (which class is responsible for this responsibility?):
Use an index card for each class. Responsibilities are verbs.
Collaborators are other classes required to carry out the responsibilities.

[                Class                ]
[ Responsibilities | Collaborators    ]
[ Responsibilities | Collaborators    ]
[ Responsibilities | Collaborators    ]
[                . . .                ]

*/

//---------------------------------------------------------------------------------------------------------

/*

//REMEMBER: System class counts as a class that another class can depend on.

Relationships between Classes / UML = Unified Modeling Language

Dependency: A class knows about and uses another class. If the known class changes, the dependent class
might have to change as well. Dependent, dashed arrow to known. Good idea to minimize the dependencies of 
classes, don't want to change all classes. "Knows-about" relationship.

Aggregation: A class aggregates another class if its objects contains objects of the other class.
A Quiz object has several Question objects. Property, open diamond to owner. Stronger form of dependency.
Quiz aggregates Question. To do this, keep an instance variable in the aggregator to store the class
objects in something like an array. "Has-a" relationship.

Inheritance: Relationship between more general class (superclass) and more specialized class (subclass).
Sometimes confused with aggregation. Subclass, open arrow to superclass. "Is-a" relationship.

Ex: Car is a Vehicle, Car has a Tire.

*/