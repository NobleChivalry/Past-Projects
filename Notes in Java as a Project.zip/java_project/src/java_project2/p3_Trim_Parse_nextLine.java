//REMEMBER: Parse used to convert String into int OR double.

//REMEMBER: The in.nextDouble() method accepts BOTH int & double values, but in.nextInt() only accepts int values.

package java_project2;

public class p3_Trim_Parse_nextLine {
	public static void main(String[] args) {
		//trim method used to remove any whitespaces before first character and after last character.
		String numA = " 392500000  ";
		String num = numA.trim(); //String "392500000"

		//parse methods used to convert from numbers to String. Static and uses wrapper classes.
		int population = Integer.parseInt(num); //Converts String to Integer.
		System.out.println(population); //392500000
		
		String numB = "30.25   ";
		double numC = Double.parseDouble(numB.trim()); //Make sure it never has whitespaces.
		System.out.println(numC); //double 30.25
		
		//Only in.nextLine() method consumes whitespace/newlines. Other in.next methods do not.
		//Therefore, this could cause problems when trying to mix nextLine with other next methods.
		//To fix this, make sure to just add an in.nextline() method at the bottom of the loop to
		//consume the extra newline character.
		
		/*

		String name = in.nextLine();
		int population = in.nextInt();
		in.nextLine();

		*/
	}
}