/*

You build UI's in Java by placing components into containers. You can place containers within containers.
JPanel and JFrame objects are examples of containers. Containers have layout managers to know where to
place the components. Example, you can contain a panel with a grid layout and a label object inside of a
panel with a border layout.

JPanel uses Flow layout by default, components are added from left to right, going down a row after running
out of room, components being centered as much as possible.

JFrame uses Border layout by default, components are placed toward areas of a container, NESW or CENTER.
Components expand to fill space. N and S expand horizontally, E and W expand vertically, Center expands in
any direction. Last added component in a direction will be displayed, ones before it being underneath.

Grid layout, you have to specify number of rows and columns. Creates box sections to be filled. Must fill
up each row before dropping down a row. Equal spacing. Useful for things like stacking 3 buttons on each
other (top to bottom). If you want them next to each other, then add them to a border layout panel when
they are in a flow layout panel (nesting panels). To make buttons smaller, use a flow layout for each of
them first.

In general, better to create your own class that inherits from JFrame, store components as instance
variables and initialize them inside your constructor. Easy to add helper methods and organize code.

*/

package java_project2;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.BorderLayout;
import java.awt.GridLayout;

public class p99_UI_Layout_Management {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300, 400);
		frame.setTitle("Empty Frame");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		//Border Layout Example
		/*
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout()); //Changes layout to Border layout.
		panel.add(new JLabel("amogusN"), BorderLayout.NORTH); //Must specify component AND area.
		panel.add(new JLabel("amogusE"), BorderLayout.EAST); //Centered text.
		panel.add(new JLabel("amogusS"), BorderLayout.SOUTH); //Left-aligned text.
		panel.add(new JLabel("amogusW"), BorderLayout.WEST); //Can only have 1 show in each direction.
		panel.add(new JLabel("amogusC"), BorderLayout.CENTER); //Left-aligned text, next to WEST.
		frame.add(panel);
		*/
		
		//GridLayout Example + Nested Panels
		/*
		JPanel keypadPanel = new JPanel(); //Master panel to contain panels and components.
		keypadPanel.setLayout(new BorderLayout());
		
		JPanel buttonPanel = new JPanel(); //Number keypad panel.
		buttonPanel.setLayout(new GridLayout(4, 3));
		buttonPanel.add(new JButton("7"));
		buttonPanel.add(new JButton("8"));
		buttonPanel.add(new JButton("9"));
		buttonPanel.add(new JButton("4"));
		buttonPanel.add(new JButton("5"));
		buttonPanel.add(new JButton("6"));
		buttonPanel.add(new JButton("1"));
		buttonPanel.add(new JButton("2"));
		buttonPanel.add(new JButton("3"));
		buttonPanel.add(new JButton("0"));
		buttonPanel.add(new JButton("."));
		buttonPanel.add(new JButton("CE"));
		
		JLabel display = new JLabel("0"); //Label to display inputs.
		keypadPanel.add(buttonPanel, BorderLayout.CENTER); //Needs to fill rest of space.
		keypadPanel.add(display, BorderLayout.NORTH);
		frame.add(keypadPanel);
		*/
		
		//Example of creating your own class that inherits from JFrame.
		/*

		public class FilledFrame extends JFrame {
			private JButton button;
			private JLabel label;
		
			private static final int FRAME_WIDTH = 300;
			private static final int FRAME_HEIGHT = 100;
		
			public FilledFrame() {
				createComponents();
				setSize(FRAME_WIDTH, FRAME_HEIGHT);
			}
		
			private void createComponents() {
				button = new JButton("Click me!");
				label = new JLabel("Hello, World!");
		
				JPanel panel = new JPanel();
				panel.add(button);
				panel.add(label);
				add(panel);
			}
		}

		*/
	}
}