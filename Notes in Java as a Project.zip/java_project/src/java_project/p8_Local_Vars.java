//REMEMBER: LOCAL VARIABLES ARE DIFFERENT FROM INSTANCE VARIABLES

//Instance variables belong to classes (objects).
//Local variables belong to methods.

//Instance variables only cease to exist if there are no more methods that use them anymore.
//All local variables are temporary and reset after the end of a method, ceasing to exist.

//Instance variables default to 0 if it's a number. Defaults to null if it's an object.
//Local variables ARE NOT automatically initialized. There are no default values.

package java_project;

public class p8_Local_Vars {
	public String Swap(int num1, int num2) { //Parameters are local variables.
		int temp = num1; //All variables created within methods are local variables.
		num1 = num2;
		num2 = temp;
		return num1 + " " + num2;
	}
	
	public static void main(String[] args) {
		p8_Local_Vars obj = new p8_Local_Vars();
		System.out.println(obj.Swap(1, 2)); //Prints "2 1".
	}
}