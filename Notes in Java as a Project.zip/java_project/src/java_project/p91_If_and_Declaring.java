/*

//REMEMBER: IMPLICIT PARAMETERS ARE ALWAYS THE CLASS OBJECT ITSELF UNDER THE NAME "THIS". ALWAYS EXISTS.
//REMEMBER: EXPLICIT PARAMETERS ARE WITHIN THE ACTUAL CONSTRUCTOR'S PARAMETERS.

//REMEMBER: ALL VARIABLES CREATED INSIDE IF-STATEMENTS ARE LOCAL VARIABLES
//REMEMBER: IF CHANGING A VARIABLE INSIDE OF AN IF-STATEMENT, DECLARE IT OUTSIDE OF IF-STATEMENT FIRST

public int main() {
	int num1 = 1;
	int num2 = 2;
	if (num1 > num2) { //All statements must wrap the conditions within parentheses.
		return num1;
	}
	else if (num1 < num2) { //elif-statement created by use of "else if".
		return num2;
	}
	else if (num1 == num2) { //Only use "==" operator for numbers. For Strings, use "a.equal(b)".
		return num1 + num2;
	}
	else {
		return num1 - num2; //All if-statements require an else-statement at the end.
	}
}

*/