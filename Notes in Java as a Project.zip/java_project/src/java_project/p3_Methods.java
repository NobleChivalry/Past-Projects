//REMEMBER: IF IT DOES NOT WORK, ADD STATIC KEYWORD TO IT

package java_project;

public class p3_Methods {
	public static void main(String[] args) {
		//System.out is an object of the PrintStream class. Some methods are print and println.
		//String class provide String objects with other methods.

		String greeting = "Hello, world!";
		int greeting_length = greeting.length(); //Stores result of calling length method on greeting String.
		System.out.println(greeting_length); //Prints 13.
		
		String greeting_upper = greeting.toUpperCase();
		System.out.println(greeting_upper); //Prints "HELLO, WORLD!"
		
		String greeting_replace = greeting.replace("l", "r"); //Replace method uses two parameters.
		System.out.println(greeting_replace); //Prints "Herro, worrd!"
		
		//Print method itself returns nothing, returning type void instead.
		//System.out.println(System.out.println());
		
		//Do not need to create a separate variable for one-time use. Can create object on the spot.
		System.out.println(greeting.toLowerCase()); //Prints "hello, world!".
		System.out.println("Hello, world!".toLowerCase()); //Prints "hello, world!".
	} //Automatically recognizes "Hello, world!" as string object.
}

//Declaring Methods: modifier, return type, method name, parameter list
//public means any code can call the method inside or outside of this class.
/*

public String posOrNeg(int x, int y) {
	int z = x + y;
	if z < 0
		return String "Neg";
	else
		return String "Pos";
}

*/

//Accessor methods do not change the instance variables of the objects that were used to invoke them.
//Ex: length method of class String

//Mutator methods do change the instance variables of the objects that were used to invoke them.
//Note: box is Rectangle object.
//Ex: box.translate(10, 20); (changes the location of the Rectangle object)

//In short, some methods return a value, while others simply change the value of the object.