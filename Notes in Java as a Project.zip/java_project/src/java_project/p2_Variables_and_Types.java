/*
This is how you create a multi-line comment.
Basically, this is Python's triple quotes.
*/
package java_project;

//All new classes must be placed into separate files.
//PrintStream class prints characters. String class simply holds characters.
//Variables hold a name and an object.
public class p2_Variables_and_Types {
	public static void main(String[] args) { //Variable declarations: type, name, =, value, ;
		String greeting = "Hello world!"; //Variable greeting is a string of "Hello world!"
		System.out.println(greeting); //Variable greeting can be referred to. Printed here.

		int length = 1 + 1; //length is 2
		int width = 2; //width is 2
		int area = length * width; //Refers to values of length and width multiplied.
		System.out.println(area); //Prints 4.
		
		int length2; //Creates int variable length2.
		int length3, width3; //Creates int variables length3 and width3.
		
		double num = 1.5; //Creates floating-point variable.
	}
}

//Errors:
//No var type: height = 30;
//Wrong var type: int height = "30";

//Basic arithmetic operators for numbers (cannot use on String values):
// +, -, *, /

//Variable Naming Rules:
//No spaces, cannot start with numbers, no special symbols, and no reserved words (ex: double).
//Always lowercase beginning. Use camel case or underscores. Classes must have capitalization.

//Initialize variables first before using ALWAYS.