package java_project;

public class p7_Constructor_Methods {
	
	private double amount;
	
	private int num;
	
	//REMEMBER: REFERS TO THIS AS THE CONSTRUCTOR METHOD OF THE CLASS (ALWAYS SAME NAME AS CLASS)
	//REMEMBER: DO NOT SPECIFY RETURN TYPE FOR CONSTRUCTOR METHODS
	
	public p7_Constructor_Methods() {
		amount = 0;
		num = 0;
	}
	
	//REMEMBER: PARAMETERS ALWAYS HAVE TYPES
	public p7_Constructor_Methods(double initial_value, int account_number) {
		amount = initial_value;
		num = account_number;
	}
	
	public double get_amount() {
		return amount;
	}
	
	public double get_num() {
		return num;
	}

	public static void main(String[] args) { //REMEMBER: MAIN METHODS USED TO ACTUALLY DO THINGS WITH CLASSES
		p7_Constructor_Methods bank1 = new p7_Constructor_Methods(2.5, 12345); //Parameters: amount, num
		System.out.println(bank1.get_amount()); //Prints 2.5.
		System.out.println(bank1.get_num()); //Prints 12345.0.
		
		p7_Constructor_Methods bank2 = new p7_Constructor_Methods(); //Uses constructor w/ NO parameters.
		System.out.println(bank2.get_amount()); //Prints 0.0.
		System.out.println(bank2.get_num()); //Prints 0.0.
	}
}