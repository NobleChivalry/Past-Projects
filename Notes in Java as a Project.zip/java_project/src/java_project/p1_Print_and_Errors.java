//REMEMBER: import java.awt.Rectangle;

//Java and Python are very different. However, both treat everything like an object.
// ' and " are differently used. Java is statically typed and compiled first.
//Uses { and } instead of whitespaces to determine where blocks of code start and end.

//This is how you create a comment. Java ignores whitespaces.
//Every time you make a class in src, always select "public static void main(String[] args)"
//All statements end with a ";".
package java_project; //Name of the module.

//REMEMBER: CLASSES DO NOT NEED PARAMETERS, CONSTRUCTOR METHODS DO

//Creates a public class called "Java_Class", starting at "{".
//methods are simply functions attached to certain classes/objects.
public class p1_Print_and_Errors { //"public" keyword is not required on this line.
	public static void main(String[] args) { //Creates a public method called "main" (not always needed).
		System.out.println("Hello,"); //Basic print statement. Creates new line.
		System.out.print("world!"); //Does not create new line.
	} //"System.out" object belongs to PrintStream class. "print" and "println" are its methods.
} //Opening curly brackets must correspond with closing curly brackets.

//There are 3 types of errors:
//compile-time (syntax): forgetting semi-colon at end of a statement
//run-time (logic): accidentally misspelling a string to be printed
//exceptions (type of run-time): Attempting to divide by zero

//PrintStream class prints characters. String class simply holds characters.