//REMEMBER:
//import java.util.Arrays;
//int[] nums = {4, 2, 1, 3};
//Arrays.sort(nums); //Mutator method that sorts the order of an array (low to high).

package java_project;
import java.util.Arrays; //Used to properly copy contents of arrays.

public class p98_Arrays_and_Enhanced_For_Loops {
	public static void main(String[] args) {
		//Arrays stores a sequence of values of the same type.
		//double array variable "values" is set to a new double array with a max capacity of 10 values.
		double[] values = new double[10]; //NEEDS to have a max capacity.
		values[4] = 21.5; //Assigns 4 index to 21.5.
		System.out.println(values.length); //Length of arrays are fixed. Ex: Cannot change from 10.
		
		String[] values2 = {"Mario", "Luigi"}; //Can create initial values.
		System.out.println(values2.length); //Prints length of 2 (cannot change).
		System.out.println(values2); //[Ljava.lang.String;@515f550a
		System.out.println(values2[0]); //Mario
		System.out.println(values2[1]); //Luigi
		//System.out.println(values2[2]); //Break program.
		//REMEMBER: Arrays are mutable. Variables can refer to the same array object.
		
		String[] values3 = Arrays.copyOf(values2, values2.length + 1); //Copies over values, changes length.
		System.out.println(values3[0]); //Mario
		System.out.println(values3[2]); //null
		System.out.println(); //DO NOT forget new keyword.
		
		//Enhanced For Loops used to iterate over each element of an array.
		//Note: CANNOT modify the elements of the array, would have to use a normal for loop.
		for (String element : values2) {
			if (element.equals("Mario")) {
				System.out.println(element); //Prints all values inside named "Mario".
			}
		}
	}
}