//REMEMBER: String concatenation never involves a toString method, even when there's an integer.

//REMEMBER: USE .equals() FOR COMPARING STRING CONTENTS

//REMEMBER: YOU CAN CONVERT STRINGS TO INTEGERS OR VICE VERSA TO .valueOf(x) METHODS
//MUST CONVERT STRING TO CHAR AND CHAR TO STRING AND STRING TO INTEGER


//REMEMBER: UPPERCASE LETTERS COME BEFORE LOWERCASE LETTERS
//"Z" and then "a"
//Whitespace before all
//Numbers before letters

//Checking to see order in dictionary:
//string1.compareTo(string2) < 0 //string1 comes before string2?
//string1.compareTo(string2) > 0 //string1 comes after string2?
//string1.compareTo(string2) == 0 //string1 and string2 are equal?


/*

//REMEMBER: String.toLowerCase() and String.toUpperCase()

//REMEMBER:
//str.charAt(x) returns type char.
//str.substring(x, y) returns type string.

String Literal: Character sequence enclosed in double quotes.
"H" != 'H'; //Type String != Type Char

int length = "Hello".length(); //Equal to 5.

String name = "Harry";
char start = name.charAt(0); //char 'H'
char last = name.charAt(4); //char 'y'

-----------------------------------------------------------------------------------------------------------

String harr = name.substring(0, 4); //String "Harr"
String arry = name.substring(1, 5); //String "arry"
String harry = name.substring(0); //String "Harry" (from index 0 to rest of String)

Can concatenate strings to strings with "+" operators. Includes other data types, like numbers. Result
ends up being a string either way (ex: "Hello" + 7.5 = "Hello7.5").

Using Scanner class to read strings:
System.out.print("Enter you name: ");
String name = in.next(); //Only takes in first word, ignoring everything after whitespace.
Note: Second call to in will take in the next word after the initial whitespace.
|
Input: "Eric Winson Truong"
first = in.next(); //"Eric"
middle = in.next(); //"Winson"
last = in.next(); //"Truong"

*/

package java_project;
import java.util.Scanner;

public class p94_Strings {
	private String word;

	public p94_Strings(String word) {
		this.word = word;
	}

	public String getMid() {
		int start = (word.length() / 2) - 1; //Converts to int (floors it).
		int end = start + 3;
		return word.substring(start, end); //Substring of three middle chars.
	}

	public static void main(String[] args) {
		/*
		Scanner in0 = new Scanner(System.in);
		System.out.print("Input: ");
		String first = in0.next();
		String middle = in0.next();
		String last = in0.next(); //Prints out names in order, 2nd part causes exception.
		System.out.println(first);
		System.out.println(middle);
		System.out.println(last);
		in0.close();
		System.out.println("");
		*/
		
		Scanner in = new Scanner(System.in);
		System.out.print("Input: ");
		String word = in.next();
		p94_Strings mid = new p94_Strings(word);
		System.out.println(mid.getMid());
		in.close();
	}
}