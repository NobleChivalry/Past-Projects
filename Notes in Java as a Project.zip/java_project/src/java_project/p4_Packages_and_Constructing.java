//Packages are the same thing as modules. You must refer to packages in order to import the classes inside.
package java_project;

import java.awt.Rectangle; //Rectangle class is a part of the java.awt package.

public class p4_Packages_and_Constructing {
	public static void main(String[] args) {
		String greeting = "Hello, world!"; //Print command allows adding strings and numbers together.
		System.out.println(greeting + 1.5); //Prints "Hello, world!1.5"
		
		//String slicing in Java uses String method "substring".
		System.out.println(greeting.substring(0, 13)); //0 is "H" and 13 is void. Prints "Hello, world!"
		System.out.println(greeting.substring(0, 12)); //Prints "Hello, world"
		System.out.println(greeting.substring(0)); //Prints "Hello, world!" (from 0 to the rest).
		System.out.println(greeting.substring(12)); //Prints "!"
		System.out.println(greeting.substring(13)); //Prints ""

		String greeting2 = "Hello, world!"; //Need to use new keyword for constructing objects
		Rectangle box = new Rectangle(5, 10, 20, 30); //from custom classes (x, y, width, height).

		System.out.println(new String()); //Prints "". Needs new keyword.
		System.out.println(box); //Prints "java.awt.Rectangle[x=5,y=10,width=20,height=30]".
		System.out.println(new Rectangle()); //Need parentheses no matter what.
	} //Prints "java.awt.Rectangle[x=0,y=0,width=0,height=0]". Empty parameters default to all 0.

}

//Example of constructing methods with the String class:
//public int length()
//public String toLowerCase()
//public String replace(oldChars, newChars)
//public String substring(indexStart, indexEnd)