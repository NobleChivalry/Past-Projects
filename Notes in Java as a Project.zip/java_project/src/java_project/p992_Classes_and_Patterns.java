//REMEMBER: Many classes require the use of set methods when trying to change the values of its class
//objects when not in the class (so like in a method of sorts).

//REMEMBER: Minimize dependencies in order to avoid side effects (class depending on another class).
//Changing one class will require us to change all other classes dependent on it sometimes.

//REMEMBER: The String class is immutable. All immutable classes cannot have mutator methods, only
//accessor methods can exist for them. On the other hand, the Rectangle class is mutable (size + location)
//and the Random class is mutable (value changes).

/*

Names are very important, since they bring value by giving clarity as to what classes do.
-
Domain Classes: Based on nouns involving the context that the class is used for.
Actors: End in -er or -or, being known to doing some kind of work for you (ex: Scanner).
Utility Classes: No objects, only has methods and constants to be used (ex: Math).
Program Starters: Classes that only have a main method.

Classes should represent a single concept. Class is cohesive only if its features relate to the concept
that the class is trying to represent. If it doesn't have all to do with the concept, you can split the
class into two classes with different concepts. CashRegister class needs to be very focused on doing
cash register stuff, not coin stuff (minimizing dependencies).

-
//Immutable classes never have mutator methods (ex: String class).
//References to immutable classes/objects can be safely used.
//Separate accessors and mutators in mutable classes.
//In general, a method should never modify its parameters (unless a mutator method), minimize side effects.
Mutator Method: Changes the state of the object called on (implicit). Return type of void usually.
Accessor Method: Returns an object without changing the state of the object being called on.

*/

/*

Class creation tends to have useful patterns that can be picked up.

For example, you can initialize a "total" variable inside of a class, mutate it, and then finally return
its end state.

Another example, you might have to count the amount of times a certain event happens, incrementing each
time it happens and returning the "counter" variable at the end.

If you ever need to hold multiple values, you can initialize a "collection" variable that is an empty array
or array list with some kind of add method.

A class may typically have properties/attributes that can be set and retrieved by the user. If it never
needs to be changed, then it will never have a setter method.

*/