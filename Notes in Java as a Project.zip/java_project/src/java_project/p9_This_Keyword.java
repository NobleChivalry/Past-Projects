//REMEMBER: "THIS" REFERS TO INSTANCE VARIABLES, NOT LOCAL VARIABLES (LOCAL IS ALREADY DEFAULTED TO)

//REMEMBER: INSTANCE VARIABLES BELONG TO CLASSES (OBJECTS), LOCAL VARIABLES BELONG TO METHODS

package java_project;

public class p9_This_Keyword {
	private String name;
	private double price;

	public p9_This_Keyword(String name, double price) {
		this.name = name; //Declaring instance variable "name" now refers to value of parameter "name".
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public void reducePrice(double amount) {
		price -= amount;
	}
}

//Implicit and Explicit Parameters:
//-
//momsSavings.deposit(500);
//Explicit: 500
//Implicit: momsSavings
//Method using Parameters: deposit

//"this" keyword used to point to which variable you actually mean, the INSTANCE variable:
//-
//this.balance = balance; (Instance object balance now refers to parameter object balance.)

//Example: A method uses an instance variable and its local variable found in its parameters.
//Therefore, it has 1 implicit (instance/called on) and 1 explicit (parameter) parameters.