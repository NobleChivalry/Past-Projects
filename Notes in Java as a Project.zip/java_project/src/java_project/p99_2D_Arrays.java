package java_project;

public class p99_2D_Arrays {
	public static void main(String[] args) {
		//Matrix, used to store tabular data, arrangement of rows and columns.
		int xCo = 3; //How many xCo there are. ROWS LENGTH
		int yCo = 3; //How many yCo there are. COLUMNS LENGTH
		int[][] graph = new int[xCo][yCo]; //Creates new 2D array.
		
		int[][] graph2 = {
			{0, 5, 0},
			{0, 1, 0}, //Can create with initial values.
			{0, 0, 1} //Cannot change size after declaring like a 1D array.
		};
		System.out.println(graph2[0][1]); //Prints 5, in 0th row and 1st column.
		System.out.println(graph2.length); //Prints row length of 3.
		System.out.println(graph2[0].length); //Prints column length of 3.
		
		//We use nested loops in order to access all elements of a 2D Array.
		for (int i = 0; i <= graph2.length - 1; i++) {
			for (int j = 0; j <= graph2.length - 1; j++) {
				System.out.printf("%8d", graph2[i][j]); //Prints each row of numbers.
			}
			System.out.println(); //Separates each row.
		}
		System.out.println();
		
		//Same thing can be done with enhanced for loops.
		for (int[] row : graph2) { //Note: 2D arrays are just an array filled several arrays.
			for (int num : row) { //Prints each number from each row.
				System.out.printf("%8d", num);
			}
			System.out.println();
		}

	}
}