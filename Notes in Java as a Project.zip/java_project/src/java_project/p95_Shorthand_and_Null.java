/*

REMEMBER: SET TO QUESTION MARK, COLON!

Conditional Operator "?"
Note: Shorthand way of declaring variable based on if-statements.

if (floor > 13) { actualFloor = floor - 1; } else { actualFloor = floor; }
=
actualFloor = floor > 13 ? floor - 1 : floor; // x = condition ? value1 : value2;

Ex: System.out.println("Actual Floor: " + (floor > 13 ? floor - 1 : floor));

Tip: Better to take duplicate code out of if-statements if the code will be executed either way.

-----------------------------------------------------------------------------------------------------------

Use comparison operators for numbers. Use equals method for strings. Do not compare different types.
num == 1 //Checks for memory location.
str.equals("H") //Checks if containing same characters.
Ex: For box1 == box2, box2 MUST have been set to box1 (no creating new object, even w/ same content).

//REMEMBER: UPPERCASE LETTERS COME BEFORE LOWERCASE LETTERS
//"Z" and then "a"
//Whitespace before all
//Numbers before letters

Checking to see order in dictionary:
string1.compareTo(string2) < 0 //string1 comes before string2?
string1.compareTo(string2) > 0 //string1 comes after string2?
string1.compareTo(string2) == 0 //string1 and string2 are equal?

-----------------------------------------------------------------------------------------------------------

null refers to no object. Can be used in comparisons, use "==" operator. Not an empty string.
String middleName = null; //If person has no middle name.

*/

//Don't know if (n > 2) will return true or not, but we know (n < 1) would.
//b = (n < 1) || (n > 2);