//Concrete Class = Non-Abstract Class

//REMEMBER: You want to use interfaces when you have 2 different classes that need to have their own way
//of performing an operation/method. Define an interface and make the classes conform to those interfaces.
//This may be useful when you have to input these objects into a method of parameter type Object and
//need to use typecasting.

//Main difference between abstract classes and interfaces: Classes can implement many different
//interfaces, but classes can only inherit from 1 abstract class (or normal class). Another thing is
//that abstract classes can have implemented methods and constructors. Both cannot be instantiated.

/*

Inheritance focused on reusing data and behavior. Interfaces focused on reusing behavior and operations.
Sometimes two classes are very different from each other. However, you want to input them into the same
method and output something in a different way. getBalance and getArea are different, settle with a
getMeasure method with an Object parameter for 2 different classes.

Depending on what class is inputted into the parameter, the different inputted objects will be called in
their own way. Need to create a new interface whose objects can both be measured.

*/

//REMEMBER: A Java interface type only declares methods. Does not provide their implementations.
//Can contain more than 1 method. All methods are abstract. No instance variables allowed.
//All are automatically public methods. No constructors, type interfaces cannot be instantiated.

//---------------------------------------------------------------------------------------------------------

/*

//REMEMBER: Always make the parameters of the methods inside of interfaces of type Object. When
//implementing methods for an interface, make sure to typecast its parameters to whatever you need it to be.

package java_project;

//"behaves-like-a" relationship
public interface Measurable { //Declares the abstract method that will be defined differently by classes.
	double getMeasure(); //Return type, name, parameters.
}

//Use "implements" keyword to get classes to conform to interfaces. Must define all methods that the
//interface had declared. Classes can implement multiple interfaces.

public class BankAccount implements Measurable, SecondInterface {
	double balance = 2.50;
	public double getMeasure() { //Required to implement this method.
		return balance;
	}
}

//All BankAccount objects are seen as instances of type Measurable as well. Similar to classes.
Measurable obj = new BankAccount();
//Can easily do typecasting between interface type and class type if obj is a BankAccount object.
BankAccount obj1 = (BankAccount) obj; //Useful for when you need to run BankAccount methods on object.

*/