/*

import java.util.Scanner; //To read input from the user through the console: Use Scanner class.

Scanner in = new Scanner(System.in); //Create Scanner object to read keyboard input.

System.out.print("Please enter your age: "); //Prompt the user.
int age = in.nextInt(); //Program waits for an int input to be assigned to variable age.
Note: in.nextDouble() for floating-point numbers, in.next() for strings.

in.close(); //Always close a Scanner object if no longer needed in order to prevent memory leak.

----------------------------------------------------------------------------------------------------------

double pi = 3.1415...;
System.out.printf("%.2f", pi); //Prints 3.14, pi but only 2 digits after the decimal. //NOT 10 whitespaces.
System.out.printf("Price per bottle:%10.2f", pi) //Prints "Price per bottle:      3.14" (10 chars long).

*/

package java_project;
import java.util.Scanner;

public class p93_Inputs_and_Formatting {
	private double radius;

	public p93_Inputs_and_Formatting(double radius) {
		this.radius = radius;
	}

	public double getVolume() {
		return ((4 * Math.PI * Math.pow(radius, 3)) / 3);
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter a value for the radius: ");
		double radius = in.nextDouble();
		//REMEMBER: MAKE IT EASY AND ALWAYS MAKE VARIABLES FOR NEW OBJECTS
		p93_Inputs_and_Formatting sphere = new p93_Inputs_and_Formatting(radius);
		System.out.printf("Volume: %.2f\n", sphere.getVolume());
		in.close();
		
		//REMEMBER: 2 PARAMETERS FOR FSTRINGS, .F FOR FLOATS, D FOR INTS
		for (int i = 1; i <= 12; i++) {
		     for (int j = 1; j <= 12; j++) {
		          System.out.printf("%4d", i*j); //Prints out a times table.
		     }
		     System.out.println();
		}
	}
}