/*

//REMEMBER: String.contains(x) used to check if a String contains a certain character.
//REMEMBER: PERCENTAGES SHOULD ALWAYS BE CONVERTED BY DIVIDING INPUT BY 100.0

switch-statements are somewhat similar to if-statements.

int day = 4;
switch (day) { //Parameter "day" compared to each case.
	case 6:
		System.out.println("Saturday"); //"break" needed or else all will run even after finding true.
		break;
	case 7:
		System.out.println("Sunday");
		break;
	default:
		System.out.println("Weekday"); //"default" used if no cases match.
} //Outputs "Weekday".

-----------------------------------------------------------------------------------------------------------

boolean data type has only two values: "true" and "false".

boolean operators:
and == &&
or == ||
not == !

Note: && and || still use short-circuit evaluation.
Note: Cannot test "0 < x < 100".

*/

//Example of nested if-statements and boolean operators.

package java_project;

public class p96_Switch_and_Boolean { //Doesn't need a constructor because of no need for an object.
	public static String alarmClock(int day, boolean vacation) { //Needs static keyword to test inside.
		if (vacation) {
			if (day == 7 || day == 0) {
				return "off";
			}
	
			else {
				return "10:00";
			}
		}
	
		else {
			if (day == 7 || day == 0) {
				return "10:00";
			}
	
			else {
				return "7:00";
			}
		}
	}
	
	public static void main(String[] args) {
		System.out.println(alarmClock(1, false)); //7:00
		System.out.println(alarmClock(5, false)); //7:00
		System.out.println(alarmClock(0, false)); //10:00
		System.out.println(alarmClock(4, true)); //10:00
		System.out.println(alarmClock(0, true)); //off
	}
}