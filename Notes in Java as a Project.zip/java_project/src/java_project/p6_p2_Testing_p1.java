//REMEMBER: MAIN METHODS USED TO ACTUALLY DO THINGS WITH CLASSES

package java_project;

public class p6_p2_Testing_p1 {
	public static void main(String[] args) {
		//Cannot directly access local variable from other class file (private).
		p6_p1_Instance_Vars count = new p6_p1_Instance_Vars(); //Creates Counter class from other class file.
		System.out.println(count.getValue()); //Prints 0.

		count.click(); //Increments local variable value.
		System.out.println(count.getValue()); //Prints 1.
		
		count.reset(); //Resets local variable value to 0.
		System.out.println(count.getValue()); //Prints 0.
		
		count.unclick();
		int result = count.getValue();
		System.out.println(result); //Prints -1.
	}
}

//Performing Encapsulation (Hiding Variables):
//Declare instance/local variables as private.
//Declare public methods that access instance variables.