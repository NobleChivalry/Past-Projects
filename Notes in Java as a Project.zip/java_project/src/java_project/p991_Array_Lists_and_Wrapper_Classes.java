//REMEMBER: You can predetermine the size of array lists.
//ArrayList<Object> numbers = new ArrayList<>(10); //size = 10

//Array Lists > Arrays
//Arrays are a bit more simple, but only use if you know you do not need to change array size.
//Note: You can change the values of an array. You cannot have initial values for an array list.

package java_project;
import java.util.ArrayList; //Must import array lists.

public class p991_Array_Lists_and_Wrapper_Classes {
	public static void main(String[] args) {
		//Arrays: Cannot insert elements into them or get them to grow/shrink.
		//Array Lists: More flexible, better to use. Can do all of the above.
		ArrayList<String> names = new ArrayList<String>(); //ARRAY LIST, TYPE, NAME, PARENTHESES
		names.add("Mario"); //You can use .add(x) to add new elements.
		System.out.println(names.get(0)); //You can use .get(x) to get an element at an index.
		names.add("Luigi");
		names.add(1, "Wario"); //Inserts Wario into index 1, moving all other elements to the right.
		names.get(1); //Returns Wario at index 1.
		names.set(2, "Waluigi"); //Sets whatever was at index 2 to something else.
		names.remove(1); //Removes whatever was at index 1.
		System.out.println(names); //Prints [Mario, Waluigi]
		
		System.out.println(names.size()); //Prints 2.
		System.out.println(names.get(names.size() - 1)); //Prints "Waluigi".
		for (String element : names) {
			System.out.println(element); //Prints each name inside of array list.
		}

		ArrayList<String> newNames = new ArrayList<String>(names); //Copies over the same contents.
		for (String element : newNames) {
			System.out.println(element); //Prints each name inside of array list.
		}
		
		//Note: Primitive types cannot be naturally used for array lists. Must be placed into a wrapper
		//first, turning it into an object (primitive = immutable).
		ArrayList<Double> numbers = new ArrayList<Double>();
		//Double wrapper = 29.95; //Auto-boxing: Automatically converts between Double and double.
		//double num = wrapper; //Can easily convert from Double to double like so.
		numbers.add(29.95);
		System.out.println(numbers); //Prints [29.95].

		//Many wrapper classes exist, such as Integer, Double, Boolean, Character, etc.

	}
}