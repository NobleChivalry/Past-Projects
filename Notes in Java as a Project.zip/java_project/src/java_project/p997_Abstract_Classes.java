/*

REMEMBER: Java does not support multiple inheritance. A subclass can only inherit from 1 superclass.

Abstract Classes: Cannot be instantiated. Simply just a class with placeholder methods for subclasses to
override in the future, since subclasses will vary on how they override the abstract methods.

Can have whatever methods, but must have abstract methods of no definition. "final" keyword used for
methods that should not be overrode by subclasses. Subclasses must override all abstract methods of the
parent class, or else code will break.

"abstract void" methods of "abstract class", like a template for subclasses.

*/

package java_project;

public abstract class p997_Abstract_Classes { //"abstract" disallows the creation of object of type p997.
	//Pet class example.
	private String owner;
	private String name;

	public p997_Abstract_Classes(String owner, String name) {
		this.owner = owner;
		this.name = name;
	}
	
	public String getName() { //Examples of normal inherited methods.
		return name;
	}
	
	public String getOwner() {
		return owner;
	}
	
	public abstract void play(); //Examples of abstract methods to be overrode.
	
	public abstract void speak(); //Ex: Dogs and cats speak differently.
}