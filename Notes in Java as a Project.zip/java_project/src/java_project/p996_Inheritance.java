//REMEMBER: For a subclass to update the private instance variable of its superclass, it needs to do so
//through the use of a public method of its superclass. A subclass has no access to the private instance
//variables of its superclass.

//REMEMBER: ClassB extends from Class A.
//ClassA test = new ClassB();
//You can only use methods of ClassA on your ClassB object.
//Must convert into ClassA first through typecasting.
//ClassB test1 = (ClassB) test;

/*

REMEMBER: If you want to call the parent class's constructor method in the subclass's constructor, just
type in "super(x)". After that, you still have to set the parameters to instance variables.

REMEMBER: Use "extends" keyword. Only can use public methods and public instance variables (inherited).
Is-a relationship. Inherits everything, but cannot access everything (private stuff). Can only be accessed
by calling superclass itself. Only need to call superclass when overriding a superclass method. Static
methods cannot be overrode.

Polymorphism: You can pass Car objects into parameters that require Vehicle objects because Car objects
inherit from Vehicle objects. Car objects can be referred to as Vehicle objects. Methods will call on
Car's version of the drive method if the object is a Car, Vehicle's version if it is simply a Vehicle.
Prioritizes most specific version of methods.

Subclasses can inherit and override methods and properties of its parent/super class. For example, class
Car and Truck can be subclasses of class Vehicle, since they both share the common trait of transporting
people from one place to another with their parent class Vehicle.

Inheritance helps reuse code by allowing subclasses to inherit the same methods as their parent class
and allowing subclass objects to be recognized as parent class objects.

All subclasses are meant to be specialized types of their parent class (ex: a Car is a type of Vehicle).
Example: Should class Quiz inherit from class Question? No, Quiz IS NOT A Question (is-a).

Java only supports single inheritance, it cannot extend more than one class. Subclasses need to differ.
Subclass inherit all PUBLIC methods, can override those methods, and can declare new methods.

*/

package java_project;

public class p996_Inheritance extends p994_Packages { //p996 is an extension/subclass of class p994.
	//New methods can be added.
	//Old methods can be overrode. Names, return types, and parameter variables need to be the same.
	//Overloading is different. Can have same name, but everything else is different (new method).
	
	//Inherits main method of p994_Packages. Inputting anything will output it.

	//This is an example of overriding. Can only call superclass methods inside of overriding methods.
	public void amogus() {
		super.amogus(); //Prints "amobus" by calling on method of parent class with "super" keyword.
		System.out.println("amogus"); //Prints "amogus".
	}
	
	//This is an example of overloading. Redefines the body of the old main method for this subclass in a
	//static context. Can also redefine parameters.
	public static void main(String[] args) {
		java.util.Scanner in = new java.util.Scanner(System.in);
		System.out.println(in.next() + "!"); //Prints with exclamation point at the end instead.
		in.close();
	}
}