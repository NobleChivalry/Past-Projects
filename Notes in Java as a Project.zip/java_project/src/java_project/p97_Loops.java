package java_project;
import java.util.Scanner;

public class p97_Loops {
	public static void main(String[] args) {

		//while loops based on repeating process until condition met and last iteration finished.
		int count = 0; //DO NOT forget to update variable to meet end condition.
		while (count != 3) { //REMEMBER: All values declared inside of code blocks are LOCAL.
			count += 1;
			System.out.println("Iteration " + count); //Prints Iterations 1 to 3.
		}
		System.out.println(); //Prints empty line.
		
		//do loops are post-test loops, condition being checked after completing the loop body.
		//Basically, you are guaranteed that the body of the CODE WILL BE EXECUTED AT LEAST ONCE.
		Scanner in = new Scanner(System.in);
		int count1 = in.nextInt();
		do {
			System.out.println("Iteration " + count1); //Counts down from positive numbers to 0.
			count1--; //If given 0 or negative numbers, just prints that one iteration.
		} while (count1 >= 0); //while statement contains statement that needs to be met thereafter.
		in.close(); //Ex: Iteration -1.
		System.out.println();
		
		//REMEMBER: INITIALIZATION; CONDITION; UPDATE (executes before each update)
		//For loops can be used to replace while loops that end based on a counter variable.
		//Good for loops that have starting and ending values with constant increments/decrements.
		for (int i = 1; i <= 10; i++) { //Starts at 1, condition needs to be met, updates counter variable.
			System.out.println(i); //Counts from 1 to 10.
		}
		for (int i = 0; i <= 10; i = i + 2) { //Starts at 0, counter increments by 2.
			System.out.println(i); //Counts 0 and even numbers from 0 to 10.
		}
		System.out.println();
		
		//You can create nested loops, just like in Python. Here's an example! :D
		for (int i = 0; i <= 5; i++) {
			for (int j = 0; j <= 2; j++) {
				System.out.println(j); //Prints 0, 1, and 2 for each iteration over i (5-0+1 times).
			}
		}
		//REMEMBER:
		/*
		While loops are best used when we are not certain how many iterations it will take to end.

		For loops are best used when we know how many iterations it will take to end.

		Do loops are best used when our body of code needs to be executed at least once.
		*/
	}
}