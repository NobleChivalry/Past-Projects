//REMEMBER:
//Place hw1.problem1.TicTacToeTester inside of a package. Your homework is located at: /home/me/ics45j
//Placed the class in: /home/me/ics45j/hw1/problem1 (directory).

/*

REMEMBER: java is not package, java.util and java.lang are packages, java.lang.Math is a class.
REMEMBER: You do not need import statements to use classes from other packages (not default or java.lang).

Package: A set of related classes. You must make sure to always declare what package your class is a part
of near the beginning of the class. Identifiers separated by periods (ex: java.util). Should always have
unique identifiers.

Example (turning domain backwards to show ownership): edu.uci.ics.emilyo OR edu.uci.ics45j;
Note: All periods represent a change in directory. "emilyo" is a subdirectory of directory "ics".
The base directory is "edu".

Never need to import a class that is inside of the same package as your class. Never import java.lang.

*/

package java_project; //Package that this class belongs to.
//import java.util.*; //Ends up importing all classes inside of the java.util package.

public class p994_Packages {
	public void amogus() {
		System.out.println("amobus"); //Inherited method.
	}
	
	public static void main(String[] args) {
		//Inconvenient, but you don't need to import statement to use Scanner.
		java.util.Scanner in = new java.util.Scanner(System.in);
		System.out.println(in.next());
		in.close();
	}
}