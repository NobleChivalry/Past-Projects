//Whenever you make a class, you should always create a unit test class for it (helps make sure changes do
//not break your code). JUnit tests are widely used and built into some IDE's like Eclipse.

//Name of test class should always end in "Test".


/*

package java_project;
import org.junit.Test; //Needed for testing.
import org.junit.Assert; //Used to check values.

public class p995_Unit_Test {
	@Test public void method_to_be_tested() {
		. . .
		Assert.assertEquals(expected, value, EPSILON); //EPSILON for how large difference can be (double).
	}
	//More test cases
	. . .
}

*/