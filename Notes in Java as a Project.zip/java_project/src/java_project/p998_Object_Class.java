/*

All classes are derived from the Object class, all subclasses inheriting all of its methods.
The only thing that is not of type Object is null.
This is valid: Object obj = "String";

Inherited Methods
-
toString: yields a string describing the object. //Rectangle objects return "java.awt.Retangle[ . . . ]"
equals: compares objects with each other.
hashCode: yields a numerical code for storing the object in a set.

Most classes override the toString method to make the printed class objects look more user-friendly, such
as the Rectangle class. The toString method is also used when concatenating a non-string to a string.
If not overrode, will return format "[Object Type][Hash Code]".

equals method checks to see if a certain object has the same contents as another object, returning either
true or false. Must look like "public boolean equals(Object otherObject)" and then cast otherObject to
your class's type (ex: Stamp other = (Stamp) otherObject;). Ending: "		&& value == other.value;".

public boolean equals(Object otherObject) {
	//Safe casting. Not sure if can compare to a certain class.
	if (otherObject instanceof ClassName) { //Returns true if otherObject is of type ClassName.
		ClassName other = (ClassName) otherObject;
		return ( . . . );
	}
}

*/