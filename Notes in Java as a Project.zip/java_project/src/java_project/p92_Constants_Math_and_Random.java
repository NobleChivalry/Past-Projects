/*

Every value in Java either refers to a an object or one of the 8 primitive types.

Primitive types: boolean, byte, char, short, int, long, float, double
Main ones: boolean, char, int, double

If it has a number in it, it is a number literal. Decimal = double, no decimal = int. No commas.
It's okay to set a double variable to an int number literal (not vice versa). No decimal in ints AT ALL.

Constant variables: Values cannot be changed by any code. Use keyword "final". Inside of a method.
final double quarterValue = 0.25;

REMEMBER: SHOULD USE A NAMED CONSTANT FOR PI AND E, "PUBLIC STATIC FINAL" AT FRONT
If constant values needed in multiple methods: Use keywords "public static final". Inside of a class.
static = Belongs to class, not method/instance; public = accessible in all of class.
public static final double PI = 3.14;

----------------------------------------------------------------------------------------------------------

Arithmetic Operators: +, -, *, /, %

Mixing ints w/ doubles will always result in decimals.
When a value cannot be calculated exactly, it will be rounded to nearest match.
double f = 4.35; System.out.println(100 * f); //Does not print 435, prints very long and close numbers.

Increment/Decrement Operators:
++ operator adds one to a number literal. (counter++;)
-- operator subtracts one from a number literal. (counter--;)

Integer Division: If either one of the number literals are a double, the calculation will be accurate.
If they are both ints, the answer will be a rounded-down int. Always use double for when expecting
decimal results.

Division/Remainder Tips:
n = 729
n % 10 = 9 //Last Digit
n % 100 = 29 //Last 2 Digits
n / 10 = 72 //All but Last Digit
n / 100 = 7 //All but Last 2 Digits
n / 10.0 = 72.9 //Accurate Answer
-n % 10 = -9 //Negative Last Digit
4 % 2 = 0 //Even Numbers Only
3 % 2 = 1 //Odd Numbers Only

Math Class Methods:
Math.sqrt(x)
Math.pow(x, y)
Math.sin(x)
Math.cos(x)
Math.tan(x)
Math.round(x) //Gives nearest integer.
Math.ceil(x)
Math.toRadians(x) //Degrees to radians.
Math.abs(x)
Math.max(x, y) //Larger of x and y.
Math.min(x, y) //Smaller of x and y.
Math.exp(x) //e^x
Math.log(x) //ln(x)
Math.log10(x) //log(x)
Math.floor(x)
Math.toDegrees(x) //Radians to degrees.

Converting Floating-Point Numbers to Integers: Use cast operator "(int)". Note, Math.round(x) gives int.
double balance = total + tax;
int dollars = (int) balance; //Chops off the decimal (rounding down).

Math.random() generates a random floating-point number within range [0, 1). Typecasting required to
convert to int.
(int)(Math.random() * range) + min //NEED parentheses. Else, you'll get min.
range = max - min + 1
min = first number in range (0)

REMEMBER:
(int)(Math.random() * range) + min //[min, min+range)
(int) Math.random() * range + min //min

*/