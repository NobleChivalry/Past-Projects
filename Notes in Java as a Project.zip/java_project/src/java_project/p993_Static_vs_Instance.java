/*

REMEMBER: Instance methods are methods that require the use of objects. Static methods do not require the
use of objects, using the class that they belong to as their implicit parameter.

REMEMBER: You can make all methods and variables static and call them in the main method, but it would be
impractical because it is easier to use objects to manage complex programs.

REMEMBER: Math.PI and Math.E are examples of static constants.

"private static" variables belong to the class itself, not to any object of the class.
All objects of the class will share the same static variable values. Can be changed.

"static final" variables can be either public or private, since they can either be changeable or
not changeable.

Static variables exist in their own space in memory, separate from all of the existing class objects that
know the location of the static variable and can access them.

There are also static methods, which are always called on by the class itself, having the class as the
implicit parameter and not a class object (ex: Math.sqrt(4)).

*/

package java_project;

public class p993_Static_vs_Instance {
	private double balance; //Each class object may have its own values of for non-static variables,
	private int accountNumber; //but all of them will share the same values for the static variables.
	private static double api = 0.20; //Should always be declared as private. Can be changed.
	public static final String bank_address = "123 Orange Rd"; //Static constants can be private OR public.
	
	public p993_Static_vs_Instance(double balance, int accountNumber) {
		this.balance = balance;
		this.accountNumber = accountNumber;
	}
	
	public static String getAddress() {
		return bank_address;
	}

	public static void main(String[] args) {
		System.out.println(p993_Static_vs_Instance.getAddress());
		//This is an example of a static method. The class itself is used to call its own main method.
		//First method of a program must always be a static main method, due to no existing objects yet.
		//class_name.method_name(x);
	}
}