package java_project;

import java.awt.Rectangle;

public class p5_Mutability_and_Get {
	public static void main(String[] args) {
		Rectangle box1 = new Rectangle(5, 10, 20, 30); //Creates a new Rectangle object.
		Rectangle box2 = new Rectangle(5, 10, 20, 30); //Creates a new Rectangle object.
		Rectangle box3 = box1; //Variable box3 refers to object that box1 refers to (same location memory).
		box1.translate(1, 1);

		System.out.println(box1); //Both prints "java.awt.Rectangle[x=6,y=11,width=20,height=30]".
		System.out.println(box3); //Custom class objects are mutable.

		int num1 = 1; //Numbers are not objects (immutable). Variable num refers to actual value of 1.
		int num2 = 1; //Does not create new object different from num1.
		int num3 = num1;
		num1 = num1 + 1; //Ex: Only num1 becomes 2, not num3.
		
		System.out.println(num1); //Prints 2.
		System.out.println(num3); //Prints 1.
		
		Rectangle box = new Rectangle(5, 10, 20, 30);
		box.translate(1, 1); //Shifts Rectangle object right 1 and up 1 (mutator method).
		System.out.println(box.getX()); //Returns top left corner's x-coordinate of 6.0 (accessor method).
		System.out.println(box.getY()); //Returns top left corner's y-coordinate 11.0 (accessor method).
	}
}