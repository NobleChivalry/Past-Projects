/*

//REMEMBER: When you implement the Comparable interface, make sure to do something like this to not need
//to convert the Object parameter:
//ClassName implements Comparable<ClassName>

//REMEMBER: When implementing methods for an interface, make sure to typecast its parameters to whatever
//you need it to be inside of your class.

//REMEMBER: Arrays.sort(x) is a mutate method. The String class implements the Comparable interface.

Comparable Interface in standard Java library. Has only 1 method, the compareTo method. Similar to the
String class's compareTo method.

public interface Comparable {
	int compareTo(Object otherObject);
}

//If a comes before b, returns negative.
//If a comes after b, returns positive.
//If a and b are the same, return zero.

a.compareTo(b) < 0 //a is before
a.compareTo(b) > 0 //a is after
a.compareTo(b) == 0 //a is same

If you implement a compareTo method for your class, you can call the Arrays.sort(x) method on an array
of those class objects to get a proper result.

*/

//---------------------------------------------------------------------------------------------------------

/*

//REMEMBER: Callbacks usually used in the case of creating interfaces for classes that you do not control
//(ex: Rectangle class). Helper classes are classes that take the place of classes that we do not have
//access to, implementing the interface themselves. Use the helper class for its implemented methods,
//since helper class objects should be a parameter in the test methods that we are using.

You can only implement your Measurable to classes that you can control, meaning you can't implement it to
things like the Rectangle class. Plus, you can only measure objects in one way.

We can fix this by using a callback. A callback is a way to execute code at a later time. Basically, you
can create a helper class that implements the Measurable interface and then cast the parameters to type
Rectangle and work with Rectangle methods/attributes.

You can do this for several other ways to measure the Rectangle class, including area, width, and length.
Only the helper classes know of Rectangle.

The method that will be used to test the interface will have an array of Objects and a helper class as the
parameters. After that, you just have to pass each Object into the helper class to find their measure.

*/

//---------------------------------------------------------------------------------------------------------

/*

An inner class is a class declared inside of another class. Useful for when you know you won't be needing
to use that inner class outside of the class it is in. Useful for insignificant classes and when you won't
be needing to use it outside of the class.

Declaring it inside of a class's method means that it will only be accessible inside of that method. If not
in a method, accessible for all methods.

You would only put an inner class inside of a class but outside any of its methods when more than 1 of the
methods need to be able to access that inner class.

*/