package java_project;

//REMEMBER: PRIVATE INSTANCE VARIABLES = STATIC LOCAL VARIABLES OF METHODS

//This is how you create an instance variable of a class object. Must always be private.
//Use public methods to access private instances. Can reuse name "value" this way.
//Behaves like a local variable: private, type, value, ;

//Counter class example.
public class p6_p1_Instance_Vars {
	private int value; //Local variable to keep track of a number. Defaults to 0.
	//Cannot be accessed outside of this class file.
	
	public int getValue() { //Public method with access to private variables inside of the shared class.
		return value;
	}
	
	public void click() { //Public method, returns nothing, doesn't require parameters, called click.
		value = value + 1; //Increments local variable "value".
		//value += 1;
	}
	
	public void reset() {
		value = 0;
	}
	
	public void unclick() {
		value = value - 1;
		//value -= 1;
	}
}