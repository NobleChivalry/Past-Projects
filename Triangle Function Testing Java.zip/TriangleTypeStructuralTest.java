import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TriangleTypeStructuralTest {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testLine1() {
		TriangleType object = new TriangleType();
	}
	
	@Test
	public void testLine18() {
		assertEquals(TriangleType.triangleType(1, 0, 0), 4);
		assertEquals(TriangleType.triangleType(0, 1, 0), 4);
		assertEquals(TriangleType.triangleType(0, 0, 1), 4);
		
		assertEquals(TriangleType.triangleType(1, 1, 0), 4);
		assertEquals(TriangleType.triangleType(1, 0, 1), 4);
		assertEquals(TriangleType.triangleType(0, 1, 1), 4);
		assertEquals(TriangleType.triangleType(0, 0, 0), 4);
	}
	
	@Test
	public void testLine24() {
		assertEquals(TriangleType.triangleType(1001, 1, 1), 5);
		assertEquals(TriangleType.triangleType(1, 1001, 1), 5);
		assertEquals(TriangleType.triangleType(1, 1, 1001), 5);
		
		assertEquals(TriangleType.triangleType(1001, 1001, 1), 5);
		assertEquals(TriangleType.triangleType(1001, 1, 1001), 5);
		assertEquals(TriangleType.triangleType(1, 1001, 1001), 5);
		assertEquals(TriangleType.triangleType(1001, 1001, 1001), 5);
	}
	
	@Test
	public void testLine41() {
		assertEquals(TriangleType.triangleType(1, 2, 3), 4);
		assertEquals(TriangleType.triangleType(3, 1, 2), 4);
		assertEquals(TriangleType.triangleType(1, 3, 2), 4);
	}
	
	@Test
	public void testLine53() {
		assertEquals(TriangleType.triangleType(1, 1, 2), 4);
		assertEquals(TriangleType.triangleType(2, 2, 1), 2);
	}
	
	@Test
	public void testLine55() {
		assertEquals(TriangleType.triangleType(1, 2, 1), 4);
		assertEquals(TriangleType.triangleType(2, 1, 2), 2);
	}
	
	@Test
	public void testLine57() {
		assertEquals(TriangleType.triangleType(2, 1, 1), 4);
		assertEquals(TriangleType.triangleType(1, 2, 2), 2);
	}
}