import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TriangleTypeFunctionalTest {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testScalene() {
		assertEquals(TriangleType.triangleType(4, 6, 9), 1);
		assertEquals(TriangleType.triangleType(444, 666, 999), 1);
	}
	
	@Test
	public void testIsosceles() {
		assertEquals(TriangleType.triangleType(1, 2, 2), 2);
		assertEquals(TriangleType.triangleType(500, 1000, 1000), 2);
	}
	
	@Test
	public void testEquilateral() {
		assertEquals(TriangleType.triangleType(1, 1, 1), 3);
		assertEquals(TriangleType.triangleType(1000, 1000, 1000), 3);
	}
	
	@Test
	public void testNot() {
		assertEquals(TriangleType.triangleType(0, 0, 0), 4);
		assertEquals(TriangleType.triangleType(-1, -1, -1), 4);
		assertEquals(TriangleType.triangleType(1, 2, 3), 4);
	}
	
	@Test
	public void testOut() {
		assertEquals(TriangleType.triangleType(1001, 1001, 1001), 5);
	}
}