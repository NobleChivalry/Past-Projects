#include "String.h"
#include "Alloc.h"

bool String::in_bounds(int i) {
	if (i >= 0 && i < static_cast<int>(strlen(buf))) {
		return true;
	}
	else {
		return false;
	}
}

size_t String::strlen(const char* s) {
	int counter = 0;
	for (const char* p = s; *p != '\0'; ++p) {
		counter++;
	}
	return counter;
}

char* String::strcpy(char* dest, const char* src) {
	int counter = 0;
	for (const char* p = src; *p != '\0'; ++p) {
		dest[counter] = *p;
		counter++;
	}
	dest[counter] = '\0';
	return dest;
}

char* String::strncpy(char* dest, const char* src, int n) {
	if (strlen(src) == 0 || n < 0) {
		return dest;
	}
	else if (n < static_cast<int>(strlen(src))) {
		for (int i = 0; i <= n; i++) {
			dest[i] = src[i];
		}
		dest[n + 1] = '\0';
	}
	else if (n > static_cast<int>(strlen(src))) {
		int end = strlen(src) - 1;
		for (int i = 0; i <= end; i++) {
			dest[i] = src[i];
		}
		dest[strlen(src)] = '\0';
	}
	return dest;
}

char* String::strdup(const char* s) {
	char* result = Alloc::new_char_array(strlen(s) + 1);
	return strcpy(result, s);
}

char* String::strcat(char* dest, const char* src) {
	char* temp = Alloc::new_char_array(strlen(dest) + strlen(src) + 1);
	strcpy(temp, dest);
	if (strlen(src) == 0) {
		Alloc::delete_char_array(dest);
		dest = temp;
		return dest;
	}
	int index = 0;
	int counter = 0;
	int end = strlen(dest) + strlen(src) - 1;
	for (int i = strlen(dest); i <= end; i++) {
		temp[i] = src[counter];
		index = i;
		counter++;
		if (src[counter] == '\0') {
			break;
		}
	}
	temp[index + 1] = '\0';
	Alloc::delete_char_array(dest);
	dest = temp;
	return dest;
}

char* String::strncat(char* dest, const char* src, int n) {
	char* temp = Alloc::new_char_array(strlen(dest) + strlen(src) + 1);
	strcpy(temp, dest);
	if (strlen(src) == 0) {
		Alloc::delete_char_array(dest);
		dest = temp;
		return dest;
	}
	int index = 0;
	int counter = 0;
	for (int i = strlen(dest); counter <= n - 1; i++) {
		temp[i] = src[counter];
		index = i;
		counter++;
		if (src[counter] == '\0') {
			break;
		}
	}
	temp[index + 1] = '\0';
	Alloc::delete_char_array(dest);
	dest = temp;
	return dest;
}

int String::strcmp(const char* left, const char* right) {
	if (strlen(left) >= strlen(right)) {
		int end = strlen(left) - 1;
		for (int i = 0; i <= end; i++) {
			if (left[i] > right[i]) {
				return 1;
			}
			else if (left[i] < right[i]) {
				return -1;
			}
		}
	}
	else if (strlen(left) < strlen(right)) {
		int end = strlen(right) - 1;
		for (int i = 0; i <= end; i++) {
			if (left[i] > right[i]) {
				return 1;
			}
			else if (left[i] < right[i]) {
				return -1;
			}
		}
	}
	return 0;
}

int String::strncmp(const char* left, const char* right, int n) {
	for (int i = 0; i <= n - 1; i++) {
		if (left[i] > right[i]) {
			return 1;
		}
		else if (left[i] < right[i]) {
			return -1;
		}
	}
	return 0;
}

void String::reverse_cpy(char* dest, const char* src) {
	int counter = 0;
	for (int i = strlen(src) - 1; i != -1; i--) {
		dest[counter] = src[i];
		counter++;
	}
	dest[counter] = '\0';
}

char* String::strchr(char* str, char c) {
	for (char* p = str; *p != '\0'; ++p) {
		if (*p == c) {
			return p;
		}
	}
	return nullptr;
}

char* String::strstr(char* haystack, const char* needle) {
	int needle_len = strlen(needle);
	for (char* p = haystack; (p = strchr(p, needle[0])); ++p) {
		if (strncmp(p, needle, needle_len) == 0) {
			return p;
		}
	}
	return nullptr;
}

const char* String::strstr(const char* haystack, const char* needle) {
	return const_cast<const char*>(strstr(const_cast<char*>(haystack), needle));
}

String::String(const char* s) {
	buf = strdup(s);
}

String::String(const String& s) {
	buf = strdup(s.buf);
}

String::String(String&& s) {
	buf = s.buf;
	s.buf = nullptr;
}

String& String::operator =(String&& s) {
	Alloc::delete_char_array(buf);
	buf = s.buf;
	s.buf = nullptr;
	return *this;
}

String& String::operator =(const String& s) {
	Alloc::delete_char_array(buf);
	buf = strdup(s.buf);
	return *this;
}

char& String::operator [](int index) {
	if (in_bounds(index)) {
		return buf[index];
	}
	else if (strlen(buf) == 0) {
		buf[0] = '\0';
		return buf[0];
	}
	else {
		cout << "ERROR: Index Out Of Bounds" << endl;
		return buf[0];
	}
}

size_t String::size() {
	return strlen(buf);
}

String String::reverse() {
	String result = String(buf);
	reverse_cpy(result.buf, buf);
	return result;
}

int String::indexOf(const char c) {
	int counter = 0;
	for (char* p = buf; *p != '\0'; ++p) {
		if (*p == c) {
			return counter;
		}
		counter++;
	}
	return -1;
}

int String::indexOf(const String s) {
	char* point = strstr(buf, s.buf);
	if (point != nullptr) {
		int end1 = strlen(buf) - 1;
		for (int i = 0; i <= end1; i++) {
			if (buf[i] == s.buf[0]) {
				bool match = true;
				int counter = 0;
				int end2 = i + strlen(s.buf) - 1;
				for (int j = i; j <= end2; j++) {
					if (buf[j] != s.buf[counter]) {
						match = false;
						break;
					}
					counter++;
				}
				if (match == true) {
					return i;
				}
			}
		}
	}
	if (strlen(s.buf) == 0) {
		return strlen(buf);
	}
	return -1;
}

bool String::operator ==(const String s) {
	if (strcmp(buf, s.buf) == 0) {
		return true;
	}
	return false;
}

bool String::operator !=(const String s) {
	if (strcmp(buf, s.buf) != 0) {
		return true;
	}
	return false;
}

bool String::operator >(const String s) {
	if (strcmp(buf, s.buf) == 1) {
		return true;
	}
	return false;
}

bool String::operator <(const String s) {
	if (strcmp(buf, s.buf) == -1) {
		return true;
	}
	return false;
}

bool String::operator <=(const String s) {
	if (strcmp(buf, s.buf) == -1 || strcmp(buf, s.buf) == 0) {
		return true;
	}
	return false;
}

bool String::operator >=(const String s) {
	if (strcmp(buf, s.buf) == 1 || strcmp(buf, s.buf) == 0) {
		return true;
	}
	return false;
}

String String::operator +(const String s) {
	String result = String(buf);
	result.buf = strncat(result.buf, s.buf, strlen(s.buf));
	return result;
}

String& String::operator += (const String s) {
	buf = strncat(buf, s.buf, strlen(s.buf));
	return *this;
}

void String::print(ostream& out) {
	out << buf;
}

void String::read(istream& in) {
	char c[1024];
	in >> c;
	Alloc::delete_char_array(buf);
	buf = strdup(c);
}

String::~String() {
	Alloc::delete_char_array(buf);
}

ostream& operator << (ostream& out, String s) {
	s.print(out);
	return out;
}

istream& operator >> (istream& in, String& s) {
	s.read(in);
	return in;
}