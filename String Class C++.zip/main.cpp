#include <iostream>
using namespace std;
#include "String.h"
#include "Alloc.h"

void test_constructors_and_print() {
	cout << "Constructor and operator << TESTS" << endl;

	String s1("Hello World");
	cout << "\"" << s1 << "\"" << endl;

	String s2(s1);
	cout << "\"" << s2 << "\"" << endl;

	String s3 = String("Hello World");
	cout << "\"" << s3 << "\"" << endl;

	cout << endl;
}

void test_assignment() {
	cout << "Assignment TESTS" << endl;

	String s1("Hello World");
	cout << "\"" << s1 << "\"" << endl;
	String s2("Hey World");
	s1 = s2;
	cout << "\"" << s1 << "\"" << endl;

	String s3("Hello World");
	cout << "\"" << s3 << "\"" << endl;
	s3 = String("Hey World");
	cout << "\"" << s3 << "\"" << endl;

	cout << endl;
}

void test_relationals() {
	cout << "Relational TESTS" << endl;

	String s1("A");
	String s2("A");
	cout << (s1 == s2) << endl;
	cout << (s1 != s2) << endl;

	String s3("A");
	String s4("B");
	cout << (s3 < s4) << endl;
	cout << (s3 >= s4) << endl;

	String s5("B");
	String s6("A");
	cout << (s5 > s6) << endl;
	cout << (s5 <= s6) << endl;

	cout << endl;
}

void test_reverse() {
	cout << "Reverse TESTS" << endl;

	String s1("A");
	cout << "\"" << s1.reverse() << "\"" << endl;
	
	String s2("AB");
	cout << "\"" << s2.reverse() << "\"" << endl;

	String s3("ABC");
	cout << "\"" << s3.reverse() << "\"" << endl;

	String s4("");
	cout << "\"" << s4.reverse() << "\"" << endl;

	cout << endl;
}

void test_concatenate() {
	cout << "Concatenate TESTS" << endl;

	String s1("AB");
	String s2("CD");
	cout << "\"" << (s1 + s2) << "\"" << endl;

	String s3("AB");
	String s4("");
	cout << "\"" << (s3 + s4) << "\"" << endl;

	String s5("");
	String s6("CD");
	cout << "\"" << (s5 + s6) << "\"" << endl;

	String s7("");
	String s8("");
	cout << "\"" << (s7 + s8) << "\"" << endl;

	cout << endl;
}

void test_indexOf() {
	cout << "indexOf TESTS" << endl;

	String s1("ABCDEFGABCDEFG");
	cout << s1.indexOf('A') << endl;
	cout << s1.indexOf('D') << endl;
	cout << s1.indexOf('G') << endl;
	cout << s1.indexOf('!') << endl;
	cout << s1.indexOf('\0') << endl;
	cout << "-" << endl;

	cout << s1.indexOf(String("ABCDEFGABCDEFG")) << endl;
	cout << s1.indexOf(String("BCDEFG")) << endl;
	cout << s1.indexOf(String("BCDEF")) << endl;
	cout << s1.indexOf(String("BCDE!")) << endl;
	cout << s1.indexOf(String("B")) << endl;
	cout << s1.indexOf(String("GAB")) << endl;

	cout << endl;
}

void test_read() {
	cout << "indexOf TESTS" << endl;

	String s = String();
	cin >> s;
	cout << s << endl;

	cout << endl;
}

int main() {
	test_constructors_and_print();
	test_assignment();
	test_relationals();
	test_reverse();
	test_concatenate();
	test_indexOf();
	test_read();

	Alloc::report_allocations();
	return 0;
}