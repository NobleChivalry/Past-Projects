#.rstrip() removes all whitespace, tabs, and newlines on the right side of a
#string, while .lstrip() removes them on the left side of the string.
#Note: .rstrip("\n") is good for when you have to read files.
string = "apple\n" #Removes the first "\n" and everything to the right of it.
string = string.rstrip()
print(string) #Prints "apple", not "apple\n".

#Similar to read() method but more efficient.
#line is a string, so it's not mutable. Have to redeclare line.
'''
for line in open(file_name):
    line = line.rstrip("\n")
    print(line)
'''
#Similar to readlines() method but more efficient.
#Uses list comprehension to split strings by every "\n".
'''
line_list = [line.rstrip("\n") for line in open(file_name)]
'''

#Versions using the "with" statement instead.
#For efficient read() method.
'''
with open(file_name) as file:
    for line in file:
        print(line.rstrip("\n"))
'''
#For efficient readlines() method.
'''
with open(file_name) as file:
    for line in file:
        print(line.rstrip("\n"))
'''

#parse_lines function can be used to take a string and separate certain parts of
#it to be converted into certain types.
def parse_lines(file, sep, conversions):
    for line in file:
        yield [conv(item) for conv, item in
                    zip(conversions, line.rstrip("\n").split(sep))]
#Example of formatted text file required:
#Bob Smith,75,80
#Mary Jones,85,90
'''
for fields in parse_lines(open(file_name), ",", (str, int, int)):
    print(fields[0], (fields[1] + fields[2]) / 2)
'''
#Creates a list called fields and then uses each element for the print.
#Example: ["Bob Smith", 75, 80]

#Changing conversions parameter to (str, int) would give: ["Bob Smith", 75]
#Accessing fields[2] would therefore give an error.

#Continues to loop over the zip until out of arguments, so a 4-string would
#still return a 3-list.

#parse_lines unpacks 3 things, so you could do something like:
'''
for name, num1, num2 in parse_lines(open(file_name), ",", (str, int, int)):
    print(name, (test1 + test2) / 2)
'''

#Python files are really just text files read by Python.
#Storing data in binary files sacrifices readability for efficiency.
#The pickle module is used to help with efficiency and lessen complexity when
#dealing with binary files.
import pickle
'''
pickle.dump(obj, open_file) #Returns None
pickle.load(open_file) #Returns value of pickled data structure
'''
dicti = dict(a=1, b=2, c=3) #Creates a dictionary with keys and values.

#"wb" is the write binary file mode (creates a file).
#Stores the dictionary in binary using the .dump() function.
with open("pickletest.dat", "wb") as storage:
    pickle.dump(dicti, storage) #Stores the pickled dictionary.

#"rb" is the read binary file mode.
#Reads the dictionary in ASCII using the .load() function.
with open("pickletest.dat", "rb") as storage:
    dicti = pickle.load(storage) #Decrypts the pickled dictionary.
print(dicti) #Prints the original dictionary that was pickled.

#You can format integers in order to divide each section of them by 3 digits.
num = 2**100
print(num) #Prints 1267650600228229401496703205376
num = "{0:,}".format(num)
print(num) #Prints 1,267,650,600,228,229,401,496,703,205,376

#Custom goody module allows the use of for looping with a range that includes
#the last value in the range (irange = inclusive range).
'''
from goody import irange
for x in irange(1, 10):
    print(x)
''' #Prints numbers 1-10.
#The frange function in the goody module allows iteration over an inclusive
#range of floating-point numbers.
'''
from goody import frange
for x in frange(0., 1., .5):
    print(x)
''' #Prints 0.0, 0.5, 1.0. There will be errors at times (small numbers).

#All functions in Python are ones that are defined by the need for parameters
#and arguments for their calls, indicated by parantheses. In a way, print
#statements are simply built-in functions in disguise.

#There are 4 scopes in Python that go by LEGB, being from smallest to greatest.
#Local, Enclosed (encloses local scopes), Global, and Built-In. By default,
#declarations of bounding objects to names make the object in question a part of
#the current scope it is in. These can be changed by using global statements and
#nonlocal statements. Searches from smallest to greatest accessible scopes.

#import method is safest because it uses the built-in scope, from import method
#is less safe because it uses the global scope, and the from import * method
#is not safe because it pollutes the global namespace.

#Functions are usually things that you call with arguments. Methods are usually
#things that you call on objects/instances with arguments.
#Example: .sort() is a method and sorted() is a function.

#Methods are simply taking the instance they see that is being modified and
#bounding them to the first parameter of the object type, object types actually
#being modules.
#NOTE: METHODS ARE JUST FUNCTIONS THAT USE OBJECT TYPE-MODULES.
#METHODS: OBJECT TYPES = BUILT-IN MODULES.
print("candide".replace("d", "p")) #Both print out "canpipe".
print(str.replace("candide", "d", "p")) #Using replace method of the string
#object class.

f = "candide".replace #Looks up replace method in the string type module,
#bounding "candide" to the first parameter. Bound fucntion object.
f = str.replace #Has no entered parameters at all. Unbound function object.

#You can create SIMPLE function objects using lambdas, but you need to assign
#them to a name if you want to use them efficiently.
add1 = lambda x, y: x + y
#Creates a function with the parameters x and y, returning the value x + y.
print(add1(1, 2))
#Both print out 3.
def add2(x, y):
    return x + y
print(add2(1, 2))
#However, you could also use lambda functions without binding them to a name.
#To do enter the argument for them, just write down an argument tuple for them.
print((lambda x, y: x + y)(1, 2))
#Lambda functions can be useful for very simple functions with basic evaluation
#or functions that return boolean values.

#Basic Unpacking/Tuple Assignment
x, y = 1, 2 #x = 1, y = 2
[x, y] = [1, 2] #x = 1, y = 2
(x, y) = (1, 2) #x = 1, y = 2
#Unpacking in Python is useful because unlike in other programming languages,
#we wouldn't need to create a temporary third object in order to switch the
#values of two objects.
#Ex:
#temp = x
#x = y
#y = temp (original value of x)
#
#In Python, you could just use normal tuple assignment to do this.
#Ex:
#(x, y) = (y, x)
#OR
#x, y = reverse(x, y)

#Sequence Unpacking
#By default, commas with no parantheses between objects create a tuple.
a, b, c, (d, f) = (1, 2, 3, (4, 5))
#Assigns to the same values. Just has to have a container of sorts inside too.
a, b, c, [d, f] = [1, 2, 3, {4, 5}]
print(a)
print(b)
print(c) #Prints 1, 2, 3, 4, 5.
print(d)
print(f)

#Complicated Unpacking/Parallel Assignments
#Note: Cannot have multiple starred expressions in an unpacking assignment,
#unless in its own container.
a, *b, c = 1, 2, 3, 4 #* variable is for list binding for unpacking.
print(a, b, c) #Binds a to 1st element, binds c to last element,
#and b to the rest, creating a list. Prints 1 [2, 3] 4.
#Does like improper string concatenation with spaces in between.
*a, b, c = 1, 2, 3, 4
print(a, b, c) #Prints [1, 2] 3 4.
a, b, *c = 1, 2, 3, 4
print(a, b, c) #Prints 1 2 [3, 4].
*a, (b, *c), d = 1, 2, (3, 4, 5), 6
print(a, b, c, d) #Prints [1, 2] 3 [4, 5] 6.
#Have to think about whether or not both sides have similar structures.

#The del statement completely removes objects from their namespace as if they
#never existed.
a = 1
del a #Cannot refer to a ever again, unless redefined.

#Iterable objects are containers and strings. Other iterable objects are
#classes and generators. The .sort() method cannot work on immutable objects,
#but sorted() can be used on all of them because sorted() takes all of their
#elements/values/keys and just sorts them into a list.
print(sorted("cab"))
print(sorted(("c", "a", "b"))) #All print ["a", "b", "c"].
print(sorted({"c", "a", "b"}))
print(sorted({"c": 3, "b": 2, "a": 1}))

#A way to create a new list and order the elements in a way that is opposite to
#how we normally sort things is to use the reverse parameter of sorted().
lis = ("c", "b", "d", "a")
print(sorted(lis, reverse = True)) #Prints ["d", "c", "b", "a"]
#The way things are sorted are by ASCII usually. All uppercase letters have
#smaller values than lowercase letters. Uppercase letters go first.
lis = ["a", "A"]
print(sorted(lis)) #Prints ["A", "a"].
#Similar to a dictionary. 1 goes before 5, therefore a string of "15" must come
#before "5", despite numerical order. Strings go by alphabetic order.
lis = ["5", "15"]
print(sorted(lis)) #Prints ["15", "5"].

#Cannot use sorted() on a list with elements of different types. Sorted based
#on the first element of each container. Length does not matter. Still sorts
#things like a dictionary if using strings inside.
lis = [("c", "b"), ("b", "a")]
print(sorted(lis)) #Prints [("b", "a"), ("c", "b")].

#Sorting with Lambda Functions
#Key parameter of sorted() function gives priority sorting to whichever index
#number indicated. By default, key uses x[0].
votes = [('Charlie', 20), ('Able', 10), ('Baker', 20), ('Dog', 15)]
for c, v in sorted(votes, key=(lambda x: x[1]), reverse=True):
    print('Candidate', c, 'received', v, 'votes')
#Uses a list that is sorted by numerical order based on the 1st index of each
#tuple inside of the votes list. Uses 0th index if the same object.
#Ordered from greatest to least integer, from z to a: Charlie, Baker, Dog, Able.

#You can use the sep and end parameters of the print function to set the ending
#of printed things and separate them by the indicated string.
#Note: sep parameter is an empty string by default.
print(1, 2, 3, sep="-", end="!\n") #Prints 1-2-3!

#Basic Conditional Expression
x = 1
y = 0
num = (x if x == 1 else y) #num is x if x is 1, else num is y.
print(num) #Prints 1 in this case.

#Conditional Expression with print()
x = 1 #Requires 2 different objects for if and else. PARANTHESES REQUIRED.
print(x, ("is even." if x % 2 == 0 else "is odd.")) #Prints "1 is odd".
print(str(x) + (" is even." if x % 2 == 0 else " is odd.")) #Concatenation.
#Formatting requires specific places where a word can be different each time.
print(f"{x} is {'even' if x % 2 == 0 else 'odd.'}")

#The list() function can only be used on iterable objects. Does not include any
#amount of integers.
'''print(list(1, 2))''' #Would cause an error.
print(list((1, 2))) #Would convert this tuple to a list.
print(list("12")) #Prints ["1", "2"].

#Open file objects are iterable. Each line of a file is like an element.
'''contents = list(open("test.txt"))''' #Would create a list of each line of
#text inside of the file, each ending in "\n".

#You can iterate a dictionary in 3 ways: by key, value, or item (2-tuple).
dicti = dict(a=1, b=2, c=3) #Variables become strings binded to the values.
print(dicti.keys()) #Prints list of the keys.
print(dicti.values()) #Prints list of the values.
print(dicti.items()) #Prints list of 2-tuples containing keys and their values.
dict1 = dict([['a', 1], ['b', 2], ['c', 3]])
dict1 = dict([('a', 1), ('b', 2), ('c', 3)])
print(dict1) #You can place a structure like dict.items() into dict().

#There is a difference between copying down the elements inside of a list and
#completing using the elements inside of a list if they're mutable.
a = [1, 2]
b = 3
x = [a, b]
y = x.copy()
a.remove(1)
print(x) #Both print [[2], 3] because both use the mutable list a.
print(y) #Better way to do this is to copy the list a and use the copy instead.

#We could use deepcopy from the copy module in order to avoid mutability too.
#Hashable = Immutable = Non-Unique ID
#Unhashable = Mutable = Unique ID
#Note: Immutable objects can still have mutable elements.
from copy import deepcopy
a = [1, 2]
b = 3
x = [a, b]
y = deepcopy(x)
a.remove(1)
print(x)
print(y) #Prints [[1, 2], 3] instead of [[2], 3].

#Frozensets are sets that cannot be modified whatsoever, so immutable sets.
fset = frozenset({1, 2, 3})
'''fset.add(4)''' #This would cause an error.
print(fset) #Prints frozenset({1, 2, 3}).

#List/Tuple/Set/Dictionary Comprehensions (More for Simple Structures)
#i squared becomes a part of list x if the number in the range 1-10 is even.
x = [i**2 for i in range(1, 11) if i % 2 == 0]
print(x) #Prints [4, 16, 36, 64, 100].
x = tuple(i**2 for i in range(1, 11) if i % 2 == 0)
print(x) #Prints tuple version. No tuple keyword creates a generator object.
x = {i**2 for i in range(1, 11) if i % 2 == 0}
print(x) #Prints set version.
x = {i: len(i) for i in ["one", "two", "three"]} #Dictionaries are more tricky.
print(x) #Prints {"one": 3, "two": 3, "three": 5}.

#Comprehensions are usually not good for when you need to mutate elements a lot
#before adding them to the list.
#Cannot mutate tuples, so you'd have to use tuple concatenation. Tuples have no
#mutator methods like .append() or .add().
x = (1, 2)
x = x + (3, )
print(x) #Prints (1, 2, 3).

#Normal for loops deal with global variables, including the ones they use to
#loop with.
#REMEMBER: FOR LOOPS DEAL WITH GLOBAL VARIABLES.
x = "ABC"
for x in range(1, 5):
    pass #Prints 4 because x was last equal
print(x) #to 4 due to the for looping.

#List Comprehensions do not deal with global variables. They're like functions.
#In this case, x in the list comprehension y is like a local variable of y.
#REMEMBER: DO NOT USE LIST COMPREHENSION FOR THINGS YOU WANT TO MUTATE INSIDE.
x = "ABC"
y = [x for x in range(1, 5)]
print(x)

#You can use nested list/container comprehensions.
#For every word in the list, for every letter in the word that is not a vowel,
#add that letter to the set x.
x = {c for word in ['i', 'love', 'new', 'york'] for c in word if c not in 'aeiou'}
print(x) #Prints {'y', 'r', 'w', 'v', 'l', 'k', 'n'}.

#Generator objects are containers that can only be iterated over once.
#Create them by creating a tuple comprehension without the tuple keyword.
x = (i for i in range(1, 4)) #Generator object.
print(x) #Prints location of generator object of (1, 2, 3).
for i in x:
    print(i) #Prints 1, 2, 3.
for i in x:
    print(i) #Prints nothing. Can only be iterated over once.
print(x) #Generator still exists.
'''print(x[0])''' #Generator is not a tuple and is not subscriptable ever.

#A generator object can be converted into another iterable object as well.
#However, once the generator object has been iterated over, its elements become
#exhauted, making the generator an empty object. Converting it to a tuple would
#just make it an empty tuple.
x = (i for i in range(1, 4))
for i in x:
    print(i)
x = tuple(x)
print(x) #Prints an empty tuple.
x = (i for i in range(1, 4))
x = tuple(x)
print(x) #Prints (1, 2, 3).

#Tuple comprehensions are different from generator objects can be iterated over
#more than once.
x = tuple(i for i in range(1, 4)) #Special way of making tuple comprehensions.
print(x) #Prints (1, 2, 3).
for i in x:
    print(i) #Tuple comprehension is able to be
for i in x:  #iterated over more than once.
    print(i)

#any function helps determine if anything in the list is True or 1.
#all function helps determine if all elements in the list are True or 1.
#If it is 0, False, or None, it is considered False.
print(any([0, 0])) #Prints False.
print(any([1, 0])) #Prints True.
print(any([1, 1])) #Prints True.
print(all([0, 0])) #Prints False.
print(all([1, 0])) #Prints False.
print(all([1, 1])) #Prints True.

#Zip objects are a type of generator object that can be iterated over once.
#zip() interleaves the iterable objects in its parameters and places them inside
#tuples inside of the zip generator object.
#Note: If the iterable objects are of different lengths, then they will do what
#they can. If one is a length of 2, then there will only be 2 tuples instead.
z = zip("abc", (1, 2, 3), [4, 5, 6])
'''z = list(z)'''
'''print(z)''' #Prints [('a', 1, 4), ('b', 2, 5), ('c', 3, 6)].
for tup in z:  #Zip objects are generators because they can only be
    print(tup) #iterated over once.

#zip() is useful for when we want to iterate over multiple objects in a for
#loop by unpacking them.
z = zip("abc", (1, 2, 3), [4, 5, 6])
for (o1, o2, o3) in z: #Can manage each object inside of each tuple this way.
    tup = (o1, o2, o3) #Looping again with z would not work.
    print(tup)

#enumerate() is like zip() but it creates a tuples that contain the index values
#and actual values of each element inside. They're generators.
#Second parameter of enumerate is what number the first index should be.
#By default, uses 0 for the 0th index.
#REMEMBER: enumerate() and zip() take iterable objects and interleave certain
#values.
e = enumerate(["a", "b", "c"], 1) #Starts at 1 for index 0 (index, value).
print(list(e)) #Prints [(1, 'a'), (2, 'b'), (3, 'c')].
for e1, e2 in e:
    print("Element", e1, "=", e2)
#In short: Pseudo-tuple comprehensions create pure generator objects, while
#zip() and enumerate() create generator objects of their own.

#*args and **kwargs usually don't use * variable outside of the parameters.
#Arguments for **kwargs must be treated like a variable.
def funky(x, *args, **kwargs):
    print(x, args, kwargs) #Prints e1 ('e2', 'e3') {'e4': 1, 'e5': 2}.
funky("e1", "e2", "e3", e4=1, e5=2)

#Sequence types are lists(m) and tuples(i). Set types are sets(m) and
#frozensets(i). Mapping types are dict and defaultdict (both m).
#dicti.get() method used to get the value of the key in the first argument.
#Else, return the default value in the second argument.
#dicti.setdefault() does the same, but sets the default permanently.
dicti = dict(a=1, b=2, c=3)
print(dicti.get("d", "Lol")) #Prints "Lol".
print(dicti.get("d")) #Prints None.
print(dicti.setdefault("d", "Lol")) #Prints "Lol".
print(dicti.get("d")) #Prints "Lol".

#Usually use defaultdict for creating a dictionary that counts how many of the
#same keys are used inside of a sequence type. "Frequency" dictionaries.
from collections import defaultdict
letters = ['a', 'x', 'b', 'x', 'f', 'a', 'x']
freq_dict = defaultdict(int) #All values will be integers, being 0.
for c in letters:
    freq_dict[c] += 1 #Increases from 0 to beyond.
print(freq_dict)

#Since sets and dictionaries are out of order, we could always sort them by
#using the sorted() function in order to convert them into sorted lists.
dicti = dict(b=2, a=1, c=3)
for key, value in dicti.items(): #Uses a list.
    print(key, "=", value)
for key, value in sorted(dicti.items()): #Uses a sorted list. Sorts by key.
    print(key, "=", value)

#The only way to create an empty set is using set(). Using {} would create an
#empty dictionary instead.
sets = set()
print(type(sets)) #Prints type set.
dicti = {}
print(type(dicti)) #Prints type dict.
#A tuple with only value must be written with a hanging comma. Tuples can never
#appear with no comma, unless it is an empty tuple. Cannot use tuple() on a
#single integer, since that would be tring to convert a non-iterable object
#(integer) to a tuple.
tup = (1,)
print(tup) #Prints (1,).

#defaultdict is basically a dictionary that provides keys with default
#parameters when they are first referenced without assigning the key to a value.
#The argument of a defaultdict must be an object type. If it is int, it will
#default to 0. If it is a container, then it will default to an empty container
#(like a set).
dicti = defaultdict(str)
dicti["key"]
print(dicti) #Value of key is an empty string.
dicti = defaultdict(int)
dicti["key"]
print(dicti) #Value of key is 0.
dicti = defaultdict(dict)
dicti["key"]
print(dicti) #Value of key is an empty dictionary.
dicti = defaultdict(set)
dicti["key"]
print(dicti) #Value of key is an empty set.

#If you want to make things easy and simply want to print or refer to whatever
#is inside of the quotation marks of a string, just create a raw string.
print(r"\n") #Prints "\n" instead of a newline.

#__init__ used to construct class objects.
#__dict__ refers to a dictionary of all the attributes of an object.
#You can create static variables in classes (can be mutable).
class identity:
    count = 0 #Static variable.
    def __init__(self):
        self.name = "Eric"
        self.color = "red"
        self.count += 1
obj = identity()
#Prints "Eric likes the color red"
print(obj.name, "likes the color", obj.color)
print(obj.__dict__) #Prints {'name': 'Eric', 'color': 'red'}
print(obj.count) #Prints 1. Can be used to track amount of identity objects.

#Functions AND classes AND methods AND namedtuples can contain attributes.
def function():
    function.name = "Eric"
function() #Function needs to be run first to establish attributes.
print(function.name) #Prints "Eric".

#__len__() refers to the length of an iterable object. Parameter needed.
#Basic definition of len() function.
'''
def len(x):
    return x.__len__()
'''
print("Hello world!".__len__()) #Prints 12.
print(["Hello", "world!"].__len__()) #Prints 2.
'''
print(1.__len__())
print(int.__len__(1))
''' #These would cause errors because int objects are not iterable, therefore
#no __len__() method exists for them.

#__bool__ is a method that Python uses to evaluate or determine whether
#something is True or False. This is used to explain things like how the any()
#and all() functions work. None, False, 0, and empty iterables objects are
#determined to be False, while most of everything else is True. Typically uses
#any() and all() to determine __bool__.
print(any([None, False, 0, "", 1==2])) #Prints False.
print(bool(None)) #bool() function uses __bool__ method. Prints False.

#"and" requires both to be True, while "or" requires either to be True.
#Includes use of "not", "in", "not in", and relational operators.
#Note: You can use short-circuiting. If one part is already False with AND,
#then it is False. If one part is already True with OR, then it is True.
print(True and False) #Prints False.
print(True or False) #Prints True.

#The same concept can be applied to string values and their __bool__ methods.
x = "first" or "second" #If both True, always returns first value.
y = "" or "second" #Returns "second".
z = None or "third" #Returns "third."
print(x)
print(y)
print(z)

#__str__() used to convert objects into type string.
#__repr__() is the same, but it adds quotes around string arguments.
#type(obj).__len__(obj) is similar to type(obj).__str__(obj).
x = 1 #Type int.
print(x.__str__() + "1") #Same as each other.
print(str(x) + "1") #Both print "11".
print(str([1, 2, 3])) #Prints [1, 2, 3].
print(eval("1 + 1")) #eval() function used to convert strings into expressions.
print(eval("'abc'")) #This prints string abc and that prints integer 2.
print(repr("abc")) #repr() is like str(). For type strings, it surrounds the
#string with quotes. Doesn't do so with any other types.
print("abc".__repr__()) #Prints 'abc' (length=5), not abc (length=3).
#Example definition of str() function definition.
'''
def str(x):
    answer = x.__str__()
    if type(answer) is not str:
        raise TypeError('__str__ returned non-string (type '+type_as_str(answer)+'))
    return answer
'''

#Other conversion type methods are:
x = 1.25
print(x.__int__()) #Only works for numeric types (no strings). Prints 1.
x = 1
print(x.__float__()) #Only works for numeric types (no strings). Prints 1.0.
#Not sure how to use these.
#Some types have these methods, some don't. Like our custom classes.
'''
x.__complex__()
x.__oct__()
x.__hex__()
x.__trunc__()
'''

#Relational operator methods exist.
x = 1
print(x.__eq__(1)) #Prints True because that's what 1 == 1 evaluates to.
'''
x.__lt__(y) = x less than y
x.__gt__(y) = x greater than y
x.__le__(y) = x less than or equal to y
x.__ge__(y) = x greater than or equal to y
x.__eq__(y) = x equal to y
x.__ne__(y) = x not equal to y
'''

#For our custom classes, we need to define our own methods, like __str__() and
#raise exceptions if they don't work out.
class C:
    def __str__(self):
        return "str"
x = C()
print(x.__str__()) #Prints str.

#There are arithmetic methods.
x = 1.2
print(x.__ceil__()) #Rounds up. Prints 2.
print(x.__floor__()) #Rounds down. Prints 1.
x = -1.2
print(x.__abs__()) #Absolute value. Prints 1.2.
print(x.__neg__()) #Multiplies by -1. Prints 1.2
print(x.__pos__()) #Multiplies by 1. Prints -1.2

#For binary arithmetic operators, like + or -, we can define them for our
#custom classes. Becareful when trying to deal with other object types.
#Must always create a reverse version of it as well if you are dealing with
#other object types. (1 + C) AND (C + 1) must both work.
'''
left.__add__(right) = left + right
right.__radd__(left) = right + left

1+C
1.__add__(C)
type(1).__add__(1, C)
int.__add__(1, C)

C+1
C.__radd__(1)
type(C).__radd__(C, 1)
Class.__radd__(C, 1)

Others:
x.__sub__(y)
x.__mul__(y)
x.__truediv__(y)
'''

#Incrementing arithmentic operators also exist. Doesn't need reversed versions.
'''
left.__iadd__(right)
left.__isub__(right)
. . .
'''

#__setattr__() method best used as the last method in a class. Determines rules
#of how to assign attributes to the class.
#This is the default form of the __setattr__ method. Takes the assigned name and
#value of the object, then makes it an entry of __dict__, the dictionary of all
#attributes of an object.
'''
def __setattr__(self, name, value):
    self.__dict__[name] = value
'''
#You can also make it so that no attributes for the class are allowed at all.
'''
def __setattr__(self, name, value):
    pass
'''

#Dunder methods can return the "NotImplemented" keyword if you want Python to
#improvise in something like a __add__ method if you can't usually add a certain
#object type to your custom class object.
NotImplemented

#A for loop is structured similarly to this. Uses iter() and next() functions.
#Also uses try-excepts, StopIteration exceptions, breaks, and while loops.
_hidden = iter(range(10))
try:
    while True:
        i = next(_hidden) #Will always start at first value first.
        print(i) #Keeps printing until 9.
except StopIteration: #After next() can use no more values.
    print('executing else')
finally:
    print('executing finally')
    del _hidden #iter() version of object is exhausted, so it can be deleted.

#In order to iterate over an object, you must first use the iter() function on
#the iterable object. Next, you can call the next() function on it. Each time
#you refer to the next(iter(x)) object, you will move to the next object inside
#of the iterable object.
i = iter(range(0, 10))
print(next(i)) #Prints 0.
print(next(i)) #Prints 1.

#You can create objects like the range object with the start, stop, and step
#parameters in their __init__ methods.
'''
def  __init__(self,start=0,stop,step=1):
    . . .
'''

#The __iter__ method determines and returns the object that you are currently at
#in the iterable object.
#The __next__ method continues to iterate to the next value in the object until
#there are no values left, making it raise a StopIteration exception.
def Psuedo__iter__(self):
    self.n = self.start #n is the current value.
    return self

def Pseudo__next__(self):
    if self.step > 0 and self.n >= self.stop or\
        self.step < 0 and self.n <= self.stop: #"\" used to continue statement.
        raise StopIteration
    answer = self.n
    self.n += self.step #Changes to next value for next iteration.
    return answer #Returns value it just was.

#Use iter() to start iterating with an object.
#REMEMBER: Key aspect of generators is that they have exhaustive values.
x = [1, 2, 3]
iter_x = iter(x) #Returns a generator object (does not mutate x).
print(next(iter_x)) #Goes to the next (first) object in the list and returns it.
print(next(iter_x)) #Goes to the next object in the list and returns it.
#The next() function allowed us access to 1 and 2.
print(next(iter_x)) #Prints 3.
print(list(iter_x)) #All values in iter_x have been exhausted; it's empty now.
print(x) #Immutable, did not affect x. Prints [1, 2, 3].
#NOTE: If x was a generator object, then it would've been mutated.

#Generator objects are special because they do not store values, they create
#them on the spot, those values being exhausted after being directly generated.
#Due to this, they are the closest things we can get to making containers that
#can hold an infinite amount of elements.
lis = [1, 2, 3]
generator = (num for num in lis)
print(list(generator)) #Prints [1, 2, 3].
for num in generator:
    print(num) #Referencing each num exhausts the num.
print(list(generator)) #Prints [] because all values were exhausted.

#Infinite generators can be created by using the yield statement in a function
#that uses an infinite while loop. The yield statement remembers where the
#function was stopped and goes back to that spot after returning a value.
def even():
    num = 1
    while True:
        if num % 2 == 0:
            yield num #Temporarily goes to return value just to come back.
        num += 1 #Checks for every number from 1-infinity.
even_num = even()
print(even_num) #Prints <generator object even at 0x0000024C475E0D60>.

#Printing the pure list version of infinite generators WILL crash the program,
#so it needs to be limited in a way.
count = 0
iter_even = iter(even_num)
while count != 10: #Allows for 10 even numbers to show.
    print(next(iter_even), end=" ") #Prints "2 4 6 8 10 12 14 16 18 20 ".
    count += 1
print("")

#Here is an example of a class made for iterating. Must have an iterable
#argument to start with and an __iter__ method. __iter__ method will have its
#own __iter__ method that returns itself and has a __next__ method that does
#the work.
class preversed:
    def __init__(self, iterable):
        self._iterable = iterable
    
    def __iter__(self):
        class preversed_iter:
            def __init__(self, iterable):
                self._iterable = iterable
                self._next = 1
            
            def __next__(self):
                x = len(self._iterable) + 1 #Makes sure iterable object does
                if self._next == x: #not go over the iteration limit.
                    raise StopIteration
                answer = self._iterable[-self._next] #Outputs last index value.
                self._next +=1 #Goes over every single value in iterable.
                return answer
            
            def __iter__(self):
                return self
            
        return preversed_iter(self._iterable)

print(list(preversed([1, 2, 3]))) #Prints [3, 2, 1].

#eval() function returns whatever the result of the expression inside is.
print(eval("1+1")) #Returns 2, which is printed.

#exec() function executes whatever code. It's like programming the programming
#of code. Useful if you plan on creating things like entirely new custom classes
#during running of the program.
string_code = "class iterate:\n    def __init__(self, inte):\n        self.inte = inte\n    def increase(self):\n        self.inte += 1\n        return self.inte"
print(string_code) #Creates a new class.
#string_code visualized.
'''
class iterate:
    def __init__(self, inte):
        self.inte = inte
    def increase(self):
        self.inte += 1
        return self.inte
'''
exec(string_code) #Executes code found in string.
num = iterate(1) #Value representing object is 1.
print(num.increase()) #Prints 2, since 1 + 1 = 2.

#Week 0: Reading files, .strip(), and .split().
'''
with open("RE Basics.txt") as f: #with statement used to open and close files.
    f = list(f) #Don't need .readlines().
    f = "".join(f) #Don't need .read either().
    f = f.rstrip() #Used to remove blank space or special escape characters
    f = f.lstrip() #to the left, right, or both sides of a string.
    f = f.strip()
    print(f) #Prints giant string like w/ .read().
    f = f.split("\n") #Converts strings to lists split at every "\n".
    print("")
'''

#Python's re module helps with dealing with regular expressions.
import re
#The match and search function check to see if a certain regular expression is
#seen in within a string. If found, a match object will be returned. If not,
#None will be returned. Match only checks from the beginning of the string,
#while search checks from all places of the string.
x = re.match("[a-z]+", "123abc")
print(x != None) #Prints False.
x = re.search("[a-z]+", "123abc")
print(x != None) #Prints True. Found near end of string.

#The re.sub() function is used to replace certain patterns with something else
#found in strings. Last parameter used to limit amount of times to replace.
x = re.sub("[a-z]+", "123", "123abc", 1)
print(x) #Prints 123123.

#The re.split() function is used to split the string into a list wherever they
#find the stated pattern in the first argument.
x = re.split("[a-z]+", "123abc123")
print(x)

#Creating decorators is basically an easier way to redefine an existing function
#as a a new function after making it into the argument of another function that
#returns a function.
def func1(func):
    def func2():
        print("Starting...")
        func()
        print("Ending...")
    return func2

def func3():
    print("Hello world!")

x = func1(func3) #Simply refers to a function object that was returned by func1.
x() #Prints everything.

#An easier way to do this would be to give the argument function decorator
#status and directly call it. This is just a shorthand way to do it.
#NOTE: func2 NEEDS to have the same parameters as func3.
def func1(func):
    def func2():
        print("Starting...")
        func()
        print("Ending...")
    return func2

@func1
def func3():
    print("Hello world!")

func3() #Prints everything, "func3" being the actual returned function object.

#If you have parameters for func3, just make things easier by giving func2 the
#parameters and func the arguments *args and **kwargs.
def func1(func):
    def func2(*args, **kwargs):
        print("Starting...")
        func(*args, **kwargs)
        print("Ending...")
    return func2

@func1 #Specifies what function this is a decorator of.
def func3(string):
    print(string)

func3("Hello world!") #Prints everything.

#You can also use decorators on methods and functions/methods that return stuff.
def func1(func):
    def func2(*args, **kwargs):
        print("Starting...")
        print(func(*args, **kwargs)) #Prints the 3.
        print("Ending...")
    return func2

@func1 #Specifies what function this is a decorator of.
def func3(x=0, y=0):
    return x + y

func3(1, 2) #Prints starting, 3, and ending.

#When you want to sort a map of words and frequencies by descending order of
#the frequencies and want the secondary sorting to be by increasing order of
#the words, you can use this kind of lambda for the key.
def printFrequencies(MapOfFrequencies):
    MapOfFrequencies = sorted(MapOfFrequencies.items(), key = lambda x: (-x[1], x[0]))
    for key, value in MapOfFrequencies:
        print(key, end = ""), print(" = ", end = ""), print(value)
