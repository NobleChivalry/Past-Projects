#ifndef ARRAY_H
#define ARRAY_H

#include<iomanip>
using namespace std;
#include<string>

template<typename T>
class Array {
	int len;
	T* buf;

public:
	Array(int new_len)
		: len(new_len), buf(new T[len])
	{
		fill(T());
	}

	int length() {
		return len;
	}

	T& operator [](int index) {
		if (index < 0 || index >= len) {
			throw ("Exception operator[](" + to_string(index) + ") Out Of Range");
		}
		return buf[index];
	}

	const T& operator [](int index) const {
		if (index < 0 || index >= len) {
			throw ("Exception operator[](" + to_string(index) + ") Out Of Range");
		}
		return buf[index];
	}

	//you must define correct copy constructor to pass
	Array(const Array& a) {
		len = a.len;
		T* temp = new T[len];
		for (int i = 0; i <= len - 1; i++) {
			temp[i] = a.buf[i];
		}
		buf = temp;
		temp = nullptr;
	}

	//leave this deleted so it's not used accidentally
	Array& operator =(Array& a) = delete;

	void fill(T val) {
		for (int i = 0; i < len; ++i) {
			buf[i] = val;
		}
	}

	void print(ostream& out) const {
		for (int i = 0; i < len; ++i)
			//set the field width to 8 spaces
			out << setw(8)
			//set decimal precision to 2 digits for real numbers
			<< setprecision(2)
			//used fixed point, not floating point for real numbers
			<< fixed
			//right justify the number within the field width
			<< right
			//print the value at buf[i]
			<< buf[i];
	}

	friend ostream& operator <<(ostream& out, const Array& a) {
		a.print(out);
		return out;
	}

	friend ostream& operator <<(ostream& out, const Array* a) {
		a->print(out);
		return out;
	}

	~Array() {
		delete[] buf;
	}

	/*
	must overload operator << for Array pointer to pass
	ostream& operator <<(ostream& out, ???);
	*/
};

#endif