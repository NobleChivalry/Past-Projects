#ifndef MATRIX_H
#define MATRIX_H

using namespace std;
#include "Array.h"

template <typename T>
class Matrix {
	int rows, cols;
	Array<Array<T>*> matrix;

	//this will change to Array<Array<int>*> matrix;
	//then finally will be Array<Array<T>*> matrix;

public:
	Matrix(int new_rows, int new_cols)
		: rows(new_rows), cols(new_cols), matrix(Array<Array<T>*>(new_rows))
	{
		for (int i = 0; i <= new_rows - 1; i++) {
			matrix[i] = new Array<T>(new_cols);
		}
		fill(T());
	}

	//you must define correct copy constructor to pass
	Matrix(const Matrix& a)
		: rows(a.rows), cols(a.cols), matrix(Array<Array<T>*>(a.rows))
	{
		for (int i = 0; i <= rows - 1; i++) {
			matrix[i] = new Array<T>(cols);
		}

		for (int i = 0; i < rows; ++i) {
			for (int j = 0; j < cols; ++j) {
				Array<T>* temp1 = matrix[i];
				Array<T>* temp2 = a.matrix[i];
				(*temp1)[j] = (*temp2)[j];
			}
		}
	}

	//leave this deleted so it's not used accidentally
	Matrix& operator =(Matrix& a) = delete;

	int num_rows() {
		return rows;
	}

	int num_cols() {
		return cols;
	}

	void fill(T val) { //deleted the dummy statement
		for (int i = 0; i < rows; ++i) {
			matrix[i]->fill(val);
		}
	}

	Array<T>& operator [](int row) {
		if (row < 0 || row >= rows) {
			throw ("Exception operator[](" + to_string(row) + ") Out Of Range");
		}
		return *(matrix[row]);
	}

	void print(ostream& out) { //deleted the dummy statement
		for (int i = 0; i <= rows - 1; i++) {
			out << matrix[i];
			out << endl;
		}
	}

	friend ostream& operator <<(ostream& out, Matrix& m) { //deleted the dummy statement
		m.print(out);
		return out;
	}

	friend ostream& operator <<(ostream& out, Matrix* m) {
		m->print(out);
		return out;
	}

	~Matrix() {
		for (int i = 0; i <= rows - 1; i++) {
			delete matrix[i];
		}
	}
};

#endif