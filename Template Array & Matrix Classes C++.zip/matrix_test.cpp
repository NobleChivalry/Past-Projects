#include <iostream>
using namespace std;

#include "Matrix.h"

template<typename FN>
void fill_with_fn(Array<int>& a, FN fn) {
	for (int i = 0; i < a.length(); ++i)
		a[i] = fn(i);
}

template<typename FN>
void fill_with_fn(Array<double>& a, FN fn) {
	for (int i = 0; i < a.length(); ++i)
		a[i] = fn(i + 1);
}

template<typename FN>
void fill_with_fn(Array<char>& a, FN fn) {
	for (int i = 0; i < a.length(); ++i)
		a[i] = fn('A' - 1 + i);
}

template<typename FN>
void fill_with_fn(Matrix<int>& m, FN fn) {
	for (int i = 0; i < m.num_rows(); ++i) {
		for (int j = 0; j < m.num_cols(); ++j) {
			m[i][j] = fn(i, j);
		}
	}
}

template<typename FN>
void fill_with_fn(Matrix<double>& m, FN fn) {
	for (int i = 0; i < m.num_rows(); ++i) {
		for (int j = 0; j < m.num_cols(); ++j) {
			m[i][j] = fn(i, j);
		}
	}
}

template<typename FN>
void fill_with_fn(Matrix<char>& m, FN fn) {
	for (int i = 0; i < m.num_rows(); ++i) {
		for (int j = 0; j < m.num_cols(); ++j) {
			m[j][i] = fn('A' - 1 + i);
		}
	}
}

void test_int_array() {
	Array<int> a{ 10 };
	auto fn = [](int i) {return i + 1; };
	a.fill(int());
	cout << a << endl;
	fill_with_fn(a, fn);
	cout << a << endl;
	cout << endl;

	Array<int> b = Array<int>{ a };
	cout << b << endl;
	cout << endl;

	a[0] = 0;
	cout << a << endl;
	cout << b << endl;
	cout << endl;

	Array<int>* c = &b;
	cout << c << endl;
	cout << endl;

	b[0] = 0;
	cout << b << endl;
	cout << c << endl;
	cout << endl;
}

void test_int_matrix() {
	Matrix<int> a(3, 3);
	auto fn = [](int i, int j) {return (i + 1) * (j + 1); };
	a.fill(int());
	cout << a << endl;
	fill_with_fn(a, fn);
	cout << a << endl;
	cout << endl;

	Matrix<int> b = Matrix<int>(a);
	cout << b << endl;
	cout << endl;

	a[0][0] = 0;
	cout << a << endl;
	cout << b << endl;
	cout << endl;

	Matrix<int>* c = &b;
	cout << c << endl;
	cout << endl;

	b[0][0] = 0;
	cout << b << endl;
	cout << c << endl;
	cout << endl;

	//define and use fill_with_fn(Matrix& m, auto fn)
}

void test_double_array() {
	Array<double> a = Array<double>{ 9 };
	auto fn = [](double i) {return i * 1.1; };
	a.fill(double());
	cout << a << endl;
	fill_with_fn(a, fn);
	cout << a << endl;
	cout << endl;

	Array<double> b = Array<double>{ a };
	cout << b << endl;
	cout << endl;

	a[0] = 0;
	cout << a << endl;
	cout << b << endl;
	cout << endl;

	Array<double>* c = &b;
	cout << c << endl;
	cout << endl;

	b[0] = 0;
	cout << b << endl;
	cout << c << endl;
	cout << endl;

	//fill with numbers 1.1 to 9.9 step 1.1
}

void test_double_matrix() {
	Matrix<double> a(10, 10);
	auto fn = [](double i, double j) {return (i + 1) + (j + 1) / 100;};
	a.fill(double());
	cout << a << endl;
	fill_with_fn(a, fn);
	cout << a << endl;
	cout << endl;

	Matrix<double> b = Matrix<double>(a);
	cout << b << endl;
	cout << endl;

	a[0][0] = 0;
	cout << a << endl;
	cout << b << endl;
	cout << endl;

	Matrix<double>* c = &b;
	cout << c << endl;
	cout << endl;

	b[0][0] = 0;
	cout << b << endl;
	cout << c << endl;
	cout << endl;

	//fill each cell with (row + 1) + (col + 1) / 100
	//e.g., matrix[0][0] = 1.01 / matrix[9][9] = 10.10
}

void test_char_array() {
	Array<char> a{26};
	auto fn = [](char i) {return i + 1;};
	a.fill(char());
	cout << a << endl;
	fill_with_fn(a, fn);
	cout << a << endl;
	cout << endl;

	//fill with letters A through Z
}

void test_char_matrix() {
	Matrix<char> a(26, 26);
	auto fn = [](char i) {return i + 1;};
	a.fill(char());
	cout << a << endl;
	fill_with_fn(a, fn);
	cout << a << endl;
	cout << endl;

	//fill each row with letters A through Z
	//repeat for each row
}

void test_exceptions() {
	try {
		Array<int> a(10);
		a[10];
	}
	catch(std::string& e) {
		cout << e << endl;
	}

	try {
		Matrix<int> m1(10, 10);
		m1[10];
	}
	catch(std::string& e) {
		cout << e << endl;
	}

	try {
		Matrix<int> m2(10, 10);
		Array<int> temp = m2[9];
		temp[10];
	}
	catch(std::string& e) {
		cout << e << endl;
	}
}

void test_extras() {
	Matrix<int> m{10, 10};
	Matrix<int> n{m}; //copy constructor
	Array<int> a{10};
	cout << &a << endl; //operator <<() for pointer to Array
}

#define N 1

int main() {
	for (int i = 1; i <= N; ++i) {
		test_int_array();
		test_int_matrix();
		test_double_array();
		test_double_matrix();
		test_char_array();
		test_char_matrix();
		test_exceptions();
		test_extras();
	}
}