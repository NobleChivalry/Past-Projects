import React from "react"

function FavoriteCar() {
    // State of "car" is simply its attributes as an object.
    const [car, setCar] = React.useState({  year: 2024,
                                            make: "Ford",
                                            model: "Mustang"});
    
    // Need to create event handler for changing each attribute within car object.
    function handleYearChange(event: React.ChangeEvent<HTMLInputElement>) { // "..." operator refers to the rest of object car's attributes.
        setCar(c => ({...c, year: Number(event.target.value)})); // Wrapped function inside of "()" to fix compiling issue.
    }
    function handleMakeChange(event: React.ChangeEvent<HTMLInputElement>) {
        setCar(c => ({...c, make: event.target.value}));
    }
    function handleModelChange(event: React.ChangeEvent<HTMLInputElement>) {
        setCar(c => ({...c, model: event.target.value}));
    }

    return (
        <div>
            <p>Your favorite car is: {car.year} {car.make} {car.model}</p>

            <input type="number" value={car.year} onChange={handleYearChange}></input>
            <input value={car.make} onChange={handleMakeChange}></input>
            <input value={car.model} onChange={handleModelChange}></input>
        </div>
    );
}

export default FavoriteCar