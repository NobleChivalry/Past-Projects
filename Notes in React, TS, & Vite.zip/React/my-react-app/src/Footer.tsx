function Footer() {
    return (
        <footer>
            {/* "&copy;" creates copyright symbol in HTML. */}
            {/* Can create Date object with JS. */}
            <p>&copy; {new Date().getFullYear()} MyWebsite</p>
        </footer>
    );
}

export default Footer