import React from "react"

function ToDoList() {
    const [tasks, setTasks] = React.useState<string[]>([]);
    const [newTask, setNewTask] = React.useState<string>("");

    function handleInputChange(event: React.ChangeEvent<HTMLInputElement>) {
        setNewTask(event.target.value);
    }

    function addTask() {
        if (newTask.trim() !== "") { // Only adds task if task is not empty or just whitespace.
            setTasks(t => [...t, newTask]);
            setNewTask("");
        }
    }

    function deleteTask(index: number) {
        const updatedTasks = tasks.filter((_, i) => i !== index);
        setTasks(updatedTasks);
    }

    function moveTaskUp(index: number) {
        if (index !== 0) { // Cannot move task up if task is at top.
            const updatedTasks = [...tasks]; // Need new array, avoid updating in-place because of update state issues.
            // updatedTasks[index - 1] is the previous/upper task.
            // Destructuring: Will swap the positions of 2 elements within an array.
            [updatedTasks[index], updatedTasks[index - 1]] = [updatedTasks[index - 1], updatedTasks[index]];
            setTasks(updatedTasks);
        }
    }

    function moveTaskDown(index: number) {
        if (index !== tasks.length - 1) { // Cannot move task down if task is at bottom.
            const updatedTasks = [...tasks]; // updatedTasks[index + 1] is the next/lower task.
            [updatedTasks[index], updatedTasks[index + 1]] = [updatedTasks[index + 1], updatedTasks[index]];
            setTasks(updatedTasks);
        }
    }

    return (
        <div className="to-do-list">
            <h1>To-Do List</h1>

            <div>
                <input type="text" placeholder="Enter a task..." value={newTask} onChange={handleInputChange}/>
                <button className="add-button" onClick={addTask}>
                    Add
                </button>
            </div>

            <ol>
                {tasks.map((task, index) =>
                    <li key={index}>
                        <span className="text">{task}</span>

                        <button className="delete-button" onClick={() => deleteTask(index)}>
                            Delete
                        </button>

                        <button className="move-button" onClick={() => moveTaskUp(index)}>
                            👆
                        </button>

                        <button className="move-button" onClick={() => moveTaskDown(index)}>
                            👇
                        </button>
                    </li>
                )}
            </ol>
        </div>
    );
}

export default ToDoList