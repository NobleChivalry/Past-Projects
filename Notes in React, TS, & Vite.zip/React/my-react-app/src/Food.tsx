function Food() {
    // Example of JS being used outside of return statement.
    const food1 = "Apple";
    const food2 = "Orange";

    return (
        <ul>
            {/* Can use JS functions within "JS fields" we're using. */}
            <li>{food1.toUpperCase()}</li>
            <li>{food2}</li>
            <li>{"Banana".toUpperCase()}</li>
            <li>{"Grape"}</li>
            <li>Grapefruit</li>
        </ul>
    );
}

export default Food