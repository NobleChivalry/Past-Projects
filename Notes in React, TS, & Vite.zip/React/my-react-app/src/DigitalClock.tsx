import React from "react"

function DigitalClock() {
    const [time, setTime] = React.useState<Date>(new Date()); // Time from Date object used.

    React.useEffect(() => { // Runs side code only 1 time.
        const intervalId = setInterval(() => { // Interval object created.
            setTime(new Date()); // Resets clock for every interval passed.
        }, 1000); // Function is run after every 1000 ms (1 second) interval.

        return () => { // Cleanup function deletes interval object.
            clearInterval(intervalId);
        };
    }, []);

    function formatTime() {
        let hours = time.getHours();
        const minutes = time.getMinutes();
        const seconds = time.getSeconds();
        const meridiem = hours >= 12 ? "PM" : "AM";
        
        // Converts from (not to) military time.
        hours = hours % 12 || 12; // Displays 12:00 instead of 0:00 with OR (||) operator.

        return `${padZero(hours)}:${padZero(minutes)}:${padZero(seconds)} ${meridiem}`;
    }

    // Makes sure to add leading zeros if needed for clock (2 digits max).
    function padZero(number: number) {
        return (number < 10 ? "0" : "") + number;
    }

    return (
        <div className="clock-background">
            <div className="clock-container">
                <div className="clock">
                    <span>{formatTime()}</span>
                </div>
            </div>
        </div>
    );
}

export default DigitalClock