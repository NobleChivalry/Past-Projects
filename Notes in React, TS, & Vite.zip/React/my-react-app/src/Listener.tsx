import React from "react"

function Listener() {
    const [width, setWidth] = React.useState<number>(window.innerWidth);
    const [height, setHeight] = React.useState<number>(window.innerHeight);

    // Event listener calls handleResize() function whenever window is resized (only need 1).
    // This is bad because we create a new event listener whenever the component re-renders (1000+ new event listeners).
    /*
    window.addEventListener("resize", handleResize);
    console.log("EVENT LISTENER ADDED");
    */

    // Issue is solved with this hook because "side code" is called only once (on mount).
    React.useEffect(() => { // 2 event listeners are added because of strict mode.
        window.addEventListener("resize", handleResize);
        console.log("EVENT LISTENER ADDED");

        return () => { // Cleanup function removes 1 event listener that was added (2nd is never unmounted).
            window.removeEventListener("resize", handleResize);
            console.log("EVENT LISTENER REMOVED");
        };
    }, []);

    // Whenever "width" or "height" stateful variables are updated, code runs (title updates).
    React.useEffect(() => {
        document.title = `Size: ${width} x ${height}`;
    }, [width, height]);

    // Whenever we resize the window of our page, the "width" and "height" stateful variables change with it.
    function handleResize() {
        setWidth(window.innerWidth);
        setHeight(window.innerHeight);
    }

    return (
        <>
            <p>Window Width: {width}px</p>
            <p>Window Height: {height}px</p>
        </>
    );
}

export default Listener