import styles from "./Button.module.css"

// Example of using modules for CSS Styling.
function Button() {
    // Modules are nice because they avoid naming conflicts.
    // Downside is that you cannot easily import global styles to here with this kind of set-up.
    return (
        <button className={styles.button}>
            Click Me
        </button>
    );
}

export default Button