import React from "react"

function ColorPicker() {
    const [color, setColor] = React.useState<string>("#FFFFFF");

    function handleColorChange(event: React.ChangeEvent<HTMLInputElement>) {
        setColor(event.target.value);
    }

    return (
        <div className="color-picker-container">
            <h1>Color Picker</h1>
            <div className="color-display" style={{backgroundColor: color}}> {/* Inline CSS Styling */}
                <p>Selected Color: {color}</p>
            </div>
            <label className="color-picker-label">Select a Color:</label>
            <input type="color" value={color} onChange={handleColorChange}></input>
        </div>
    );
}

export default ColorPicker