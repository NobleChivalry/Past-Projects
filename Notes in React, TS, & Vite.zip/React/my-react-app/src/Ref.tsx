import React from "react"

// useRef is like useState but does not trigger re-renders of the component (improved efficiency).
/*
useRef can be useful for:
1. Accessing/Interacting with DOM elements.
2. Handling Focus, Animations, & Transitions.
3. Managing Timers & Intervals.
*/

function Ref() {
    // let [number, setNumber] = React.useState(0); // Example with useState() hook (re-renders whenever state changes on button click).
    const inputRef = React.useRef<HTMLInputElement>(null); // Returns an Object with a single property called "current". Initial state is null.
    const inputRef2 = React.useRef<HTMLInputElement>(null);
    const inputRef3 = React.useRef<HTMLInputElement>(null);

    console.log(inputRef); // Prints "null". Usually, HTML elements print giant Objects.
    console.log(inputRef.current); // Prints "{current: null}".

    // Runs side code for every time the component renders (never re-renders).
    React.useEffect(() => {
        console.log("COMPONENT RENDERED");
    });

    function handleClick() {
        // setNumber(n => n + 1);
        if (inputRef.current !== null && inputRef2.current !== null && inputRef3.current !== null) { // Compiler worries about "null" elements in use.
            inputRef.current.focus(); // Sets the focus to be on the input box ("awaiting input" mode).
            inputRef.current.style.backgroundColor = "yellow"; // Sets CSS style to make the box yellow.

            inputRef2.current.style.backgroundColor = ""; // Makes sure other input boxes are no longer yellow.
            inputRef3.current.style.backgroundColor = "";
        }
    }

    function handleClick2() {
        if (inputRef.current !== null && inputRef2.current !== null && inputRef3.current !== null) {
            inputRef2.current.focus();
            inputRef2.current.style.backgroundColor = "yellow";

            inputRef.current.style.backgroundColor = "";
            inputRef3.current.style.backgroundColor = "";
        }
    }

    function handleClick3() {
        if (inputRef.current !== null && inputRef2.current !== null && inputRef3.current !== null) {
            inputRef3.current.focus();
            inputRef3.current.style.backgroundColor = "yellow";

            inputRef.current.style.backgroundColor = "";
            inputRef2.current.style.backgroundColor = "";
        }
    }

    return (
        <div>
            <button onClick={handleClick}>
                Click Me
            </button>
            <input ref={inputRef}/> {/* This input element can be referenced using the "inputRef" stateful variable/reference. */}

            <button onClick={handleClick2}>
                Click Me 2
            </button>
            <input ref={inputRef2}/>

            <button onClick={handleClick3}>
                Click Me 3
            </button>
            <input ref={inputRef3}/>
        </div>
    );
}

export default Ref