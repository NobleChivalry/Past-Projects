// There can only be 1 parameter, a mapping of key-value pairs, mapping attribute names to attribute arguments.
// Allows for default parameters as well.
function Student({name = "Guest", age = 0, isStudent = false}: propTypes) {
    return (
        <div className="student">
            <p>Name: {name}</p>
            <p>Age: {age}</p>
            <p>Student: {isStudent ? "Yes" : "No"}</p> {/* If true, output "Yes". Else, output "No". */}
        </div>
    );
}

// Example of using TypeScript with JavaScript XML (ensures correct parameter types).
// Can refer to array of strings by using type "string[]".
// Can even do "object" types with their own attribute types (e.g. {name: "Mario", age: 35}).
type propTypes = {
    name: string,
    age: number,
    isStudent: boolean
};

export default Student