import React from "react"

function FormElements() {
    const [name, setName] = React.useState<string>("Guest");
    const [quantity, setQuantity] = React.useState<number>(1);

    const [comment, setComment] = React.useState<string>("");

    const [payment, setPayment] = React.useState<string>("");

    const [shipping, setShipping] = React.useState<string>("Delivery"); // "Delivery" option is selected by default.

    // If handling change events instead of click/mouse events, need to change up way of dealing with TypeScript.
    // Use "function" for event handlers instead of "const".

    // Example of Event Handlers for Input Boxes
    function handleNameChange(event: React.ChangeEvent<HTMLInputElement>) {
        setName(event.target.value);
    }
    function handleQuantityChange(event: React.ChangeEvent<HTMLInputElement>) {
        setQuantity(Number(event.target.value)); // "value" attribute always returns string, need to convert to Number.
    }
    
    // Example of Event Handlers for Text Areas
    function handleCommentChange(event: React.ChangeEvent<HTMLTextAreaElement>) {
        setComment(event.target.value);
    }

    // Example of Event Handlers for Select Elements
    function handlePaymentChange(event: React.ChangeEvent<HTMLSelectElement>) {
        setPayment(event.target.value);
    }

    // Example of Event Handlers for Radio Elements (Radio Elements are a Type of Input Element)
    function handleShippingChange(event: React.ChangeEvent<HTMLInputElement>) {
        setShipping(event.target.value);
    }

    return (
        <div>
            {/* Setting "value" field will set the text inside of the input box. */}
            <input value={name} onChange={handleNameChange}/>
            <p>Name: {name}</p>

            {/* Setting "type" field to be "number" adds increment and decrement buttons to input box. */}
            <input value={quantity} onChange={handleQuantityChange} type="number"/>
            <p>Quantity: {quantity}</p>

            {/* Setting "placeholder" field will add gray text when text area is empty. */}
            <textarea value={comment} onChange={handleCommentChange} placeholder="Enter delivery instructions"/>
            <p>Comment: {comment}</p>

            <select value={payment} onChange={handlePaymentChange}>
                <option value="">Select an option</option> {/* No payment method shown for this option (acts as placeholder). */}
                <option value="Visa">Visa</option>
                <option value="Mastercard">Mastercard</option>
                <option value="Giftcard">Giftcard</option>
            </select>
            <p>Payment: {payment}</p>

            {/* Setting "checked" field to true will mark option as selected and vice versa. */}
            <label> {/* Label elements can be used to add a label to a specific element. */}
                <input type="radio" value="Pick Up" checked={shipping === "Pick Up"} onChange={handleShippingChange}/>
                Pick Up
            </label><br/>
            <label>
                <input type="radio" value="Delivery" checked={shipping === "Delivery"} onChange={handleShippingChange}/>
                Delivery
            </label>
            <p>Shipping: {shipping}</p>
        </div>
    );
}

export default FormElements