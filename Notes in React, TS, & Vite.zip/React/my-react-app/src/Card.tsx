function Card() {
    // Use "div" element for generic containers.
    // Convention: Lowercase className(s).
    return (
        // Can either import picture and use "{}" field OR
        // use online link to picture for "src" field (import optional).
        <div className="card"> {/* className field refers to styling it will use from styling sheet. */}
            {/* "alt" field should contain description of image. Replaces image if image not usable. */}
            <img className="card-image" src="https://dummyimage.com/150x150/000/fff" alt="Profile Picture"></img>
            <h2 className="card-title">Luigi Mario</h2>
            <p className="card-text">Software engineer who likes coding</p>
        </div>
    );
}

export default Card