// Example of Inline CSS Styling.

// Simple, straightforward, and avoids naming conflicts.
// Especially good for isolated components that do not require much complex styling.
// Can hinder readability of components.
function RoundButton() {
    /*
    Must turn "styles" into a variable, use camel case, turn values into strings,
    turn semi-colons into commas, and change "className" to "style".
    */
    const styles = {
        backgroundColor: "hsl(0, 100%, 50%)",
        color: "white",
        maxWidth: "50px",
        maxHeight: "50px",
        padding: "10px 10px",
        borderRadius: "100%", /* Makes element circular. */
        border: "none",
        cursor: "pointer"
    }

    return (
        <button style={styles}>
            Click Me
        </button>
    );
}

export default RoundButton