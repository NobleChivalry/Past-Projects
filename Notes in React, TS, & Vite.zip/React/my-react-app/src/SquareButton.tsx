import React from "react" // Needed for type "MouseEvent".

function SquareButton() {
    // Event handler requires arrow function (" () => ").
    const handleClick = () => console.log("OOF!");

    // Format strings require " ` " quotes and "${}" fields.
    const handleClick2 = (name: string) => console.log(`${name}, stop clicking me.`);

    // Event handlers that require multiple lines must use "{}" to wrap up the lines.
    let count = 0;
    const handleClick3 = (name: string) => {
        if (count < 3) {
            ++count;
            console.log(`${name}, you clicked me ${count} time(s).`);
        }
        else {
            console.log(`${name}, stop clicking me.`);
        }
    };

    // "e" stands for event. Take type "MouseEvent" from React library (used for click events).
    // By default, there is always some invisible MouseEvent argument in event handlers.
    const handleClick4 = (e: React.MouseEvent) => console.log(e);

    const handleClick5 = (e: React.MouseEvent) => {
        const target = e.target as HTMLElement;
        target.textContent = "OOF! 🤕";
    };

    // If button has a parameter, arrow function must be included in the onClick field. Can also use onDoubleClick field instead.
    //
    // <button onClick={handleClick}>Click Me 🙂</button>
    // <button onClick={() => handleClick2("Mario")}>Click Me 🙂</button>
    // <button onClick={() => handleClick3("Mario")}>Click Me 🙂</button>
    // <button onClick={(e) => handleClick4(e)}>Click Me 🙂</button>
    // <button onClick={(e) => handleClick5(e)}>Click Me 🙂</button>
    return (
        <button onDoubleClick={(e) => handleClick5(e)}>Click Me 🙂</button>
    );
}

export default SquareButton