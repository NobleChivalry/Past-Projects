import React from "react"

// useEffect() ~= useSideCode()
/*
1. useEffect(() => {})          // Runs after every re-render (many times) -> benefit is cleanup function.
2. useEffect(() => {}, [])      // Runs only on mount (1 time).
3. useEffect(() => {}, [value]) // Runs on mount + when value(s) change (1+ times).
*/
function Effect() {
    const [count, setCount] = React.useState<number>(0);
    const [color, setColor] = React.useState<string>("green");

    // Only runs "function" when any of the "dependencies" change.
    // useEffect(function, [dependencies])
    React.useEffect(() => {
        document.title = `Count: ${count} ${color}`; // Could keep only this line if it should be ran for every re-rendering.
        return () => {
            // Could include a cleanup function, which frees up resources before the next re-render or before unmounting the component.
            // Example: If we added an event listener when the component mounts,
            // we should remove it before unmounting. If not, there could be unexpected behavior.
        }
    }, [count, color]);

    function addCount() {
        setCount(c => c + 1);
    }

    function subtractCount() {
        setCount(c => c - 1);
    }

    function changeColor() {
        setColor(c => c === "green" ? "red" : "green");
    }

    return (
        <>
            <p style={{color: color}}>Count: {count}</p>
            <button onClick={addCount}>Add</button>
            <button onClick={subtractCount}>Subtract</button>
            <button onClick={changeColor}>Change Color</button>
        </>
    );
}

export default Effect