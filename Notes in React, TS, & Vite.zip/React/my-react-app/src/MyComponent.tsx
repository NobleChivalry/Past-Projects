import React from "react" // Needed for using React hooks.

function MyComponent() {
    // useState() = React hook that allows the creation of a stateful variable AND a setter fuction to update its value in the Virtual DOM.
    // const [state, setState] = ?
    const [name, setName] = React.useState<string>("Guest"); // Initial state is "Guest" (need to specify parameter type for hook).
    const [age, setAge] = React.useState<number>(0); // Need to include type of stateful variable in useState() call to avoid TypeScript issues.
    const [isEmployed, setIsEmployed] = React.useState<boolean>(false);

    // Event handler that utilizes hook's setter function to update stateful variable "name".
    const updateName = () => {
        setName("Mario");
    }
    const incrementAge = () => {
        setAge(age + 1); // Sets "age" to be 1 higher.
    }
    const toggleEmployedStatus = () => {
        setIsEmployed(!isEmployed); // Sets "age" to be 1 higher.
    }

    return (
        <div>
            <p>Name: {name}</p>
            <button onClick={updateName}>Set Name</button>

            <p>Age: {age}</p>
            <button onClick={incrementAge}>Increment Age</button>

            <p>Is Employed: {isEmployed ? "Yes" : "No"}</p>
            <button onClick={toggleEmployedStatus}>Toggle Status</button>
        </div>
    );
}

export default MyComponent