import React from "react"

function UpdaterFunctions() {
    const [count, setCount] = React.useState<number>(0);

    /*
    function increment() {
        setCount(count + 1); // Other setCount(s) fail because React batches state updates together for performance reasons.
        setCount(count + 1); // Ends up using the same value of "count" in next setCount calls.
        setCount(count + 1);
    }
    */

    // If you want to solve this issue and include multiple state updates within an event handler, you need an updater function.
    // Updater Function: Arrow function passed into setState() to update a state based on previous states.
    function increment() {
        setCount(c => c + 1); // Can replace name of stateful variable with its first letter for simplicity (can be "prevCount" too).
        setCount(c => c + 1); // Allows for safe updates based on previous states (good practice to use).
        setCount(c => c + 1);
    }

    function decrement() {
        setCount(prevCount => prevCount - 1); // Example of using "prevCount" naming convention.
        setCount(prevCount => prevCount - 1);
        setCount(prevCount => prevCount - 1);
    }

    function reset() {
        setCount(0); // Updater function not necessary, we do not need the previous state here.
    }

    return (
        <div>
            <p>Count: {count}</p>
            <button onClick={decrement}>Decrement</button>
            <button onClick={reset}>Reset</button>
            <button onClick={increment}>Increment</button>
        </div>
    );
}

export default UpdaterFunctions