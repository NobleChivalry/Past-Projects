import React from "react"

function Stopwatch() {
    const [isRunning, setIsRunning] = React.useState<boolean>(false);
    const [elapsedTime, setElapsedTime] = React.useState<number>(0);
    const intervalIdRef = React.useRef<number>(null);
    const startTimeRef = React.useRef<number>(0);

    React.useEffect(() => {
        if (isRunning) {
            intervalIdRef.current = setInterval(() => {
                setElapsedTime(Date.now() - startTimeRef.current);
            }, 10);
        }

        return () => {
            if (intervalIdRef.current) {
                clearInterval(intervalIdRef.current);
            }
        }
    }, [isRunning]);

    function start() {
        setIsRunning(true);
        startTimeRef.current = Date.now() - elapsedTime; // "Date.now()" returns current date & time.
    }

    function stop() {
        setIsRunning(false);
    }

    function reset() {
        setElapsedTime(0);
        setIsRunning(false);
    }

    function formatTime() { // Uses Math library.
        let hours = Math.floor(elapsedTime / (1000 * 60 * 60));
        let minutes = Math.floor(elapsedTime / (1000 * 60) % 60);
        let seconds = Math.floor(elapsedTime / (1000) % 60);
        let ms = Math.floor((elapsedTime % 1000) / 10);

        const hoursStr = String(hours).padStart(2, "0"); // TypeScript doesn't like it when we don't follow type consistency.
        const minutesStr = String(minutes).padStart(2, "0"); // Doesn't allow for type conversion.
        const secondsStr = String(seconds).padStart(2, "0");
        const msStr = String(ms).padStart(2, "0");

        return `${hoursStr}:${minutesStr}:${secondsStr}:${msStr}`;
    }

    return (
        <div className="stopwatch">
            <div className="display">{formatTime()}</div>
            <div className="controls">
                <button className="start-button" onClick={start}>Start</button>
                <button className="stop-button" onClick={stop}>Stop</button>
                <button className="reset-button" onClick={reset}>Reset</button>
            </div>
        </div>
    );
}

export default Stopwatch