// npm create vite@latest (?)
// cd my-react-app
// npm install (?)
// npm run dev

// Vite: A local development server and fast frontend development tool.
// .jsx = JavaScript XML = JavaScript + HTML Code
// Use "{}" whenever you want to insert JavaScript code.

// Component: A section of reusable JSX code.
// "App" component ties all other components together.
// Global styling sheet is "index.css".

// Component = File with Class Type(?)
// Element = HTML Tag

// Files in "public" are like images derived from links.
// Files in "assets" are like images derived from downloads.

/*
Ways of Styling React Components with CSS:
1. External = Use External/Global CSS Style Sheet (Issues: Naming Conflicts & Accidental Overriding; Good for Smaller & Simpler Programs)
2. Modules = Group Component with Component-Specific Style Sheet (Ex: Button; Most Balanced Approach)
3. Inline = Define and Use Styles within Component (Ex: RoundButton)
*/

// An "object" is like a map/dictionary but the key is always just a "name" (e.g. {name: "Mario", age: 35}).
// "number" is primitive class, while "Number" is wrapper class (used for type conversion).
// Bold Text: Use "strong" element if text is important, "b" element if less important, and CSS font-weight if not important.
// "===" means they must be the same value AND type, while "==" means they must just be the same value (type conversion).
// map() and filter() functions can take in 2 parameters. 1st is element itself, 2nd is element index number. Both need arrow function.
// For default style property, set style property to empty string.

// "<br/>" creates a line break.
// "<hr/>" creates a horizontal line.

// "div" element creates a new line.
// "span" element does not create a new line.

// onClick requires event handler and ARROW FUNCTION IF THERE IS AN ISSUE.
// onChange requires just event handler.

// Strict mode makes code run twice as much as normally (Development-Only Setup, then Cleanup Cycle).
// Can remove StrictMode tag in "main.tsx".

import Header from "./Header.tsx" // Imports "name" from "file in specified file location".
import Footer from "./Footer.tsx"
import Food from "./Food.tsx"
import Card from "./Card.tsx"
import Button from "./Button/Button.tsx"
import RoundButton from "./RoundButton.tsx"
import Student from "./Student.tsx"
import UserGreeting from "./UserGreeting.tsx"
import List from "./List.tsx"
import SquareButton from "./SquareButton.tsx"
import ProfilePicture from "./ProfilePicture.tsx"
import MyComponent from "./MyComponent.tsx"
import Counter from "./Counter.tsx"
import FormElements from "./FormElements.tsx"
import ColorPicker from "./ColorPicker.tsx"
import UpdaterFunctions from "./UpdaterFunctions.tsx"
import FavoriteCar from "./FavoriteCar.tsx"
import Foods from "./Foods.tsx"
import FavoriteCars from "./FavoriteCars.tsx"
import ToDoList from "./ToDoList.tsx"
import Effect from "./Effect.tsx"
import Listener from "./Listener.tsx"
import DigitalClock from "./DigitalClock.tsx"
import ComponentA from "./ComponentX/ComponentA.tsx"
import Ref from "./Ref.tsx"
import Stopwatch from "./Stopwatch.tsx"

// Global variables that can be used to affect the page.
document // "title" attribute used to change name of page's tab.
window   // addEventListener("event", function) function used with useEffect() hook to create event listener.
// "body" HTML element affects EVERYTHING. Will wipe out all other components if not used in main component (invisible default one exists).

function App() {
  // Function must return just 1 HTML object. Outside of return is purely JS.
  // Fragment elements are good for avoiding extra nodes to the DOM.
  return(
    <> {/* Enclose all components/content within a fragment element if not planning on using CSS styling. */}
      {/* This is how you make a comment within an HTML element. */}
      <Header></Header> {/* Creates Header component. */}
      {/* Shorthand version writing the HTML: <Header/> */}
      <hr></hr> {/* Horizontal Rule = Line Divider */}
      <Food/>
      <hr/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <Card/>
      <hr/>
      <Button/>
      <hr/>
      <RoundButton/>
      <hr/>
      {/* Props = Read-only properties shared between components; parent component sends child component data through key-value pairs. */}
      {/* Can define own attributes for component on the spot. Using wrong type will lead to inferences. */}
      <Student name="Mario" age={35} isStudent={true}/> {/* Must use JS field for non-string literal values. */}
      <Student name="Luigi" age={30} isStudent={false}/> {/* Allows for diversity of component type. */}
      <hr/>
      {/* There can only be 1 parameter and 1 return object for each function. */}
      <UserGreeting isLoggedIn={true} username="Mario"/>
      <UserGreeting isLoggedIn={false} username="Mario"/>
      <hr/>
      <List category="Fruits"/>
      <List/>
      <hr/>
      {/* Example of Event Handlers, String Formatting, & Type Conversion */}
      <SquareButton/>
      <hr/>
      {/* Example of Accessing & Modifying Target of Event Handler */}
      <ProfilePicture/>
      <hr/>
      {/* React Hook: Special function that allows functional components to use React features w/o writing class components. */}
      <MyComponent/> {/* Some include: useState, useEffect, useContext, useReducer, useCallback, etc. */}
      <hr/>
      <Counter/> {/* useState() is most useful React hook. Updates states of variables. */}
      <hr/>
      {/* onChange = Event handler used primarily with "form elements". Triggers function whenever value of input changes. */}
      <FormElements/> {/* Some form elements include: <input>, <textarea>, <select>, <radio>, etc. */}
      <hr/>
      <ColorPicker/>
      <hr/>
      {/* Example of Updater Functions (Remake of Counter Component) */}
      <UpdaterFunctions/>
      <hr/>
      {/* Example of Updating State of Objects & Using "..." Operator */}
      <FavoriteCar/>
      <hr/>
      {/* Example of Updating State of Arrays & Using "key" Field */}
      <Foods/>
      <hr/>
      {/* Example of Updating State of Arrays of Objects */}
      <FavoriteCars/>
      <hr/>
      <ToDoList/>
      <hr/>
      {/* Example of Using useEffect() Hook */}
      <Effect/>
      <hr/>
      {/* Example of Using useEffect() Hook Part 2, Event Listeners, & Cleanup Functions */}
      <Listener/>
      <hr/>
      {/* Example of Using Hooks & Intervals */}
      <DigitalClock/>
      <hr/>
      {/* Example of Using useContext() Hook & Prop Drilling */}
      <ComponentA/>
      <hr/>
      {/* Example of Using useRef() Hook instead of useState() */}
      <Ref/>
      <hr/>
      {/* Example of Using Hooks & Math Library */}
      <Stopwatch/>
      <hr/>
      <Footer/>
    </>
  );
}

export default App