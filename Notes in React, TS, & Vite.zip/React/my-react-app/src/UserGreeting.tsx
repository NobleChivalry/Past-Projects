// Example of using ternary operators to display elements of the same type differently through CSS styling.

function UserGreeting({isLoggedIn = false, username = "Guest"}: propTypes) {
    // Abstracting HTML elements into variables can make code easier to read.
    const welcomeMessage =  <h2 className="welcome-message">Welcome, {username}!</h2>;
    const loginPrompt = <h2 className="login-prompt">Please log in to continue...</h2>;

    // Can use ternary operators instead of if-else statements in JSX.
    return isLoggedIn ? welcomeMessage : loginPrompt;

    /*
    return (isLoggedIn ?    <h2 className="welcome-message">Welcome, {username}!</h2> :
                            <h2 className="login-prompt">Please log in to continue...</h2>);
    */
    
    //return isLoggedIn ? <h2 className="welcome-message">Welcome, {username}!</h2> : <h2 className="login-prompt">Please log in to continue...</h2>;
    
    /*
    if (isLoggedIn) {
        return (
            <h2 className="welcome-message">Welcome, {username}!</h2>
        );
    }
    return (
        <h2 className="login-prompt">Please log in to continue...</h2>
    );
    */
}

type propTypes = {
    isLoggedIn: boolean,
    username: string
};

export default UserGreeting