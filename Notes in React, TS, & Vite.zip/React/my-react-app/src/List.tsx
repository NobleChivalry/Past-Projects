// Even if there's only 1 attribute, the parameter must still be a mapping of sorts ("{}").
function List({category = "NULL"}) {
    const fruits = [{id: 1, name: "apple", calories: 95},
                    {id: 2, name: "orange", calories: 45},
                    {id: 3, name: "banana", calories: 105},
                    {id: 4, name: "coconut", calories: 159},
                    {id: 5, name: "pineapple", calories: 37}];
    
    // Sort array method is lexicographical (~alphabetical) by default.
    // The (a, b) parameters refer to 2 different elements in the array to be compared to each other.
    fruits.sort((a, b) => a.name.localeCompare(b.name)); // Alphabetical Order
    fruits.sort((a, b) => b.name.localeCompare(a.name)); // Reverse Alphabetical Order
    fruits.sort((a, b) => a.calories - b.calories); // Numeric Order (Smaller Number = Larger Differences)
    fruits.sort((a, b) => b.calories - a.calories); // Reverse Numeric Order
    
    // The "filter" function can be called on an array in order to include only elements that meet a certain condition.
    //const lowCalFruits = fruits.filter(fruit => fruit.calories < 100);
    //const highCalFruits = fruits.filter(fruit => fruit.calories >= 100);

    // The "map" function can be called on an array in order to transform each element inside of the array in some way.
    // Warning: Since we're deriving a list item element from objects instead of primitives, each one needs a unique "key" parameter (id is unique).
    const listItems = fruits.map(fruit => <li key={fruit.id}>
                                                {fruit.name}: &nbsp; {/* nbsp = Non-Breaking Space Character (keeps text on only 1 line) */}
                                                <b>{fruit.calories}</b>
                                                </li>); // Can have a JS array of HTML elements.

    // Example of Ternary Operations w/o Else Output (Latter is Shortcircuiting)
    category == "NULL" ? console.log("amogus1") : null;
    category == "NULL" && console.log("amogus2");
    
    // Example of Rendering Lists: If "category" is not defined or defined innapropriately by the user, component does not display (null).
    if (category == "NULL") {
        return null;
    }

    // JS array of list item (li) elements can be placed inside of a list element (ul/ol).
    // Unordered list element is bulleted. Ordered list element is numbered (1-inf).
    return (
        <>
            {/* "arr.length" returns the length of an array. */}
            <h3 className="list-category">{category} ({fruits.length})</h3>
            <ol className="list-items">{listItems}</ol>
        </>
    );
}

export default List