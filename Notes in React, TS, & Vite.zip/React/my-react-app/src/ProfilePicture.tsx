import React from "react"

function ProfilePicture() {
    // For URLs, need to start at main directory of the project.
    const imageURL = "./src/assets/Portrait.png";

    // Can access target's style sheet to modify its appearance.
    const handleClick = (e: React.MouseEvent) => {
        const target = e.target as HTMLElement;
        target.style.display = "none";
    };

    // Clicking on the image makes it disappear.
    return (
        <img style={styles} src={imageURL} onClick={handleClick}></img>
    );
}

const styles = {
    height: "250px"
};

export default ProfilePicture