import React from "react"
import ComponentB from "./ComponentB.tsx"

// useContext() Hook = React hook that allows you to share values between multiple levels of components w/o passing props through each level.

// Provider Component = ComponentA (Exports Context)
// Consumer Component = ComponentD & ComponentC (Imports Context)

// Solution to prop drilling is the useContext() hook.
// We export the context in ComponentA that contains "user" to import the context into ComponentD and ComponentC directly.
export const UserContext = React.createContext(""); // Can use "ColorContext" name if dealing with colors.

function ComponentA() {
    const [user, _] = React.useState("Mario");

    return (
        <div className="box">
            <h1>ComponentA</h1>
            <h2>{`Hello, ${user}!`}</h2>

            {/* The context of passing down value of "user" to other components in lower levels. MUST WRAP CHILDREN COMPONENTS. */}
            <UserContext.Provider value={user}>
                <ComponentB/>
            </UserContext.Provider>

            {/* Conceptual Example of Prop Drilling ("Passing Down Props") */}
            {/* If we wanted to display "user" in ComponentD, we would need to pass down props from A to B, C, then D. */}
            {/* <ComponentB user={user}/> // Then, write props parameter for B; Rinse and repeat. */}
        </div>
    );
}

export default ComponentA