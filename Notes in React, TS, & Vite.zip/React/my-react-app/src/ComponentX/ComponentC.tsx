import React from "react"
import ComponentD from "./ComponentD.tsx"

import {UserContext} from "./ComponentA.tsx"

function ComponentC() {
    const user = React.useContext(UserContext);

    return (
        <div className="box">
            <h1>ComponentC</h1>
            <h2>{`Hello again, ${user}!`}</h2>
            <ComponentD/>
        </div>
    );
}

export default ComponentC