import React from "react"

// Importing the context from ComponentA.
import {UserContext} from "./ComponentA.tsx"

function ComponentD() {
    // Using the context returns the stored value.
    const user = React.useContext(UserContext);

    return (
        <div className="box">
            <h1>ComponentD</h1>
            <h2>{`Bye, ${user}!`}</h2>
        </div>
    );
}

export default ComponentD