function Header() {
    return(
        // Can only return 1 HTML object.
        <header>
            <h1>MyWebsite</h1>
            <nav> {/* Navigation Bar */}
                <ul> {/* Unordered List = UL; Ordered List = OL. */}
                    <li><a href="">Home</a></li> {/* Turns list items into hyperlinks. */}
                    <li><a href="">About</a></li>
                    <li><a href="">Services</a></li>
                    <li><a href="">Contact</a></li>
                </ul>
            </nav>
        </header>
    );
}

export default Header