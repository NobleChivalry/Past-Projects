import React from "react"

function Foods() {
    const [foods, setFoods] = React.useState(["Apple", "Orange", "Banana"]);

    /* Need to handle TypeScript on element within "document" appropriately. */
    function handleAddFood() { 
        const element = document.getElementById("foodInput") as HTMLInputElement; // "document" is global variable referring to the whole page itself.
        const newFood = element.value; // getElementById() returns HTML element with specified ID.
        element.value = ""; // Resets input field after pressing button.
        setFoods(f => [...f, newFood]);
    }

    function handleRemoveFood(index: number) {
        setFoods(foods.filter((_, i) => i !== index)); // Convention: If will never use variable, replace it with "_".
    }
    
    return (
        <div>
            <h2>List of Foods:</h2>
            <ul> {/* 1st Parameter = Element; 2nd Parameter = Index Number */}
                {foods.map((food, index) =>
                    <li key={index} onClick={() => handleRemoveFood(index)}> {/* "key" field used as identifier for list item elements. */}
                        {food}
                    </li>
                )}
            </ul>
            <input type="text" id="foodInput" placeholder="Enter food name"/>
            <button onClick={handleAddFood}>Add Food</button>
        </div>
    );
}

export default Foods